/**
 */
package asa;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Service Requis</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see asa.AsaPackage#getServiceRequis()
 * @model
 * @generated
 */
public interface ServiceRequis extends Services {
} // ServiceRequis

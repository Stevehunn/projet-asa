/**
 */
package asa;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Service Fourni</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see asa.AsaPackage#getServiceFourni()
 * @model
 * @generated
 */
public interface ServiceFourni extends Services {
} // ServiceFourni

/**
 */
package asa;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>New EClass25</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see asa.AsaPackage#getNewEClass25()
 * @model
 * @generated
 */
public interface NewEClass25 extends EObject {
} // NewEClass25

/**
 */
package asa;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Role Fourni</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see asa.AsaPackage#getRoleFourni()
 * @model
 * @generated
 */
public interface RoleFourni extends Role {
} // RoleFourni

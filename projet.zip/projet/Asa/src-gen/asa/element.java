/**
 */
package asa;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>element</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link asa.element#getPropriete <em>Propriete</em>}</li>
 *   <li>{@link asa.element#getName <em>Name</em>}</li>
 * </ul>
 *
 * @see asa.AsaPackage#getelement()
 * @model abstract="true"
 * @generated
 */
public interface element extends EObject {
	/**
	 * Returns the value of the '<em><b>Propriete</b></em>' containment reference list.
	 * The list contents are of type {@link asa.Propriete}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Propriete</em>' containment reference list.
	 * @see asa.AsaPackage#getelement_Propriete()
	 * @model containment="true"
	 * @generated
	 */
	EList<Propriete> getPropriete();

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see asa.AsaPackage#getelement_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link asa.element#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

} // element

/**
 */
package asa;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Port Config Fournis</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see asa.AsaPackage#getPortConfigFournis()
 * @model
 * @generated
 */
public interface PortConfigFournis extends PortConfig {
} // PortConfigFournis

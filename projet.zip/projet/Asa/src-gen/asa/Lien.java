/**
 */
package asa;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Lien</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see asa.AsaPackage#getLien()
 * @model abstract="true"
 * @generated
 */
public interface Lien extends element {
} // Lien

/**
 */
package asa;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Propriete</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see asa.AsaPackage#getPropriete()
 * @model
 * @generated
 */
public interface Propriete extends EObject {
} // Propriete

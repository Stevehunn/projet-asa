/**
 */
package asa;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Port Config Requis</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see asa.AsaPackage#getPortConfigRequis()
 * @model
 * @generated
 */
public interface PortConfigRequis extends PortConfig {
} // PortConfigRequis

/**
 */
package asa.impl;

import asa.AsaPackage;
import asa.ConnecteurFeuille;
import asa.Glue;
import asa.InterfaceConnnecteur;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Connecteur Feuille</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link asa.impl.ConnecteurFeuilleImpl#getInterfaceconnnecteur <em>Interfaceconnnecteur</em>}</li>
 *   <li>{@link asa.impl.ConnecteurFeuilleImpl#getGlue <em>Glue</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ConnecteurFeuilleImpl extends ConnecteurImpl implements ConnecteurFeuille {
	/**
	 * The cached value of the '{@link #getInterfaceconnnecteur() <em>Interfaceconnnecteur</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInterfaceconnnecteur()
	 * @generated
	 * @ordered
	 */
	protected EList<InterfaceConnnecteur> interfaceconnnecteur;

	/**
	 * The cached value of the '{@link #getGlue() <em>Glue</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGlue()
	 * @generated
	 * @ordered
	 */
	protected Glue glue;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ConnecteurFeuilleImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return AsaPackage.Literals.CONNECTEUR_FEUILLE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<InterfaceConnnecteur> getInterfaceconnnecteur() {
		if (interfaceconnnecteur == null) {
			interfaceconnnecteur = new EObjectContainmentEList<InterfaceConnnecteur>(InterfaceConnnecteur.class, this,
					AsaPackage.CONNECTEUR_FEUILLE__INTERFACECONNNECTEUR);
		}
		return interfaceconnnecteur;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Glue getGlue() {
		return glue;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetGlue(Glue newGlue, NotificationChain msgs) {
		Glue oldGlue = glue;
		glue = newGlue;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					AsaPackage.CONNECTEUR_FEUILLE__GLUE, oldGlue, newGlue);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setGlue(Glue newGlue) {
		if (newGlue != glue) {
			NotificationChain msgs = null;
			if (glue != null)
				msgs = ((InternalEObject) glue).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - AsaPackage.CONNECTEUR_FEUILLE__GLUE, null, msgs);
			if (newGlue != null)
				msgs = ((InternalEObject) newGlue).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - AsaPackage.CONNECTEUR_FEUILLE__GLUE, null, msgs);
			msgs = basicSetGlue(newGlue, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AsaPackage.CONNECTEUR_FEUILLE__GLUE, newGlue,
					newGlue));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case AsaPackage.CONNECTEUR_FEUILLE__INTERFACECONNNECTEUR:
			return ((InternalEList<?>) getInterfaceconnnecteur()).basicRemove(otherEnd, msgs);
		case AsaPackage.CONNECTEUR_FEUILLE__GLUE:
			return basicSetGlue(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case AsaPackage.CONNECTEUR_FEUILLE__INTERFACECONNNECTEUR:
			return getInterfaceconnnecteur();
		case AsaPackage.CONNECTEUR_FEUILLE__GLUE:
			return getGlue();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case AsaPackage.CONNECTEUR_FEUILLE__INTERFACECONNNECTEUR:
			getInterfaceconnnecteur().clear();
			getInterfaceconnnecteur().addAll((Collection<? extends InterfaceConnnecteur>) newValue);
			return;
		case AsaPackage.CONNECTEUR_FEUILLE__GLUE:
			setGlue((Glue) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case AsaPackage.CONNECTEUR_FEUILLE__INTERFACECONNNECTEUR:
			getInterfaceconnnecteur().clear();
			return;
		case AsaPackage.CONNECTEUR_FEUILLE__GLUE:
			setGlue((Glue) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case AsaPackage.CONNECTEUR_FEUILLE__INTERFACECONNNECTEUR:
			return interfaceconnnecteur != null && !interfaceconnnecteur.isEmpty();
		case AsaPackage.CONNECTEUR_FEUILLE__GLUE:
			return glue != null;
		}
		return super.eIsSet(featureID);
	}

} //ConnecteurFeuilleImpl

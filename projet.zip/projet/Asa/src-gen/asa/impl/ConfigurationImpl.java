/**
 */
package asa.impl;

import asa.AsaPackage;
import asa.Composant;
import asa.Configuration;
import asa.Connecteur;
import asa.Lien;
import asa.configurationInterface;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Configuration</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link asa.impl.ConfigurationImpl#getComposant <em>Composant</em>}</li>
 *   <li>{@link asa.impl.ConfigurationImpl#getConnecteur <em>Connecteur</em>}</li>
 *   <li>{@link asa.impl.ConfigurationImpl#getLien <em>Lien</em>}</li>
 *   <li>{@link asa.impl.ConfigurationImpl#getConfigurationinterface <em>Configurationinterface</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ConfigurationImpl extends elementImpl implements Configuration {
	/**
	 * The cached value of the '{@link #getComposant() <em>Composant</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getComposant()
	 * @generated
	 * @ordered
	 */
	protected EList<Composant> composant;

	/**
	 * The cached value of the '{@link #getConnecteur() <em>Connecteur</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getConnecteur()
	 * @generated
	 * @ordered
	 */
	protected EList<Connecteur> connecteur;

	/**
	 * The cached value of the '{@link #getLien() <em>Lien</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLien()
	 * @generated
	 * @ordered
	 */
	protected EList<Lien> lien;

	/**
	 * The cached value of the '{@link #getConfigurationinterface() <em>Configurationinterface</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getConfigurationinterface()
	 * @generated
	 * @ordered
	 */
	protected EList<configurationInterface> configurationinterface;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ConfigurationImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return AsaPackage.Literals.CONFIGURATION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Composant> getComposant() {
		if (composant == null) {
			composant = new EObjectContainmentEList<Composant>(Composant.class, this,
					AsaPackage.CONFIGURATION__COMPOSANT);
		}
		return composant;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Connecteur> getConnecteur() {
		if (connecteur == null) {
			connecteur = new EObjectContainmentEList<Connecteur>(Connecteur.class, this,
					AsaPackage.CONFIGURATION__CONNECTEUR);
		}
		return connecteur;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Lien> getLien() {
		if (lien == null) {
			lien = new EObjectContainmentEList<Lien>(Lien.class, this, AsaPackage.CONFIGURATION__LIEN);
		}
		return lien;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<configurationInterface> getConfigurationinterface() {
		if (configurationinterface == null) {
			configurationinterface = new EObjectContainmentEList<configurationInterface>(configurationInterface.class,
					this, AsaPackage.CONFIGURATION__CONFIGURATIONINTERFACE);
		}
		return configurationinterface;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case AsaPackage.CONFIGURATION__COMPOSANT:
			return ((InternalEList<?>) getComposant()).basicRemove(otherEnd, msgs);
		case AsaPackage.CONFIGURATION__CONNECTEUR:
			return ((InternalEList<?>) getConnecteur()).basicRemove(otherEnd, msgs);
		case AsaPackage.CONFIGURATION__LIEN:
			return ((InternalEList<?>) getLien()).basicRemove(otherEnd, msgs);
		case AsaPackage.CONFIGURATION__CONFIGURATIONINTERFACE:
			return ((InternalEList<?>) getConfigurationinterface()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case AsaPackage.CONFIGURATION__COMPOSANT:
			return getComposant();
		case AsaPackage.CONFIGURATION__CONNECTEUR:
			return getConnecteur();
		case AsaPackage.CONFIGURATION__LIEN:
			return getLien();
		case AsaPackage.CONFIGURATION__CONFIGURATIONINTERFACE:
			return getConfigurationinterface();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case AsaPackage.CONFIGURATION__COMPOSANT:
			getComposant().clear();
			getComposant().addAll((Collection<? extends Composant>) newValue);
			return;
		case AsaPackage.CONFIGURATION__CONNECTEUR:
			getConnecteur().clear();
			getConnecteur().addAll((Collection<? extends Connecteur>) newValue);
			return;
		case AsaPackage.CONFIGURATION__LIEN:
			getLien().clear();
			getLien().addAll((Collection<? extends Lien>) newValue);
			return;
		case AsaPackage.CONFIGURATION__CONFIGURATIONINTERFACE:
			getConfigurationinterface().clear();
			getConfigurationinterface().addAll((Collection<? extends configurationInterface>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case AsaPackage.CONFIGURATION__COMPOSANT:
			getComposant().clear();
			return;
		case AsaPackage.CONFIGURATION__CONNECTEUR:
			getConnecteur().clear();
			return;
		case AsaPackage.CONFIGURATION__LIEN:
			getLien().clear();
			return;
		case AsaPackage.CONFIGURATION__CONFIGURATIONINTERFACE:
			getConfigurationinterface().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case AsaPackage.CONFIGURATION__COMPOSANT:
			return composant != null && !composant.isEmpty();
		case AsaPackage.CONFIGURATION__CONNECTEUR:
			return connecteur != null && !connecteur.isEmpty();
		case AsaPackage.CONFIGURATION__LIEN:
			return lien != null && !lien.isEmpty();
		case AsaPackage.CONFIGURATION__CONFIGURATIONINTERFACE:
			return configurationinterface != null && !configurationinterface.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //ConfigurationImpl

/**
 */
package asa.impl;

import asa.AsaPackage;
import asa.ServiceFourni;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Service Fourni</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ServiceFourniImpl extends ServicesImpl implements ServiceFourni {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ServiceFourniImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return AsaPackage.Literals.SERVICE_FOURNI;
	}

} //ServiceFourniImpl

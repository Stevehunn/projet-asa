/**
 */
package asa.impl;

import asa.AsaPackage;
import asa.Attachement;
import asa.PortsFourni;
import asa.PortsRequis;
import asa.RoleFourni;
import asa.RoleRequis;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Attachement</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link asa.impl.AttachementImpl#getRolefourni <em>Rolefourni</em>}</li>
 *   <li>{@link asa.impl.AttachementImpl#getRolerequis <em>Rolerequis</em>}</li>
 *   <li>{@link asa.impl.AttachementImpl#getPortsfourni <em>Portsfourni</em>}</li>
 *   <li>{@link asa.impl.AttachementImpl#getPortrequis <em>Portrequis</em>}</li>
 * </ul>
 *
 * @generated
 */
public class AttachementImpl extends LienImpl implements Attachement {
	/**
	 * The cached value of the '{@link #getRolefourni() <em>Rolefourni</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRolefourni()
	 * @generated
	 * @ordered
	 */
	protected RoleFourni rolefourni;

	/**
	 * The cached value of the '{@link #getRolerequis() <em>Rolerequis</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRolerequis()
	 * @generated
	 * @ordered
	 */
	protected RoleRequis rolerequis;

	/**
	 * The cached value of the '{@link #getPortsfourni() <em>Portsfourni</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPortsfourni()
	 * @generated
	 * @ordered
	 */
	protected PortsFourni portsfourni;

	/**
	 * The cached value of the '{@link #getPortrequis() <em>Portrequis</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPortrequis()
	 * @generated
	 * @ordered
	 */
	protected PortsRequis portrequis;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AttachementImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return AsaPackage.Literals.ATTACHEMENT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public RoleFourni getRolefourni() {
		if (rolefourni != null && rolefourni.eIsProxy()) {
			InternalEObject oldRolefourni = (InternalEObject) rolefourni;
			rolefourni = (RoleFourni) eResolveProxy(oldRolefourni);
			if (rolefourni != oldRolefourni) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, AsaPackage.ATTACHEMENT__ROLEFOURNI,
							oldRolefourni, rolefourni));
			}
		}
		return rolefourni;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RoleFourni basicGetRolefourni() {
		return rolefourni;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setRolefourni(RoleFourni newRolefourni) {
		RoleFourni oldRolefourni = rolefourni;
		rolefourni = newRolefourni;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AsaPackage.ATTACHEMENT__ROLEFOURNI, oldRolefourni,
					rolefourni));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public RoleRequis getRolerequis() {
		if (rolerequis != null && rolerequis.eIsProxy()) {
			InternalEObject oldRolerequis = (InternalEObject) rolerequis;
			rolerequis = (RoleRequis) eResolveProxy(oldRolerequis);
			if (rolerequis != oldRolerequis) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, AsaPackage.ATTACHEMENT__ROLEREQUIS,
							oldRolerequis, rolerequis));
			}
		}
		return rolerequis;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RoleRequis basicGetRolerequis() {
		return rolerequis;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setRolerequis(RoleRequis newRolerequis) {
		RoleRequis oldRolerequis = rolerequis;
		rolerequis = newRolerequis;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AsaPackage.ATTACHEMENT__ROLEREQUIS, oldRolerequis,
					rolerequis));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public PortsFourni getPortsfourni() {
		if (portsfourni != null && portsfourni.eIsProxy()) {
			InternalEObject oldPortsfourni = (InternalEObject) portsfourni;
			portsfourni = (PortsFourni) eResolveProxy(oldPortsfourni);
			if (portsfourni != oldPortsfourni) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, AsaPackage.ATTACHEMENT__PORTSFOURNI,
							oldPortsfourni, portsfourni));
			}
		}
		return portsfourni;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PortsFourni basicGetPortsfourni() {
		return portsfourni;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setPortsfourni(PortsFourni newPortsfourni) {
		PortsFourni oldPortsfourni = portsfourni;
		portsfourni = newPortsfourni;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AsaPackage.ATTACHEMENT__PORTSFOURNI, oldPortsfourni,
					portsfourni));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public PortsRequis getPortrequis() {
		if (portrequis != null && portrequis.eIsProxy()) {
			InternalEObject oldPortrequis = (InternalEObject) portrequis;
			portrequis = (PortsRequis) eResolveProxy(oldPortrequis);
			if (portrequis != oldPortrequis) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, AsaPackage.ATTACHEMENT__PORTREQUIS,
							oldPortrequis, portrequis));
			}
		}
		return portrequis;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PortsRequis basicGetPortrequis() {
		return portrequis;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setPortrequis(PortsRequis newPortrequis) {
		PortsRequis oldPortrequis = portrequis;
		portrequis = newPortrequis;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AsaPackage.ATTACHEMENT__PORTREQUIS, oldPortrequis,
					portrequis));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case AsaPackage.ATTACHEMENT__ROLEFOURNI:
			if (resolve)
				return getRolefourni();
			return basicGetRolefourni();
		case AsaPackage.ATTACHEMENT__ROLEREQUIS:
			if (resolve)
				return getRolerequis();
			return basicGetRolerequis();
		case AsaPackage.ATTACHEMENT__PORTSFOURNI:
			if (resolve)
				return getPortsfourni();
			return basicGetPortsfourni();
		case AsaPackage.ATTACHEMENT__PORTREQUIS:
			if (resolve)
				return getPortrequis();
			return basicGetPortrequis();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case AsaPackage.ATTACHEMENT__ROLEFOURNI:
			setRolefourni((RoleFourni) newValue);
			return;
		case AsaPackage.ATTACHEMENT__ROLEREQUIS:
			setRolerequis((RoleRequis) newValue);
			return;
		case AsaPackage.ATTACHEMENT__PORTSFOURNI:
			setPortsfourni((PortsFourni) newValue);
			return;
		case AsaPackage.ATTACHEMENT__PORTREQUIS:
			setPortrequis((PortsRequis) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case AsaPackage.ATTACHEMENT__ROLEFOURNI:
			setRolefourni((RoleFourni) null);
			return;
		case AsaPackage.ATTACHEMENT__ROLEREQUIS:
			setRolerequis((RoleRequis) null);
			return;
		case AsaPackage.ATTACHEMENT__PORTSFOURNI:
			setPortsfourni((PortsFourni) null);
			return;
		case AsaPackage.ATTACHEMENT__PORTREQUIS:
			setPortrequis((PortsRequis) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case AsaPackage.ATTACHEMENT__ROLEFOURNI:
			return rolefourni != null;
		case AsaPackage.ATTACHEMENT__ROLEREQUIS:
			return rolerequis != null;
		case AsaPackage.ATTACHEMENT__PORTSFOURNI:
			return portsfourni != null;
		case AsaPackage.ATTACHEMENT__PORTREQUIS:
			return portrequis != null;
		}
		return super.eIsSet(featureID);
	}

} //AttachementImpl

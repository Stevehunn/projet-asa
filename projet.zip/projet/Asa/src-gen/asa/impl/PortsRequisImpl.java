/**
 */
package asa.impl;

import asa.AsaPackage;
import asa.PortsRequis;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Ports Requis</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class PortsRequisImpl extends PortsImpl implements PortsRequis {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PortsRequisImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return AsaPackage.Literals.PORTS_REQUIS;
	}

} //PortsRequisImpl

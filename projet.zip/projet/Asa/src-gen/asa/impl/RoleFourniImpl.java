/**
 */
package asa.impl;

import asa.AsaPackage;
import asa.RoleFourni;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Role Fourni</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class RoleFourniImpl extends RoleImpl implements RoleFourni {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RoleFourniImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return AsaPackage.Literals.ROLE_FOURNI;
	}

} //RoleFourniImpl

/**
 */
package asa.impl;

import asa.AsaPackage;
import asa.PortConfigFournis;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Port Config Fournis</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class PortConfigFournisImpl extends PortConfigImpl implements PortConfigFournis {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PortConfigFournisImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return AsaPackage.Literals.PORT_CONFIG_FOURNIS;
	}

} //PortConfigFournisImpl

/**
 */
package asa.impl;

import asa.AsaPackage;
import asa.Binding;
import asa.PortConfigFournis;
import asa.PortConfigRequis;
import asa.PortsFourni;
import asa.PortsRequis;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Binding</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link asa.impl.BindingImpl#getPortconfigfournis <em>Portconfigfournis</em>}</li>
 *   <li>{@link asa.impl.BindingImpl#getPortconfigrequis <em>Portconfigrequis</em>}</li>
 *   <li>{@link asa.impl.BindingImpl#getPortsfourni <em>Portsfourni</em>}</li>
 *   <li>{@link asa.impl.BindingImpl#getPortsrequis <em>Portsrequis</em>}</li>
 * </ul>
 *
 * @generated
 */
public class BindingImpl extends LienImpl implements Binding {
	/**
	 * The cached value of the '{@link #getPortconfigfournis() <em>Portconfigfournis</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPortconfigfournis()
	 * @generated
	 * @ordered
	 */
	protected PortConfigFournis portconfigfournis;

	/**
	 * The cached value of the '{@link #getPortconfigrequis() <em>Portconfigrequis</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPortconfigrequis()
	 * @generated
	 * @ordered
	 */
	protected PortConfigRequis portconfigrequis;

	/**
	 * The cached value of the '{@link #getPortsfourni() <em>Portsfourni</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPortsfourni()
	 * @generated
	 * @ordered
	 */
	protected PortsFourni portsfourni;

	/**
	 * The cached value of the '{@link #getPortsrequis() <em>Portsrequis</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPortsrequis()
	 * @generated
	 * @ordered
	 */
	protected PortsRequis portsrequis;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected BindingImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return AsaPackage.Literals.BINDING;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public PortConfigFournis getPortconfigfournis() {
		if (portconfigfournis != null && portconfigfournis.eIsProxy()) {
			InternalEObject oldPortconfigfournis = (InternalEObject) portconfigfournis;
			portconfigfournis = (PortConfigFournis) eResolveProxy(oldPortconfigfournis);
			if (portconfigfournis != oldPortconfigfournis) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, AsaPackage.BINDING__PORTCONFIGFOURNIS,
							oldPortconfigfournis, portconfigfournis));
			}
		}
		return portconfigfournis;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PortConfigFournis basicGetPortconfigfournis() {
		return portconfigfournis;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setPortconfigfournis(PortConfigFournis newPortconfigfournis) {
		PortConfigFournis oldPortconfigfournis = portconfigfournis;
		portconfigfournis = newPortconfigfournis;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AsaPackage.BINDING__PORTCONFIGFOURNIS,
					oldPortconfigfournis, portconfigfournis));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public PortConfigRequis getPortconfigrequis() {
		if (portconfigrequis != null && portconfigrequis.eIsProxy()) {
			InternalEObject oldPortconfigrequis = (InternalEObject) portconfigrequis;
			portconfigrequis = (PortConfigRequis) eResolveProxy(oldPortconfigrequis);
			if (portconfigrequis != oldPortconfigrequis) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, AsaPackage.BINDING__PORTCONFIGREQUIS,
							oldPortconfigrequis, portconfigrequis));
			}
		}
		return portconfigrequis;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PortConfigRequis basicGetPortconfigrequis() {
		return portconfigrequis;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setPortconfigrequis(PortConfigRequis newPortconfigrequis) {
		PortConfigRequis oldPortconfigrequis = portconfigrequis;
		portconfigrequis = newPortconfigrequis;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AsaPackage.BINDING__PORTCONFIGREQUIS,
					oldPortconfigrequis, portconfigrequis));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public PortsFourni getPortsfourni() {
		if (portsfourni != null && portsfourni.eIsProxy()) {
			InternalEObject oldPortsfourni = (InternalEObject) portsfourni;
			portsfourni = (PortsFourni) eResolveProxy(oldPortsfourni);
			if (portsfourni != oldPortsfourni) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, AsaPackage.BINDING__PORTSFOURNI,
							oldPortsfourni, portsfourni));
			}
		}
		return portsfourni;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PortsFourni basicGetPortsfourni() {
		return portsfourni;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setPortsfourni(PortsFourni newPortsfourni) {
		PortsFourni oldPortsfourni = portsfourni;
		portsfourni = newPortsfourni;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AsaPackage.BINDING__PORTSFOURNI, oldPortsfourni,
					portsfourni));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public PortsRequis getPortsrequis() {
		if (portsrequis != null && portsrequis.eIsProxy()) {
			InternalEObject oldPortsrequis = (InternalEObject) portsrequis;
			portsrequis = (PortsRequis) eResolveProxy(oldPortsrequis);
			if (portsrequis != oldPortsrequis) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, AsaPackage.BINDING__PORTSREQUIS,
							oldPortsrequis, portsrequis));
			}
		}
		return portsrequis;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PortsRequis basicGetPortsrequis() {
		return portsrequis;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setPortsrequis(PortsRequis newPortsrequis) {
		PortsRequis oldPortsrequis = portsrequis;
		portsrequis = newPortsrequis;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AsaPackage.BINDING__PORTSREQUIS, oldPortsrequis,
					portsrequis));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case AsaPackage.BINDING__PORTCONFIGFOURNIS:
			if (resolve)
				return getPortconfigfournis();
			return basicGetPortconfigfournis();
		case AsaPackage.BINDING__PORTCONFIGREQUIS:
			if (resolve)
				return getPortconfigrequis();
			return basicGetPortconfigrequis();
		case AsaPackage.BINDING__PORTSFOURNI:
			if (resolve)
				return getPortsfourni();
			return basicGetPortsfourni();
		case AsaPackage.BINDING__PORTSREQUIS:
			if (resolve)
				return getPortsrequis();
			return basicGetPortsrequis();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case AsaPackage.BINDING__PORTCONFIGFOURNIS:
			setPortconfigfournis((PortConfigFournis) newValue);
			return;
		case AsaPackage.BINDING__PORTCONFIGREQUIS:
			setPortconfigrequis((PortConfigRequis) newValue);
			return;
		case AsaPackage.BINDING__PORTSFOURNI:
			setPortsfourni((PortsFourni) newValue);
			return;
		case AsaPackage.BINDING__PORTSREQUIS:
			setPortsrequis((PortsRequis) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case AsaPackage.BINDING__PORTCONFIGFOURNIS:
			setPortconfigfournis((PortConfigFournis) null);
			return;
		case AsaPackage.BINDING__PORTCONFIGREQUIS:
			setPortconfigrequis((PortConfigRequis) null);
			return;
		case AsaPackage.BINDING__PORTSFOURNI:
			setPortsfourni((PortsFourni) null);
			return;
		case AsaPackage.BINDING__PORTSREQUIS:
			setPortsrequis((PortsRequis) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case AsaPackage.BINDING__PORTCONFIGFOURNIS:
			return portconfigfournis != null;
		case AsaPackage.BINDING__PORTCONFIGREQUIS:
			return portconfigrequis != null;
		case AsaPackage.BINDING__PORTSFOURNI:
			return portsfourni != null;
		case AsaPackage.BINDING__PORTSREQUIS:
			return portsrequis != null;
		}
		return super.eIsSet(featureID);
	}

} //BindingImpl

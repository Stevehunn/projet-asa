/**
 */
package asa.impl;

import asa.AsaPackage;
import asa.PortConfigRequis;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Port Config Requis</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class PortConfigRequisImpl extends PortConfigImpl implements PortConfigRequis {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PortConfigRequisImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return AsaPackage.Literals.PORT_CONFIG_REQUIS;
	}

} //PortConfigRequisImpl

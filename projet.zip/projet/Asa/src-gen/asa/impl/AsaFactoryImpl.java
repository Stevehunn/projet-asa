/**
 */
package asa.impl;

import asa.AsaFactory;
import asa.AsaPackage;
import asa.Attachement;
import asa.Binding;
import asa.Composant;
import asa.ComposantFeuille;
import asa.Configuration;
import asa.Connecteur;
import asa.ConnecteurFeuille;
import asa.Glue;
import asa.NewEClass25;
import asa.PortConfig;
import asa.PortConfigFournis;
import asa.PortConfigRequis;
import asa.PortsFourni;
import asa.PortsRequis;
import asa.Propriete;
import asa.Role;
import asa.RoleFourni;
import asa.RoleRequis;
import asa.ServiceFourni;
import asa.ServiceRequis;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class AsaFactoryImpl extends EFactoryImpl implements AsaFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static AsaFactory init() {
		try {
			AsaFactory theAsaFactory = (AsaFactory) EPackage.Registry.INSTANCE.getEFactory(AsaPackage.eNS_URI);
			if (theAsaFactory != null) {
				return theAsaFactory;
			}
		} catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new AsaFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AsaFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		case AsaPackage.COMPOSANT:
			return createComposant();
		case AsaPackage.CONFIGURATION:
			return createConfiguration();
		case AsaPackage.CONNECTEUR:
			return createConnecteur();
		case AsaPackage.BINDING:
			return createBinding();
		case AsaPackage.ATTACHEMENT:
			return createAttachement();
		case AsaPackage.GLUE:
			return createGlue();
		case AsaPackage.ROLE_REQUIS:
			return createRoleRequis();
		case AsaPackage.ROLE_FOURNI:
			return createRoleFourni();
		case AsaPackage.COMPOSANT_FEUILLE:
			return createComposantFeuille();
		case AsaPackage.CONNECTEUR_FEUILLE:
			return createConnecteurFeuille();
		case AsaPackage.SERVICE_REQUIS:
			return createServiceRequis();
		case AsaPackage.SERVICE_FOURNI:
			return createServiceFourni();
		case AsaPackage.PORTS_REQUIS:
			return createPortsRequis();
		case AsaPackage.PORTS_FOURNI:
			return createPortsFourni();
		case AsaPackage.ROLE:
			return createRole();
		case AsaPackage.NEW_ECLASS25:
			return createNewEClass25();
		case AsaPackage.SYSTEM:
			return createSystem();
		case AsaPackage.PROPRIETE:
			return createPropriete();
		case AsaPackage.PORT_CONFIG:
			return createPortConfig();
		case AsaPackage.PORT_CONFIG_FOURNIS:
			return createPortConfigFournis();
		case AsaPackage.PORT_CONFIG_REQUIS:
			return createPortConfigRequis();
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Composant createComposant() {
		ComposantImpl composant = new ComposantImpl();
		return composant;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Configuration createConfiguration() {
		ConfigurationImpl configuration = new ConfigurationImpl();
		return configuration;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Connecteur createConnecteur() {
		ConnecteurImpl connecteur = new ConnecteurImpl();
		return connecteur;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Binding createBinding() {
		BindingImpl binding = new BindingImpl();
		return binding;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Attachement createAttachement() {
		AttachementImpl attachement = new AttachementImpl();
		return attachement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Glue createGlue() {
		GlueImpl glue = new GlueImpl();
		return glue;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public RoleRequis createRoleRequis() {
		RoleRequisImpl roleRequis = new RoleRequisImpl();
		return roleRequis;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public RoleFourni createRoleFourni() {
		RoleFourniImpl roleFourni = new RoleFourniImpl();
		return roleFourni;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ComposantFeuille createComposantFeuille() {
		ComposantFeuilleImpl composantFeuille = new ComposantFeuilleImpl();
		return composantFeuille;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ConnecteurFeuille createConnecteurFeuille() {
		ConnecteurFeuilleImpl connecteurFeuille = new ConnecteurFeuilleImpl();
		return connecteurFeuille;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ServiceRequis createServiceRequis() {
		ServiceRequisImpl serviceRequis = new ServiceRequisImpl();
		return serviceRequis;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ServiceFourni createServiceFourni() {
		ServiceFourniImpl serviceFourni = new ServiceFourniImpl();
		return serviceFourni;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public PortsRequis createPortsRequis() {
		PortsRequisImpl portsRequis = new PortsRequisImpl();
		return portsRequis;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public PortsFourni createPortsFourni() {
		PortsFourniImpl portsFourni = new PortsFourniImpl();
		return portsFourni;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Role createRole() {
		RoleImpl role = new RoleImpl();
		return role;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NewEClass25 createNewEClass25() {
		NewEClass25Impl newEClass25 = new NewEClass25Impl();
		return newEClass25;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public asa.System createSystem() {
		SystemImpl system = new SystemImpl();
		return system;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Propriete createPropriete() {
		ProprieteImpl propriete = new ProprieteImpl();
		return propriete;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public PortConfig createPortConfig() {
		PortConfigImpl portConfig = new PortConfigImpl();
		return portConfig;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public PortConfigFournis createPortConfigFournis() {
		PortConfigFournisImpl portConfigFournis = new PortConfigFournisImpl();
		return portConfigFournis;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public PortConfigRequis createPortConfigRequis() {
		PortConfigRequisImpl portConfigRequis = new PortConfigRequisImpl();
		return portConfigRequis;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public AsaPackage getAsaPackage() {
		return (AsaPackage) getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static AsaPackage getPackage() {
		return AsaPackage.eINSTANCE;
	}

} //AsaFactoryImpl

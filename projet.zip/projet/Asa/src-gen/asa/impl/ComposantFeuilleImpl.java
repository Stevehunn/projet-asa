/**
 */
package asa.impl;

import asa.AsaPackage;
import asa.ComposantFeuille;
import asa.InterfaceComposant;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Composant Feuille</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link asa.impl.ComposantFeuilleImpl#getInterfacecomposant <em>Interfacecomposant</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ComposantFeuilleImpl extends ComposantImpl implements ComposantFeuille {
	/**
	 * The cached value of the '{@link #getInterfacecomposant() <em>Interfacecomposant</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInterfacecomposant()
	 * @generated
	 * @ordered
	 */
	protected EList<InterfaceComposant> interfacecomposant;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ComposantFeuilleImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return AsaPackage.Literals.COMPOSANT_FEUILLE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<InterfaceComposant> getInterfacecomposant() {
		if (interfacecomposant == null) {
			interfacecomposant = new EObjectContainmentEList<InterfaceComposant>(InterfaceComposant.class, this,
					AsaPackage.COMPOSANT_FEUILLE__INTERFACECOMPOSANT);
		}
		return interfacecomposant;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case AsaPackage.COMPOSANT_FEUILLE__INTERFACECOMPOSANT:
			return ((InternalEList<?>) getInterfacecomposant()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case AsaPackage.COMPOSANT_FEUILLE__INTERFACECOMPOSANT:
			return getInterfacecomposant();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case AsaPackage.COMPOSANT_FEUILLE__INTERFACECOMPOSANT:
			getInterfacecomposant().clear();
			getInterfacecomposant().addAll((Collection<? extends InterfaceComposant>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case AsaPackage.COMPOSANT_FEUILLE__INTERFACECOMPOSANT:
			getInterfacecomposant().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case AsaPackage.COMPOSANT_FEUILLE__INTERFACECOMPOSANT:
			return interfacecomposant != null && !interfacecomposant.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //ComposantFeuilleImpl

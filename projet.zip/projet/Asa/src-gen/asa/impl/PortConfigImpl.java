/**
 */
package asa.impl;

import asa.AsaPackage;
import asa.PortConfig;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Port Config</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class PortConfigImpl extends MinimalEObjectImpl.Container implements PortConfig {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PortConfigImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return AsaPackage.Literals.PORT_CONFIG;
	}

} //PortConfigImpl

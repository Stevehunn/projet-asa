/**
 */
package asa.impl;

import asa.AsaPackage;
import asa.NewEClass25;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>New EClass25</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class NewEClass25Impl extends MinimalEObjectImpl.Container implements NewEClass25 {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected NewEClass25Impl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return AsaPackage.Literals.NEW_ECLASS25;
	}

} //NewEClass25Impl

/**
 */
package asa;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see asa.AsaFactory
 * @model kind="package"
 * @generated
 */
public interface AsaPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "asa";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.example.org/asa";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "asa";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	AsaPackage eINSTANCE = asa.impl.AsaPackageImpl.init();

	/**
	 * The meta object id for the '{@link asa.impl.elementImpl <em>element</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see asa.impl.elementImpl
	 * @see asa.impl.AsaPackageImpl#getelement()
	 * @generated
	 */
	int ELEMENT = 23;

	/**
	 * The feature id for the '<em><b>Propriete</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEMENT__PROPRIETE = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEMENT__NAME = 1;

	/**
	 * The number of structural features of the '<em>element</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEMENT_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>element</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEMENT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link asa.impl.ComposantImpl <em>Composant</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see asa.impl.ComposantImpl
	 * @see asa.impl.AsaPackageImpl#getComposant()
	 * @generated
	 */
	int COMPOSANT = 0;

	/**
	 * The feature id for the '<em><b>Propriete</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPOSANT__PROPRIETE = ELEMENT__PROPRIETE;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPOSANT__NAME = ELEMENT__NAME;

	/**
	 * The number of structural features of the '<em>Composant</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPOSANT_FEATURE_COUNT = ELEMENT_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Composant</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPOSANT_OPERATION_COUNT = ELEMENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link asa.impl.ConfigurationImpl <em>Configuration</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see asa.impl.ConfigurationImpl
	 * @see asa.impl.AsaPackageImpl#getConfiguration()
	 * @generated
	 */
	int CONFIGURATION = 1;

	/**
	 * The feature id for the '<em><b>Propriete</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONFIGURATION__PROPRIETE = ELEMENT__PROPRIETE;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONFIGURATION__NAME = ELEMENT__NAME;

	/**
	 * The feature id for the '<em><b>Composant</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONFIGURATION__COMPOSANT = ELEMENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Connecteur</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONFIGURATION__CONNECTEUR = ELEMENT_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Lien</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONFIGURATION__LIEN = ELEMENT_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Configurationinterface</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONFIGURATION__CONFIGURATIONINTERFACE = ELEMENT_FEATURE_COUNT + 3;

	/**
	 * The number of structural features of the '<em>Configuration</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONFIGURATION_FEATURE_COUNT = ELEMENT_FEATURE_COUNT + 4;

	/**
	 * The number of operations of the '<em>Configuration</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONFIGURATION_OPERATION_COUNT = ELEMENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link asa.impl.ConnecteurImpl <em>Connecteur</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see asa.impl.ConnecteurImpl
	 * @see asa.impl.AsaPackageImpl#getConnecteur()
	 * @generated
	 */
	int CONNECTEUR = 2;

	/**
	 * The feature id for the '<em><b>Propriete</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTEUR__PROPRIETE = ELEMENT__PROPRIETE;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTEUR__NAME = ELEMENT__NAME;

	/**
	 * The number of structural features of the '<em>Connecteur</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTEUR_FEATURE_COUNT = ELEMENT_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Connecteur</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTEUR_OPERATION_COUNT = ELEMENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link asa.impl.LienImpl <em>Lien</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see asa.impl.LienImpl
	 * @see asa.impl.AsaPackageImpl#getLien()
	 * @generated
	 */
	int LIEN = 22;

	/**
	 * The feature id for the '<em><b>Propriete</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIEN__PROPRIETE = ELEMENT__PROPRIETE;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIEN__NAME = ELEMENT__NAME;

	/**
	 * The number of structural features of the '<em>Lien</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIEN_FEATURE_COUNT = ELEMENT_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Lien</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIEN_OPERATION_COUNT = ELEMENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link asa.impl.BindingImpl <em>Binding</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see asa.impl.BindingImpl
	 * @see asa.impl.AsaPackageImpl#getBinding()
	 * @generated
	 */
	int BINDING = 3;

	/**
	 * The feature id for the '<em><b>Propriete</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BINDING__PROPRIETE = LIEN__PROPRIETE;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BINDING__NAME = LIEN__NAME;

	/**
	 * The feature id for the '<em><b>Portconfigfournis</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BINDING__PORTCONFIGFOURNIS = LIEN_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Portconfigrequis</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BINDING__PORTCONFIGREQUIS = LIEN_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Portsfourni</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BINDING__PORTSFOURNI = LIEN_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Portsrequis</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BINDING__PORTSREQUIS = LIEN_FEATURE_COUNT + 3;

	/**
	 * The number of structural features of the '<em>Binding</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BINDING_FEATURE_COUNT = LIEN_FEATURE_COUNT + 4;

	/**
	 * The number of operations of the '<em>Binding</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BINDING_OPERATION_COUNT = LIEN_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link asa.impl.AttachementImpl <em>Attachement</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see asa.impl.AttachementImpl
	 * @see asa.impl.AsaPackageImpl#getAttachement()
	 * @generated
	 */
	int ATTACHEMENT = 4;

	/**
	 * The feature id for the '<em><b>Propriete</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTACHEMENT__PROPRIETE = LIEN__PROPRIETE;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTACHEMENT__NAME = LIEN__NAME;

	/**
	 * The feature id for the '<em><b>Rolefourni</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTACHEMENT__ROLEFOURNI = LIEN_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Rolerequis</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTACHEMENT__ROLEREQUIS = LIEN_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Portsfourni</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTACHEMENT__PORTSFOURNI = LIEN_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Portrequis</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTACHEMENT__PORTREQUIS = LIEN_FEATURE_COUNT + 3;

	/**
	 * The number of structural features of the '<em>Attachement</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTACHEMENT_FEATURE_COUNT = LIEN_FEATURE_COUNT + 4;

	/**
	 * The number of operations of the '<em>Attachement</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTACHEMENT_OPERATION_COUNT = LIEN_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link asa.impl.GlueImpl <em>Glue</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see asa.impl.GlueImpl
	 * @see asa.impl.AsaPackageImpl#getGlue()
	 * @generated
	 */
	int GLUE = 5;

	/**
	 * The number of structural features of the '<em>Glue</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GLUE_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Glue</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GLUE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link asa.impl.RoleImpl <em>Role</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see asa.impl.RoleImpl
	 * @see asa.impl.AsaPackageImpl#getRole()
	 * @generated
	 */
	int ROLE = 19;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE__VALUE = 0;

	/**
	 * The number of structural features of the '<em>Role</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Role</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link asa.impl.RoleRequisImpl <em>Role Requis</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see asa.impl.RoleRequisImpl
	 * @see asa.impl.AsaPackageImpl#getRoleRequis()
	 * @generated
	 */
	int ROLE_REQUIS = 6;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE_REQUIS__VALUE = ROLE__VALUE;

	/**
	 * The number of structural features of the '<em>Role Requis</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE_REQUIS_FEATURE_COUNT = ROLE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Role Requis</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE_REQUIS_OPERATION_COUNT = ROLE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link asa.impl.RoleFourniImpl <em>Role Fourni</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see asa.impl.RoleFourniImpl
	 * @see asa.impl.AsaPackageImpl#getRoleFourni()
	 * @generated
	 */
	int ROLE_FOURNI = 7;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE_FOURNI__VALUE = ROLE__VALUE;

	/**
	 * The number of structural features of the '<em>Role Fourni</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE_FOURNI_FEATURE_COUNT = ROLE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Role Fourni</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE_FOURNI_OPERATION_COUNT = ROLE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link asa.impl.ComposantFeuilleImpl <em>Composant Feuille</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see asa.impl.ComposantFeuilleImpl
	 * @see asa.impl.AsaPackageImpl#getComposantFeuille()
	 * @generated
	 */
	int COMPOSANT_FEUILLE = 8;

	/**
	 * The feature id for the '<em><b>Propriete</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPOSANT_FEUILLE__PROPRIETE = COMPOSANT__PROPRIETE;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPOSANT_FEUILLE__NAME = COMPOSANT__NAME;

	/**
	 * The feature id for the '<em><b>Interfacecomposant</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPOSANT_FEUILLE__INTERFACECOMPOSANT = COMPOSANT_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Composant Feuille</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPOSANT_FEUILLE_FEATURE_COUNT = COMPOSANT_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Composant Feuille</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPOSANT_FEUILLE_OPERATION_COUNT = COMPOSANT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link asa.impl.ConnecteurFeuilleImpl <em>Connecteur Feuille</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see asa.impl.ConnecteurFeuilleImpl
	 * @see asa.impl.AsaPackageImpl#getConnecteurFeuille()
	 * @generated
	 */
	int CONNECTEUR_FEUILLE = 9;

	/**
	 * The feature id for the '<em><b>Propriete</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTEUR_FEUILLE__PROPRIETE = CONNECTEUR__PROPRIETE;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTEUR_FEUILLE__NAME = CONNECTEUR__NAME;

	/**
	 * The feature id for the '<em><b>Interfaceconnnecteur</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTEUR_FEUILLE__INTERFACECONNNECTEUR = CONNECTEUR_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Glue</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTEUR_FEUILLE__GLUE = CONNECTEUR_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Connecteur Feuille</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTEUR_FEUILLE_FEATURE_COUNT = CONNECTEUR_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Connecteur Feuille</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTEUR_FEUILLE_OPERATION_COUNT = CONNECTEUR_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link asa.impl.ServicesImpl <em>Services</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see asa.impl.ServicesImpl
	 * @see asa.impl.AsaPackageImpl#getServices()
	 * @generated
	 */
	int SERVICES = 15;

	/**
	 * The number of structural features of the '<em>Services</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVICES_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Services</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVICES_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link asa.impl.ServiceRequisImpl <em>Service Requis</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see asa.impl.ServiceRequisImpl
	 * @see asa.impl.AsaPackageImpl#getServiceRequis()
	 * @generated
	 */
	int SERVICE_REQUIS = 10;

	/**
	 * The number of structural features of the '<em>Service Requis</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVICE_REQUIS_FEATURE_COUNT = SERVICES_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Service Requis</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVICE_REQUIS_OPERATION_COUNT = SERVICES_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link asa.impl.ServiceFourniImpl <em>Service Fourni</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see asa.impl.ServiceFourniImpl
	 * @see asa.impl.AsaPackageImpl#getServiceFourni()
	 * @generated
	 */
	int SERVICE_FOURNI = 11;

	/**
	 * The number of structural features of the '<em>Service Fourni</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVICE_FOURNI_FEATURE_COUNT = SERVICES_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Service Fourni</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVICE_FOURNI_OPERATION_COUNT = SERVICES_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link asa.impl.PortsImpl <em>Ports</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see asa.impl.PortsImpl
	 * @see asa.impl.AsaPackageImpl#getPorts()
	 * @generated
	 */
	int PORTS = 16;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORTS__VALUE = 0;

	/**
	 * The number of structural features of the '<em>Ports</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORTS_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Ports</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORTS_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link asa.impl.PortsRequisImpl <em>Ports Requis</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see asa.impl.PortsRequisImpl
	 * @see asa.impl.AsaPackageImpl#getPortsRequis()
	 * @generated
	 */
	int PORTS_REQUIS = 12;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORTS_REQUIS__VALUE = PORTS__VALUE;

	/**
	 * The number of structural features of the '<em>Ports Requis</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORTS_REQUIS_FEATURE_COUNT = PORTS_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Ports Requis</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORTS_REQUIS_OPERATION_COUNT = PORTS_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link asa.impl.PortsFourniImpl <em>Ports Fourni</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see asa.impl.PortsFourniImpl
	 * @see asa.impl.AsaPackageImpl#getPortsFourni()
	 * @generated
	 */
	int PORTS_FOURNI = 13;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORTS_FOURNI__VALUE = PORTS__VALUE;

	/**
	 * The number of structural features of the '<em>Ports Fourni</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORTS_FOURNI_FEATURE_COUNT = PORTS_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Ports Fourni</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORTS_FOURNI_OPERATION_COUNT = PORTS_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link asa.impl.ComposantCompositeImpl <em>Composant Composite</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see asa.impl.ComposantCompositeImpl
	 * @see asa.impl.AsaPackageImpl#getComposantComposite()
	 * @generated
	 */
	int COMPOSANT_COMPOSITE = 14;

	/**
	 * The feature id for the '<em><b>Propriete</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPOSANT_COMPOSITE__PROPRIETE = COMPOSANT__PROPRIETE;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPOSANT_COMPOSITE__NAME = COMPOSANT__NAME;

	/**
	 * The feature id for the '<em><b>Configuration</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPOSANT_COMPOSITE__CONFIGURATION = COMPOSANT_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Composant Composite</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPOSANT_COMPOSITE_FEATURE_COUNT = COMPOSANT_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Composant Composite</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPOSANT_COMPOSITE_OPERATION_COUNT = COMPOSANT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link asa.impl.ConnecteurCompositeImpl <em>Connecteur Composite</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see asa.impl.ConnecteurCompositeImpl
	 * @see asa.impl.AsaPackageImpl#getConnecteurComposite()
	 * @generated
	 */
	int CONNECTEUR_COMPOSITE = 17;

	/**
	 * The feature id for the '<em><b>Propriete</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTEUR_COMPOSITE__PROPRIETE = CONNECTEUR__PROPRIETE;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTEUR_COMPOSITE__NAME = CONNECTEUR__NAME;

	/**
	 * The number of structural features of the '<em>Connecteur Composite</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTEUR_COMPOSITE_FEATURE_COUNT = CONNECTEUR_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Connecteur Composite</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTEUR_COMPOSITE_OPERATION_COUNT = CONNECTEUR_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link asa.InterfaceConnnecteur <em>Interface Connnecteur</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see asa.InterfaceConnnecteur
	 * @see asa.impl.AsaPackageImpl#getInterfaceConnnecteur()
	 * @generated
	 */
	int INTERFACE_CONNNECTEUR = 18;

	/**
	 * The feature id for the '<em><b>Role</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERFACE_CONNNECTEUR__ROLE = 0;

	/**
	 * The number of structural features of the '<em>Interface Connnecteur</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERFACE_CONNNECTEUR_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Interface Connnecteur</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERFACE_CONNNECTEUR_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link asa.InterfaceComposant <em>Interface Composant</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see asa.InterfaceComposant
	 * @see asa.impl.AsaPackageImpl#getInterfaceComposant()
	 * @generated
	 */
	int INTERFACE_COMPOSANT = 20;

	/**
	 * The feature id for the '<em><b>Service</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERFACE_COMPOSANT__SERVICE = 0;

	/**
	 * The feature id for the '<em><b>Port</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERFACE_COMPOSANT__PORT = 1;

	/**
	 * The number of structural features of the '<em>Interface Composant</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERFACE_COMPOSANT_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Interface Composant</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERFACE_COMPOSANT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link asa.impl.NewEClass25Impl <em>New EClass25</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see asa.impl.NewEClass25Impl
	 * @see asa.impl.AsaPackageImpl#getNewEClass25()
	 * @generated
	 */
	int NEW_ECLASS25 = 21;

	/**
	 * The number of structural features of the '<em>New EClass25</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NEW_ECLASS25_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>New EClass25</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NEW_ECLASS25_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link asa.impl.SystemImpl <em>System</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see asa.impl.SystemImpl
	 * @see asa.impl.AsaPackageImpl#getSystem()
	 * @generated
	 */
	int SYSTEM = 24;

	/**
	 * The feature id for the '<em><b>Element</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYSTEM__ELEMENT = 0;

	/**
	 * The number of structural features of the '<em>System</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYSTEM_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>System</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYSTEM_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link asa.impl.ProprieteImpl <em>Propriete</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see asa.impl.ProprieteImpl
	 * @see asa.impl.AsaPackageImpl#getPropriete()
	 * @generated
	 */
	int PROPRIETE = 25;

	/**
	 * The number of structural features of the '<em>Propriete</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROPRIETE_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Propriete</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROPRIETE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link asa.configurationInterface <em>configuration Interface</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see asa.configurationInterface
	 * @see asa.impl.AsaPackageImpl#getconfigurationInterface()
	 * @generated
	 */
	int CONFIGURATION_INTERFACE = 26;

	/**
	 * The feature id for the '<em><b>Portconfig</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONFIGURATION_INTERFACE__PORTCONFIG = 0;

	/**
	 * The number of structural features of the '<em>configuration Interface</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONFIGURATION_INTERFACE_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>configuration Interface</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONFIGURATION_INTERFACE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link asa.impl.PortConfigImpl <em>Port Config</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see asa.impl.PortConfigImpl
	 * @see asa.impl.AsaPackageImpl#getPortConfig()
	 * @generated
	 */
	int PORT_CONFIG = 27;

	/**
	 * The number of structural features of the '<em>Port Config</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORT_CONFIG_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Port Config</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORT_CONFIG_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link asa.impl.PortConfigFournisImpl <em>Port Config Fournis</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see asa.impl.PortConfigFournisImpl
	 * @see asa.impl.AsaPackageImpl#getPortConfigFournis()
	 * @generated
	 */
	int PORT_CONFIG_FOURNIS = 28;

	/**
	 * The number of structural features of the '<em>Port Config Fournis</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORT_CONFIG_FOURNIS_FEATURE_COUNT = PORT_CONFIG_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Port Config Fournis</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORT_CONFIG_FOURNIS_OPERATION_COUNT = PORT_CONFIG_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link asa.impl.PortConfigRequisImpl <em>Port Config Requis</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see asa.impl.PortConfigRequisImpl
	 * @see asa.impl.AsaPackageImpl#getPortConfigRequis()
	 * @generated
	 */
	int PORT_CONFIG_REQUIS = 29;

	/**
	 * The number of structural features of the '<em>Port Config Requis</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORT_CONFIG_REQUIS_FEATURE_COUNT = PORT_CONFIG_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Port Config Requis</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORT_CONFIG_REQUIS_OPERATION_COUNT = PORT_CONFIG_OPERATION_COUNT + 0;

	/**
	 * Returns the meta object for class '{@link asa.Composant <em>Composant</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Composant</em>'.
	 * @see asa.Composant
	 * @generated
	 */
	EClass getComposant();

	/**
	 * Returns the meta object for class '{@link asa.Configuration <em>Configuration</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Configuration</em>'.
	 * @see asa.Configuration
	 * @generated
	 */
	EClass getConfiguration();

	/**
	 * Returns the meta object for the containment reference list '{@link asa.Configuration#getComposant <em>Composant</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Composant</em>'.
	 * @see asa.Configuration#getComposant()
	 * @see #getConfiguration()
	 * @generated
	 */
	EReference getConfiguration_Composant();

	/**
	 * Returns the meta object for the containment reference list '{@link asa.Configuration#getConnecteur <em>Connecteur</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Connecteur</em>'.
	 * @see asa.Configuration#getConnecteur()
	 * @see #getConfiguration()
	 * @generated
	 */
	EReference getConfiguration_Connecteur();

	/**
	 * Returns the meta object for the containment reference list '{@link asa.Configuration#getLien <em>Lien</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Lien</em>'.
	 * @see asa.Configuration#getLien()
	 * @see #getConfiguration()
	 * @generated
	 */
	EReference getConfiguration_Lien();

	/**
	 * Returns the meta object for the containment reference list '{@link asa.Configuration#getConfigurationinterface <em>Configurationinterface</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Configurationinterface</em>'.
	 * @see asa.Configuration#getConfigurationinterface()
	 * @see #getConfiguration()
	 * @generated
	 */
	EReference getConfiguration_Configurationinterface();

	/**
	 * Returns the meta object for class '{@link asa.Connecteur <em>Connecteur</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Connecteur</em>'.
	 * @see asa.Connecteur
	 * @generated
	 */
	EClass getConnecteur();

	/**
	 * Returns the meta object for class '{@link asa.Binding <em>Binding</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Binding</em>'.
	 * @see asa.Binding
	 * @generated
	 */
	EClass getBinding();

	/**
	 * Returns the meta object for the reference '{@link asa.Binding#getPortconfigfournis <em>Portconfigfournis</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Portconfigfournis</em>'.
	 * @see asa.Binding#getPortconfigfournis()
	 * @see #getBinding()
	 * @generated
	 */
	EReference getBinding_Portconfigfournis();

	/**
	 * Returns the meta object for the reference '{@link asa.Binding#getPortconfigrequis <em>Portconfigrequis</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Portconfigrequis</em>'.
	 * @see asa.Binding#getPortconfigrequis()
	 * @see #getBinding()
	 * @generated
	 */
	EReference getBinding_Portconfigrequis();

	/**
	 * Returns the meta object for the reference '{@link asa.Binding#getPortsfourni <em>Portsfourni</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Portsfourni</em>'.
	 * @see asa.Binding#getPortsfourni()
	 * @see #getBinding()
	 * @generated
	 */
	EReference getBinding_Portsfourni();

	/**
	 * Returns the meta object for the reference '{@link asa.Binding#getPortsrequis <em>Portsrequis</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Portsrequis</em>'.
	 * @see asa.Binding#getPortsrequis()
	 * @see #getBinding()
	 * @generated
	 */
	EReference getBinding_Portsrequis();

	/**
	 * Returns the meta object for class '{@link asa.Attachement <em>Attachement</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Attachement</em>'.
	 * @see asa.Attachement
	 * @generated
	 */
	EClass getAttachement();

	/**
	 * Returns the meta object for the reference '{@link asa.Attachement#getRolefourni <em>Rolefourni</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Rolefourni</em>'.
	 * @see asa.Attachement#getRolefourni()
	 * @see #getAttachement()
	 * @generated
	 */
	EReference getAttachement_Rolefourni();

	/**
	 * Returns the meta object for the reference '{@link asa.Attachement#getRolerequis <em>Rolerequis</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Rolerequis</em>'.
	 * @see asa.Attachement#getRolerequis()
	 * @see #getAttachement()
	 * @generated
	 */
	EReference getAttachement_Rolerequis();

	/**
	 * Returns the meta object for the reference '{@link asa.Attachement#getPortsfourni <em>Portsfourni</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Portsfourni</em>'.
	 * @see asa.Attachement#getPortsfourni()
	 * @see #getAttachement()
	 * @generated
	 */
	EReference getAttachement_Portsfourni();

	/**
	 * Returns the meta object for the reference '{@link asa.Attachement#getPortrequis <em>Portrequis</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Portrequis</em>'.
	 * @see asa.Attachement#getPortrequis()
	 * @see #getAttachement()
	 * @generated
	 */
	EReference getAttachement_Portrequis();

	/**
	 * Returns the meta object for class '{@link asa.Glue <em>Glue</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Glue</em>'.
	 * @see asa.Glue
	 * @generated
	 */
	EClass getGlue();

	/**
	 * Returns the meta object for class '{@link asa.RoleRequis <em>Role Requis</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Role Requis</em>'.
	 * @see asa.RoleRequis
	 * @generated
	 */
	EClass getRoleRequis();

	/**
	 * Returns the meta object for class '{@link asa.RoleFourni <em>Role Fourni</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Role Fourni</em>'.
	 * @see asa.RoleFourni
	 * @generated
	 */
	EClass getRoleFourni();

	/**
	 * Returns the meta object for class '{@link asa.ComposantFeuille <em>Composant Feuille</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Composant Feuille</em>'.
	 * @see asa.ComposantFeuille
	 * @generated
	 */
	EClass getComposantFeuille();

	/**
	 * Returns the meta object for the containment reference list '{@link asa.ComposantFeuille#getInterfacecomposant <em>Interfacecomposant</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Interfacecomposant</em>'.
	 * @see asa.ComposantFeuille#getInterfacecomposant()
	 * @see #getComposantFeuille()
	 * @generated
	 */
	EReference getComposantFeuille_Interfacecomposant();

	/**
	 * Returns the meta object for class '{@link asa.ConnecteurFeuille <em>Connecteur Feuille</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Connecteur Feuille</em>'.
	 * @see asa.ConnecteurFeuille
	 * @generated
	 */
	EClass getConnecteurFeuille();

	/**
	 * Returns the meta object for the containment reference list '{@link asa.ConnecteurFeuille#getInterfaceconnnecteur <em>Interfaceconnnecteur</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Interfaceconnnecteur</em>'.
	 * @see asa.ConnecteurFeuille#getInterfaceconnnecteur()
	 * @see #getConnecteurFeuille()
	 * @generated
	 */
	EReference getConnecteurFeuille_Interfaceconnnecteur();

	/**
	 * Returns the meta object for the containment reference '{@link asa.ConnecteurFeuille#getGlue <em>Glue</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Glue</em>'.
	 * @see asa.ConnecteurFeuille#getGlue()
	 * @see #getConnecteurFeuille()
	 * @generated
	 */
	EReference getConnecteurFeuille_Glue();

	/**
	 * Returns the meta object for class '{@link asa.ServiceRequis <em>Service Requis</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Service Requis</em>'.
	 * @see asa.ServiceRequis
	 * @generated
	 */
	EClass getServiceRequis();

	/**
	 * Returns the meta object for class '{@link asa.ServiceFourni <em>Service Fourni</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Service Fourni</em>'.
	 * @see asa.ServiceFourni
	 * @generated
	 */
	EClass getServiceFourni();

	/**
	 * Returns the meta object for class '{@link asa.PortsRequis <em>Ports Requis</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Ports Requis</em>'.
	 * @see asa.PortsRequis
	 * @generated
	 */
	EClass getPortsRequis();

	/**
	 * Returns the meta object for class '{@link asa.PortsFourni <em>Ports Fourni</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Ports Fourni</em>'.
	 * @see asa.PortsFourni
	 * @generated
	 */
	EClass getPortsFourni();

	/**
	 * Returns the meta object for class '{@link asa.ComposantComposite <em>Composant Composite</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Composant Composite</em>'.
	 * @see asa.ComposantComposite
	 * @generated
	 */
	EClass getComposantComposite();

	/**
	 * Returns the meta object for the containment reference '{@link asa.ComposantComposite#getConfiguration <em>Configuration</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Configuration</em>'.
	 * @see asa.ComposantComposite#getConfiguration()
	 * @see #getComposantComposite()
	 * @generated
	 */
	EReference getComposantComposite_Configuration();

	/**
	 * Returns the meta object for class '{@link asa.Services <em>Services</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Services</em>'.
	 * @see asa.Services
	 * @generated
	 */
	EClass getServices();

	/**
	 * Returns the meta object for class '{@link asa.Ports <em>Ports</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Ports</em>'.
	 * @see asa.Ports
	 * @generated
	 */
	EClass getPorts();

	/**
	 * Returns the meta object for the attribute '{@link asa.Ports#getValue <em>Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Value</em>'.
	 * @see asa.Ports#getValue()
	 * @see #getPorts()
	 * @generated
	 */
	EAttribute getPorts_Value();

	/**
	 * Returns the meta object for class '{@link asa.ConnecteurComposite <em>Connecteur Composite</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Connecteur Composite</em>'.
	 * @see asa.ConnecteurComposite
	 * @generated
	 */
	EClass getConnecteurComposite();

	/**
	 * Returns the meta object for class '{@link asa.InterfaceConnnecteur <em>Interface Connnecteur</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Interface Connnecteur</em>'.
	 * @see asa.InterfaceConnnecteur
	 * @generated
	 */
	EClass getInterfaceConnnecteur();

	/**
	 * Returns the meta object for the containment reference list '{@link asa.InterfaceConnnecteur#getRole <em>Role</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Role</em>'.
	 * @see asa.InterfaceConnnecteur#getRole()
	 * @see #getInterfaceConnnecteur()
	 * @generated
	 */
	EReference getInterfaceConnnecteur_Role();

	/**
	 * Returns the meta object for class '{@link asa.Role <em>Role</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Role</em>'.
	 * @see asa.Role
	 * @generated
	 */
	EClass getRole();

	/**
	 * Returns the meta object for the attribute '{@link asa.Role#getValue <em>Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Value</em>'.
	 * @see asa.Role#getValue()
	 * @see #getRole()
	 * @generated
	 */
	EAttribute getRole_Value();

	/**
	 * Returns the meta object for class '{@link asa.InterfaceComposant <em>Interface Composant</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Interface Composant</em>'.
	 * @see asa.InterfaceComposant
	 * @generated
	 */
	EClass getInterfaceComposant();

	/**
	 * Returns the meta object for the containment reference list '{@link asa.InterfaceComposant#getService <em>Service</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Service</em>'.
	 * @see asa.InterfaceComposant#getService()
	 * @see #getInterfaceComposant()
	 * @generated
	 */
	EReference getInterfaceComposant_Service();

	/**
	 * Returns the meta object for the containment reference list '{@link asa.InterfaceComposant#getPort <em>Port</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Port</em>'.
	 * @see asa.InterfaceComposant#getPort()
	 * @see #getInterfaceComposant()
	 * @generated
	 */
	EReference getInterfaceComposant_Port();

	/**
	 * Returns the meta object for class '{@link asa.NewEClass25 <em>New EClass25</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>New EClass25</em>'.
	 * @see asa.NewEClass25
	 * @generated
	 */
	EClass getNewEClass25();

	/**
	 * Returns the meta object for class '{@link asa.Lien <em>Lien</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Lien</em>'.
	 * @see asa.Lien
	 * @generated
	 */
	EClass getLien();

	/**
	 * Returns the meta object for class '{@link asa.element <em>element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>element</em>'.
	 * @see asa.element
	 * @generated
	 */
	EClass getelement();

	/**
	 * Returns the meta object for the containment reference list '{@link asa.element#getPropriete <em>Propriete</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Propriete</em>'.
	 * @see asa.element#getPropriete()
	 * @see #getelement()
	 * @generated
	 */
	EReference getelement_Propriete();

	/**
	 * Returns the meta object for the attribute '{@link asa.element#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see asa.element#getName()
	 * @see #getelement()
	 * @generated
	 */
	EAttribute getelement_Name();

	/**
	 * Returns the meta object for class '{@link asa.System <em>System</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>System</em>'.
	 * @see asa.System
	 * @generated
	 */
	EClass getSystem();

	/**
	 * Returns the meta object for the containment reference list '{@link asa.System#getElement <em>Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Element</em>'.
	 * @see asa.System#getElement()
	 * @see #getSystem()
	 * @generated
	 */
	EReference getSystem_Element();

	/**
	 * Returns the meta object for class '{@link asa.Propriete <em>Propriete</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Propriete</em>'.
	 * @see asa.Propriete
	 * @generated
	 */
	EClass getPropriete();

	/**
	 * Returns the meta object for class '{@link asa.configurationInterface <em>configuration Interface</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>configuration Interface</em>'.
	 * @see asa.configurationInterface
	 * @generated
	 */
	EClass getconfigurationInterface();

	/**
	 * Returns the meta object for the containment reference list '{@link asa.configurationInterface#getPortconfig <em>Portconfig</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Portconfig</em>'.
	 * @see asa.configurationInterface#getPortconfig()
	 * @see #getconfigurationInterface()
	 * @generated
	 */
	EReference getconfigurationInterface_Portconfig();

	/**
	 * Returns the meta object for class '{@link asa.PortConfig <em>Port Config</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Port Config</em>'.
	 * @see asa.PortConfig
	 * @generated
	 */
	EClass getPortConfig();

	/**
	 * Returns the meta object for class '{@link asa.PortConfigFournis <em>Port Config Fournis</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Port Config Fournis</em>'.
	 * @see asa.PortConfigFournis
	 * @generated
	 */
	EClass getPortConfigFournis();

	/**
	 * Returns the meta object for class '{@link asa.PortConfigRequis <em>Port Config Requis</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Port Config Requis</em>'.
	 * @see asa.PortConfigRequis
	 * @generated
	 */
	EClass getPortConfigRequis();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	AsaFactory getAsaFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link asa.impl.ComposantImpl <em>Composant</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see asa.impl.ComposantImpl
		 * @see asa.impl.AsaPackageImpl#getComposant()
		 * @generated
		 */
		EClass COMPOSANT = eINSTANCE.getComposant();

		/**
		 * The meta object literal for the '{@link asa.impl.ConfigurationImpl <em>Configuration</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see asa.impl.ConfigurationImpl
		 * @see asa.impl.AsaPackageImpl#getConfiguration()
		 * @generated
		 */
		EClass CONFIGURATION = eINSTANCE.getConfiguration();

		/**
		 * The meta object literal for the '<em><b>Composant</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONFIGURATION__COMPOSANT = eINSTANCE.getConfiguration_Composant();

		/**
		 * The meta object literal for the '<em><b>Connecteur</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONFIGURATION__CONNECTEUR = eINSTANCE.getConfiguration_Connecteur();

		/**
		 * The meta object literal for the '<em><b>Lien</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONFIGURATION__LIEN = eINSTANCE.getConfiguration_Lien();

		/**
		 * The meta object literal for the '<em><b>Configurationinterface</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONFIGURATION__CONFIGURATIONINTERFACE = eINSTANCE.getConfiguration_Configurationinterface();

		/**
		 * The meta object literal for the '{@link asa.impl.ConnecteurImpl <em>Connecteur</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see asa.impl.ConnecteurImpl
		 * @see asa.impl.AsaPackageImpl#getConnecteur()
		 * @generated
		 */
		EClass CONNECTEUR = eINSTANCE.getConnecteur();

		/**
		 * The meta object literal for the '{@link asa.impl.BindingImpl <em>Binding</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see asa.impl.BindingImpl
		 * @see asa.impl.AsaPackageImpl#getBinding()
		 * @generated
		 */
		EClass BINDING = eINSTANCE.getBinding();

		/**
		 * The meta object literal for the '<em><b>Portconfigfournis</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BINDING__PORTCONFIGFOURNIS = eINSTANCE.getBinding_Portconfigfournis();

		/**
		 * The meta object literal for the '<em><b>Portconfigrequis</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BINDING__PORTCONFIGREQUIS = eINSTANCE.getBinding_Portconfigrequis();

		/**
		 * The meta object literal for the '<em><b>Portsfourni</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BINDING__PORTSFOURNI = eINSTANCE.getBinding_Portsfourni();

		/**
		 * The meta object literal for the '<em><b>Portsrequis</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BINDING__PORTSREQUIS = eINSTANCE.getBinding_Portsrequis();

		/**
		 * The meta object literal for the '{@link asa.impl.AttachementImpl <em>Attachement</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see asa.impl.AttachementImpl
		 * @see asa.impl.AsaPackageImpl#getAttachement()
		 * @generated
		 */
		EClass ATTACHEMENT = eINSTANCE.getAttachement();

		/**
		 * The meta object literal for the '<em><b>Rolefourni</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ATTACHEMENT__ROLEFOURNI = eINSTANCE.getAttachement_Rolefourni();

		/**
		 * The meta object literal for the '<em><b>Rolerequis</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ATTACHEMENT__ROLEREQUIS = eINSTANCE.getAttachement_Rolerequis();

		/**
		 * The meta object literal for the '<em><b>Portsfourni</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ATTACHEMENT__PORTSFOURNI = eINSTANCE.getAttachement_Portsfourni();

		/**
		 * The meta object literal for the '<em><b>Portrequis</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ATTACHEMENT__PORTREQUIS = eINSTANCE.getAttachement_Portrequis();

		/**
		 * The meta object literal for the '{@link asa.impl.GlueImpl <em>Glue</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see asa.impl.GlueImpl
		 * @see asa.impl.AsaPackageImpl#getGlue()
		 * @generated
		 */
		EClass GLUE = eINSTANCE.getGlue();

		/**
		 * The meta object literal for the '{@link asa.impl.RoleRequisImpl <em>Role Requis</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see asa.impl.RoleRequisImpl
		 * @see asa.impl.AsaPackageImpl#getRoleRequis()
		 * @generated
		 */
		EClass ROLE_REQUIS = eINSTANCE.getRoleRequis();

		/**
		 * The meta object literal for the '{@link asa.impl.RoleFourniImpl <em>Role Fourni</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see asa.impl.RoleFourniImpl
		 * @see asa.impl.AsaPackageImpl#getRoleFourni()
		 * @generated
		 */
		EClass ROLE_FOURNI = eINSTANCE.getRoleFourni();

		/**
		 * The meta object literal for the '{@link asa.impl.ComposantFeuilleImpl <em>Composant Feuille</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see asa.impl.ComposantFeuilleImpl
		 * @see asa.impl.AsaPackageImpl#getComposantFeuille()
		 * @generated
		 */
		EClass COMPOSANT_FEUILLE = eINSTANCE.getComposantFeuille();

		/**
		 * The meta object literal for the '<em><b>Interfacecomposant</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COMPOSANT_FEUILLE__INTERFACECOMPOSANT = eINSTANCE.getComposantFeuille_Interfacecomposant();

		/**
		 * The meta object literal for the '{@link asa.impl.ConnecteurFeuilleImpl <em>Connecteur Feuille</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see asa.impl.ConnecteurFeuilleImpl
		 * @see asa.impl.AsaPackageImpl#getConnecteurFeuille()
		 * @generated
		 */
		EClass CONNECTEUR_FEUILLE = eINSTANCE.getConnecteurFeuille();

		/**
		 * The meta object literal for the '<em><b>Interfaceconnnecteur</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONNECTEUR_FEUILLE__INTERFACECONNNECTEUR = eINSTANCE.getConnecteurFeuille_Interfaceconnnecteur();

		/**
		 * The meta object literal for the '<em><b>Glue</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONNECTEUR_FEUILLE__GLUE = eINSTANCE.getConnecteurFeuille_Glue();

		/**
		 * The meta object literal for the '{@link asa.impl.ServiceRequisImpl <em>Service Requis</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see asa.impl.ServiceRequisImpl
		 * @see asa.impl.AsaPackageImpl#getServiceRequis()
		 * @generated
		 */
		EClass SERVICE_REQUIS = eINSTANCE.getServiceRequis();

		/**
		 * The meta object literal for the '{@link asa.impl.ServiceFourniImpl <em>Service Fourni</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see asa.impl.ServiceFourniImpl
		 * @see asa.impl.AsaPackageImpl#getServiceFourni()
		 * @generated
		 */
		EClass SERVICE_FOURNI = eINSTANCE.getServiceFourni();

		/**
		 * The meta object literal for the '{@link asa.impl.PortsRequisImpl <em>Ports Requis</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see asa.impl.PortsRequisImpl
		 * @see asa.impl.AsaPackageImpl#getPortsRequis()
		 * @generated
		 */
		EClass PORTS_REQUIS = eINSTANCE.getPortsRequis();

		/**
		 * The meta object literal for the '{@link asa.impl.PortsFourniImpl <em>Ports Fourni</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see asa.impl.PortsFourniImpl
		 * @see asa.impl.AsaPackageImpl#getPortsFourni()
		 * @generated
		 */
		EClass PORTS_FOURNI = eINSTANCE.getPortsFourni();

		/**
		 * The meta object literal for the '{@link asa.impl.ComposantCompositeImpl <em>Composant Composite</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see asa.impl.ComposantCompositeImpl
		 * @see asa.impl.AsaPackageImpl#getComposantComposite()
		 * @generated
		 */
		EClass COMPOSANT_COMPOSITE = eINSTANCE.getComposantComposite();

		/**
		 * The meta object literal for the '<em><b>Configuration</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COMPOSANT_COMPOSITE__CONFIGURATION = eINSTANCE.getComposantComposite_Configuration();

		/**
		 * The meta object literal for the '{@link asa.impl.ServicesImpl <em>Services</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see asa.impl.ServicesImpl
		 * @see asa.impl.AsaPackageImpl#getServices()
		 * @generated
		 */
		EClass SERVICES = eINSTANCE.getServices();

		/**
		 * The meta object literal for the '{@link asa.impl.PortsImpl <em>Ports</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see asa.impl.PortsImpl
		 * @see asa.impl.AsaPackageImpl#getPorts()
		 * @generated
		 */
		EClass PORTS = eINSTANCE.getPorts();

		/**
		 * The meta object literal for the '<em><b>Value</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PORTS__VALUE = eINSTANCE.getPorts_Value();

		/**
		 * The meta object literal for the '{@link asa.impl.ConnecteurCompositeImpl <em>Connecteur Composite</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see asa.impl.ConnecteurCompositeImpl
		 * @see asa.impl.AsaPackageImpl#getConnecteurComposite()
		 * @generated
		 */
		EClass CONNECTEUR_COMPOSITE = eINSTANCE.getConnecteurComposite();

		/**
		 * The meta object literal for the '{@link asa.InterfaceConnnecteur <em>Interface Connnecteur</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see asa.InterfaceConnnecteur
		 * @see asa.impl.AsaPackageImpl#getInterfaceConnnecteur()
		 * @generated
		 */
		EClass INTERFACE_CONNNECTEUR = eINSTANCE.getInterfaceConnnecteur();

		/**
		 * The meta object literal for the '<em><b>Role</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INTERFACE_CONNNECTEUR__ROLE = eINSTANCE.getInterfaceConnnecteur_Role();

		/**
		 * The meta object literal for the '{@link asa.impl.RoleImpl <em>Role</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see asa.impl.RoleImpl
		 * @see asa.impl.AsaPackageImpl#getRole()
		 * @generated
		 */
		EClass ROLE = eINSTANCE.getRole();

		/**
		 * The meta object literal for the '<em><b>Value</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ROLE__VALUE = eINSTANCE.getRole_Value();

		/**
		 * The meta object literal for the '{@link asa.InterfaceComposant <em>Interface Composant</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see asa.InterfaceComposant
		 * @see asa.impl.AsaPackageImpl#getInterfaceComposant()
		 * @generated
		 */
		EClass INTERFACE_COMPOSANT = eINSTANCE.getInterfaceComposant();

		/**
		 * The meta object literal for the '<em><b>Service</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INTERFACE_COMPOSANT__SERVICE = eINSTANCE.getInterfaceComposant_Service();

		/**
		 * The meta object literal for the '<em><b>Port</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INTERFACE_COMPOSANT__PORT = eINSTANCE.getInterfaceComposant_Port();

		/**
		 * The meta object literal for the '{@link asa.impl.NewEClass25Impl <em>New EClass25</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see asa.impl.NewEClass25Impl
		 * @see asa.impl.AsaPackageImpl#getNewEClass25()
		 * @generated
		 */
		EClass NEW_ECLASS25 = eINSTANCE.getNewEClass25();

		/**
		 * The meta object literal for the '{@link asa.impl.LienImpl <em>Lien</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see asa.impl.LienImpl
		 * @see asa.impl.AsaPackageImpl#getLien()
		 * @generated
		 */
		EClass LIEN = eINSTANCE.getLien();

		/**
		 * The meta object literal for the '{@link asa.impl.elementImpl <em>element</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see asa.impl.elementImpl
		 * @see asa.impl.AsaPackageImpl#getelement()
		 * @generated
		 */
		EClass ELEMENT = eINSTANCE.getelement();

		/**
		 * The meta object literal for the '<em><b>Propriete</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ELEMENT__PROPRIETE = eINSTANCE.getelement_Propriete();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ELEMENT__NAME = eINSTANCE.getelement_Name();

		/**
		 * The meta object literal for the '{@link asa.impl.SystemImpl <em>System</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see asa.impl.SystemImpl
		 * @see asa.impl.AsaPackageImpl#getSystem()
		 * @generated
		 */
		EClass SYSTEM = eINSTANCE.getSystem();

		/**
		 * The meta object literal for the '<em><b>Element</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SYSTEM__ELEMENT = eINSTANCE.getSystem_Element();

		/**
		 * The meta object literal for the '{@link asa.impl.ProprieteImpl <em>Propriete</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see asa.impl.ProprieteImpl
		 * @see asa.impl.AsaPackageImpl#getPropriete()
		 * @generated
		 */
		EClass PROPRIETE = eINSTANCE.getPropriete();

		/**
		 * The meta object literal for the '{@link asa.configurationInterface <em>configuration Interface</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see asa.configurationInterface
		 * @see asa.impl.AsaPackageImpl#getconfigurationInterface()
		 * @generated
		 */
		EClass CONFIGURATION_INTERFACE = eINSTANCE.getconfigurationInterface();

		/**
		 * The meta object literal for the '<em><b>Portconfig</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONFIGURATION_INTERFACE__PORTCONFIG = eINSTANCE.getconfigurationInterface_Portconfig();

		/**
		 * The meta object literal for the '{@link asa.impl.PortConfigImpl <em>Port Config</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see asa.impl.PortConfigImpl
		 * @see asa.impl.AsaPackageImpl#getPortConfig()
		 * @generated
		 */
		EClass PORT_CONFIG = eINSTANCE.getPortConfig();

		/**
		 * The meta object literal for the '{@link asa.impl.PortConfigFournisImpl <em>Port Config Fournis</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see asa.impl.PortConfigFournisImpl
		 * @see asa.impl.AsaPackageImpl#getPortConfigFournis()
		 * @generated
		 */
		EClass PORT_CONFIG_FOURNIS = eINSTANCE.getPortConfigFournis();

		/**
		 * The meta object literal for the '{@link asa.impl.PortConfigRequisImpl <em>Port Config Requis</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see asa.impl.PortConfigRequisImpl
		 * @see asa.impl.AsaPackageImpl#getPortConfigRequis()
		 * @generated
		 */
		EClass PORT_CONFIG_REQUIS = eINSTANCE.getPortConfigRequis();

	}

} //AsaPackage

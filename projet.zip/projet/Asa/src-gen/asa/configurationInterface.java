/**
 */
package asa;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>configuration Interface</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link asa.configurationInterface#getPortconfig <em>Portconfig</em>}</li>
 * </ul>
 *
 * @see asa.AsaPackage#getconfigurationInterface()
 * @model interface="true" abstract="true"
 * @generated
 */
public interface configurationInterface extends EObject {
	/**
	 * Returns the value of the '<em><b>Portconfig</b></em>' containment reference list.
	 * The list contents are of type {@link asa.PortConfig}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Portconfig</em>' containment reference list.
	 * @see asa.AsaPackage#getconfigurationInterface_Portconfig()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<PortConfig> getPortconfig();

} // configurationInterface

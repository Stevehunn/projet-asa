/**
 */
package asa;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Interface Connnecteur</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link asa.InterfaceConnnecteur#getRole <em>Role</em>}</li>
 * </ul>
 *
 * @see asa.AsaPackage#getInterfaceConnnecteur()
 * @model interface="true" abstract="true"
 * @generated
 */
public interface InterfaceConnnecteur extends EObject {
	/**
	 * Returns the value of the '<em><b>Role</b></em>' containment reference list.
	 * The list contents are of type {@link asa.Role}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Role</em>' containment reference list.
	 * @see asa.AsaPackage#getInterfaceConnnecteur_Role()
	 * @model containment="true"
	 * @generated
	 */
	EList<Role> getRole();

} // InterfaceConnnecteur

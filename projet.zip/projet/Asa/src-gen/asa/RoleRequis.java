/**
 */
package asa;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Role Requis</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see asa.AsaPackage#getRoleRequis()
 * @model
 * @generated
 */
public interface RoleRequis extends Role {
} // RoleRequis

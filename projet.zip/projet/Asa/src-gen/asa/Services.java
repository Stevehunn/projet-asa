/**
 */
package asa;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Services</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see asa.AsaPackage#getServices()
 * @model abstract="true"
 * @generated
 */
public interface Services extends EObject {
} // Services

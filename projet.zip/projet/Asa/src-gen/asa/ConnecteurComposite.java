/**
 */
package asa;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Connecteur Composite</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see asa.AsaPackage#getConnecteurComposite()
 * @model abstract="true"
 * @generated
 */
public interface ConnecteurComposite extends Connecteur {
} // ConnecteurComposite

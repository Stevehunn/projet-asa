/**
 */
package asa;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Ports Requis</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see asa.AsaPackage#getPortsRequis()
 * @model
 * @generated
 */
public interface PortsRequis extends Ports {
} // PortsRequis

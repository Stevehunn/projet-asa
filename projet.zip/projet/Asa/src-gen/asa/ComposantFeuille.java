/**
 */
package asa;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Composant Feuille</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link asa.ComposantFeuille#getInterfacecomposant <em>Interfacecomposant</em>}</li>
 * </ul>
 *
 * @see asa.AsaPackage#getComposantFeuille()
 * @model
 * @generated
 */
public interface ComposantFeuille extends Composant {
	/**
	 * Returns the value of the '<em><b>Interfacecomposant</b></em>' containment reference list.
	 * The list contents are of type {@link asa.InterfaceComposant}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Interfacecomposant</em>' containment reference list.
	 * @see asa.AsaPackage#getComposantFeuille_Interfacecomposant()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<InterfaceComposant> getInterfacecomposant();

} // ComposantFeuille

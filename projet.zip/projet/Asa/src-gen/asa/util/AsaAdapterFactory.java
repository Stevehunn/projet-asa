/**
 */
package asa.util;

import asa.AsaPackage;
import asa.Attachement;
import asa.Binding;
import asa.Composant;
import asa.ComposantComposite;
import asa.ComposantFeuille;
import asa.Configuration;
import asa.Connecteur;
import asa.ConnecteurComposite;
import asa.ConnecteurFeuille;
import asa.Glue;
import asa.InterfaceComposant;
import asa.InterfaceConnnecteur;
import asa.Lien;
import asa.NewEClass25;
import asa.PortConfig;
import asa.PortConfigFournis;
import asa.PortConfigRequis;
import asa.Ports;
import asa.PortsFourni;
import asa.PortsRequis;
import asa.Propriete;
import asa.Role;
import asa.RoleFourni;
import asa.RoleRequis;
import asa.ServiceFourni;
import asa.ServiceRequis;
import asa.Services;
import asa.configurationInterface;
import asa.element;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see asa.AsaPackage
 * @generated
 */
public class AsaAdapterFactory extends AdapterFactoryImpl {
	/**
	 * The cached model package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static AsaPackage modelPackage;

	/**
	 * Creates an instance of the adapter factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AsaAdapterFactory() {
		if (modelPackage == null) {
			modelPackage = AsaPackage.eINSTANCE;
		}
	}

	/**
	 * Returns whether this factory is applicable for the type of the object.
	 * <!-- begin-user-doc -->
	 * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
	 * <!-- end-user-doc -->
	 * @return whether this factory is applicable for the type of the object.
	 * @generated
	 */
	@Override
	public boolean isFactoryForType(Object object) {
		if (object == modelPackage) {
			return true;
		}
		if (object instanceof EObject) {
			return ((EObject) object).eClass().getEPackage() == modelPackage;
		}
		return false;
	}

	/**
	 * The switch that delegates to the <code>createXXX</code> methods.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AsaSwitch<Adapter> modelSwitch = new AsaSwitch<Adapter>() {
		@Override
		public Adapter caseComposant(Composant object) {
			return createComposantAdapter();
		}

		@Override
		public Adapter caseConfiguration(Configuration object) {
			return createConfigurationAdapter();
		}

		@Override
		public Adapter caseConnecteur(Connecteur object) {
			return createConnecteurAdapter();
		}

		@Override
		public Adapter caseBinding(Binding object) {
			return createBindingAdapter();
		}

		@Override
		public Adapter caseAttachement(Attachement object) {
			return createAttachementAdapter();
		}

		@Override
		public Adapter caseGlue(Glue object) {
			return createGlueAdapter();
		}

		@Override
		public Adapter caseRoleRequis(RoleRequis object) {
			return createRoleRequisAdapter();
		}

		@Override
		public Adapter caseRoleFourni(RoleFourni object) {
			return createRoleFourniAdapter();
		}

		@Override
		public Adapter caseComposantFeuille(ComposantFeuille object) {
			return createComposantFeuilleAdapter();
		}

		@Override
		public Adapter caseConnecteurFeuille(ConnecteurFeuille object) {
			return createConnecteurFeuilleAdapter();
		}

		@Override
		public Adapter caseServiceRequis(ServiceRequis object) {
			return createServiceRequisAdapter();
		}

		@Override
		public Adapter caseServiceFourni(ServiceFourni object) {
			return createServiceFourniAdapter();
		}

		@Override
		public Adapter casePortsRequis(PortsRequis object) {
			return createPortsRequisAdapter();
		}

		@Override
		public Adapter casePortsFourni(PortsFourni object) {
			return createPortsFourniAdapter();
		}

		@Override
		public Adapter caseComposantComposite(ComposantComposite object) {
			return createComposantCompositeAdapter();
		}

		@Override
		public Adapter caseServices(Services object) {
			return createServicesAdapter();
		}

		@Override
		public Adapter casePorts(Ports object) {
			return createPortsAdapter();
		}

		@Override
		public Adapter caseConnecteurComposite(ConnecteurComposite object) {
			return createConnecteurCompositeAdapter();
		}

		@Override
		public Adapter caseInterfaceConnnecteur(InterfaceConnnecteur object) {
			return createInterfaceConnnecteurAdapter();
		}

		@Override
		public Adapter caseRole(Role object) {
			return createRoleAdapter();
		}

		@Override
		public Adapter caseInterfaceComposant(InterfaceComposant object) {
			return createInterfaceComposantAdapter();
		}

		@Override
		public Adapter caseNewEClass25(NewEClass25 object) {
			return createNewEClass25Adapter();
		}

		@Override
		public Adapter caseLien(Lien object) {
			return createLienAdapter();
		}

		@Override
		public Adapter caseelement(element object) {
			return createelementAdapter();
		}

		@Override
		public Adapter caseSystem(asa.System object) {
			return createSystemAdapter();
		}

		@Override
		public Adapter casePropriete(Propriete object) {
			return createProprieteAdapter();
		}

		@Override
		public Adapter caseconfigurationInterface(configurationInterface object) {
			return createconfigurationInterfaceAdapter();
		}

		@Override
		public Adapter casePortConfig(PortConfig object) {
			return createPortConfigAdapter();
		}

		@Override
		public Adapter casePortConfigFournis(PortConfigFournis object) {
			return createPortConfigFournisAdapter();
		}

		@Override
		public Adapter casePortConfigRequis(PortConfigRequis object) {
			return createPortConfigRequisAdapter();
		}

		@Override
		public Adapter defaultCase(EObject object) {
			return createEObjectAdapter();
		}
	};

	/**
	 * Creates an adapter for the <code>target</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param target the object to adapt.
	 * @return the adapter for the <code>target</code>.
	 * @generated
	 */
	@Override
	public Adapter createAdapter(Notifier target) {
		return modelSwitch.doSwitch((EObject) target);
	}

	/**
	 * Creates a new adapter for an object of class '{@link asa.Composant <em>Composant</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see asa.Composant
	 * @generated
	 */
	public Adapter createComposantAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link asa.Configuration <em>Configuration</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see asa.Configuration
	 * @generated
	 */
	public Adapter createConfigurationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link asa.Connecteur <em>Connecteur</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see asa.Connecteur
	 * @generated
	 */
	public Adapter createConnecteurAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link asa.Binding <em>Binding</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see asa.Binding
	 * @generated
	 */
	public Adapter createBindingAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link asa.Attachement <em>Attachement</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see asa.Attachement
	 * @generated
	 */
	public Adapter createAttachementAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link asa.Glue <em>Glue</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see asa.Glue
	 * @generated
	 */
	public Adapter createGlueAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link asa.RoleRequis <em>Role Requis</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see asa.RoleRequis
	 * @generated
	 */
	public Adapter createRoleRequisAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link asa.RoleFourni <em>Role Fourni</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see asa.RoleFourni
	 * @generated
	 */
	public Adapter createRoleFourniAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link asa.ComposantFeuille <em>Composant Feuille</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see asa.ComposantFeuille
	 * @generated
	 */
	public Adapter createComposantFeuilleAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link asa.ConnecteurFeuille <em>Connecteur Feuille</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see asa.ConnecteurFeuille
	 * @generated
	 */
	public Adapter createConnecteurFeuilleAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link asa.ServiceRequis <em>Service Requis</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see asa.ServiceRequis
	 * @generated
	 */
	public Adapter createServiceRequisAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link asa.ServiceFourni <em>Service Fourni</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see asa.ServiceFourni
	 * @generated
	 */
	public Adapter createServiceFourniAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link asa.PortsRequis <em>Ports Requis</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see asa.PortsRequis
	 * @generated
	 */
	public Adapter createPortsRequisAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link asa.PortsFourni <em>Ports Fourni</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see asa.PortsFourni
	 * @generated
	 */
	public Adapter createPortsFourniAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link asa.ComposantComposite <em>Composant Composite</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see asa.ComposantComposite
	 * @generated
	 */
	public Adapter createComposantCompositeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link asa.Services <em>Services</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see asa.Services
	 * @generated
	 */
	public Adapter createServicesAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link asa.Ports <em>Ports</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see asa.Ports
	 * @generated
	 */
	public Adapter createPortsAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link asa.ConnecteurComposite <em>Connecteur Composite</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see asa.ConnecteurComposite
	 * @generated
	 */
	public Adapter createConnecteurCompositeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link asa.InterfaceConnnecteur <em>Interface Connnecteur</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see asa.InterfaceConnnecteur
	 * @generated
	 */
	public Adapter createInterfaceConnnecteurAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link asa.Role <em>Role</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see asa.Role
	 * @generated
	 */
	public Adapter createRoleAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link asa.InterfaceComposant <em>Interface Composant</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see asa.InterfaceComposant
	 * @generated
	 */
	public Adapter createInterfaceComposantAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link asa.NewEClass25 <em>New EClass25</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see asa.NewEClass25
	 * @generated
	 */
	public Adapter createNewEClass25Adapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link asa.Lien <em>Lien</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see asa.Lien
	 * @generated
	 */
	public Adapter createLienAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link asa.element <em>element</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see asa.element
	 * @generated
	 */
	public Adapter createelementAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link asa.System <em>System</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see asa.System
	 * @generated
	 */
	public Adapter createSystemAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link asa.Propriete <em>Propriete</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see asa.Propriete
	 * @generated
	 */
	public Adapter createProprieteAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link asa.configurationInterface <em>configuration Interface</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see asa.configurationInterface
	 * @generated
	 */
	public Adapter createconfigurationInterfaceAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link asa.PortConfig <em>Port Config</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see asa.PortConfig
	 * @generated
	 */
	public Adapter createPortConfigAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link asa.PortConfigFournis <em>Port Config Fournis</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see asa.PortConfigFournis
	 * @generated
	 */
	public Adapter createPortConfigFournisAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link asa.PortConfigRequis <em>Port Config Requis</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see asa.PortConfigRequis
	 * @generated
	 */
	public Adapter createPortConfigRequisAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for the default case.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @generated
	 */
	public Adapter createEObjectAdapter() {
		return null;
	}

} //AsaAdapterFactory

/**
 */
package asa.util;

import asa.AsaPackage;
import asa.Attachement;
import asa.Binding;
import asa.Composant;
import asa.ComposantComposite;
import asa.ComposantFeuille;
import asa.Configuration;
import asa.Connecteur;
import asa.ConnecteurComposite;
import asa.ConnecteurFeuille;
import asa.Glue;
import asa.InterfaceComposant;
import asa.InterfaceConnnecteur;
import asa.Lien;
import asa.NewEClass25;
import asa.PortConfig;
import asa.PortConfigFournis;
import asa.PortConfigRequis;
import asa.Ports;
import asa.PortsFourni;
import asa.PortsRequis;
import asa.Propriete;
import asa.Role;
import asa.RoleFourni;
import asa.RoleRequis;
import asa.ServiceFourni;
import asa.ServiceRequis;
import asa.Services;
import asa.configurationInterface;
import asa.element;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.Switch;

/**
 * <!-- begin-user-doc -->
 * The <b>Switch</b> for the model's inheritance hierarchy.
 * It supports the call {@link #doSwitch(EObject) doSwitch(object)}
 * to invoke the <code>caseXXX</code> method for each class of the model,
 * starting with the actual class of the object
 * and proceeding up the inheritance hierarchy
 * until a non-null result is returned,
 * which is the result of the switch.
 * <!-- end-user-doc -->
 * @see asa.AsaPackage
 * @generated
 */
public class AsaSwitch<T> extends Switch<T> {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static AsaPackage modelPackage;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AsaSwitch() {
		if (modelPackage == null) {
			modelPackage = AsaPackage.eINSTANCE;
		}
	}

	/**
	 * Checks whether this is a switch for the given package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param ePackage the package in question.
	 * @return whether this is a switch for the given package.
	 * @generated
	 */
	@Override
	protected boolean isSwitchFor(EPackage ePackage) {
		return ePackage == modelPackage;
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	@Override
	protected T doSwitch(int classifierID, EObject theEObject) {
		switch (classifierID) {
		case AsaPackage.COMPOSANT: {
			Composant composant = (Composant) theEObject;
			T result = caseComposant(composant);
			if (result == null)
				result = caseelement(composant);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case AsaPackage.CONFIGURATION: {
			Configuration configuration = (Configuration) theEObject;
			T result = caseConfiguration(configuration);
			if (result == null)
				result = caseelement(configuration);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case AsaPackage.CONNECTEUR: {
			Connecteur connecteur = (Connecteur) theEObject;
			T result = caseConnecteur(connecteur);
			if (result == null)
				result = caseelement(connecteur);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case AsaPackage.BINDING: {
			Binding binding = (Binding) theEObject;
			T result = caseBinding(binding);
			if (result == null)
				result = caseLien(binding);
			if (result == null)
				result = caseelement(binding);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case AsaPackage.ATTACHEMENT: {
			Attachement attachement = (Attachement) theEObject;
			T result = caseAttachement(attachement);
			if (result == null)
				result = caseLien(attachement);
			if (result == null)
				result = caseelement(attachement);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case AsaPackage.GLUE: {
			Glue glue = (Glue) theEObject;
			T result = caseGlue(glue);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case AsaPackage.ROLE_REQUIS: {
			RoleRequis roleRequis = (RoleRequis) theEObject;
			T result = caseRoleRequis(roleRequis);
			if (result == null)
				result = caseRole(roleRequis);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case AsaPackage.ROLE_FOURNI: {
			RoleFourni roleFourni = (RoleFourni) theEObject;
			T result = caseRoleFourni(roleFourni);
			if (result == null)
				result = caseRole(roleFourni);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case AsaPackage.COMPOSANT_FEUILLE: {
			ComposantFeuille composantFeuille = (ComposantFeuille) theEObject;
			T result = caseComposantFeuille(composantFeuille);
			if (result == null)
				result = caseComposant(composantFeuille);
			if (result == null)
				result = caseelement(composantFeuille);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case AsaPackage.CONNECTEUR_FEUILLE: {
			ConnecteurFeuille connecteurFeuille = (ConnecteurFeuille) theEObject;
			T result = caseConnecteurFeuille(connecteurFeuille);
			if (result == null)
				result = caseConnecteur(connecteurFeuille);
			if (result == null)
				result = caseelement(connecteurFeuille);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case AsaPackage.SERVICE_REQUIS: {
			ServiceRequis serviceRequis = (ServiceRequis) theEObject;
			T result = caseServiceRequis(serviceRequis);
			if (result == null)
				result = caseServices(serviceRequis);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case AsaPackage.SERVICE_FOURNI: {
			ServiceFourni serviceFourni = (ServiceFourni) theEObject;
			T result = caseServiceFourni(serviceFourni);
			if (result == null)
				result = caseServices(serviceFourni);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case AsaPackage.PORTS_REQUIS: {
			PortsRequis portsRequis = (PortsRequis) theEObject;
			T result = casePortsRequis(portsRequis);
			if (result == null)
				result = casePorts(portsRequis);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case AsaPackage.PORTS_FOURNI: {
			PortsFourni portsFourni = (PortsFourni) theEObject;
			T result = casePortsFourni(portsFourni);
			if (result == null)
				result = casePorts(portsFourni);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case AsaPackage.COMPOSANT_COMPOSITE: {
			ComposantComposite composantComposite = (ComposantComposite) theEObject;
			T result = caseComposantComposite(composantComposite);
			if (result == null)
				result = caseComposant(composantComposite);
			if (result == null)
				result = caseelement(composantComposite);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case AsaPackage.SERVICES: {
			Services services = (Services) theEObject;
			T result = caseServices(services);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case AsaPackage.PORTS: {
			Ports ports = (Ports) theEObject;
			T result = casePorts(ports);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case AsaPackage.CONNECTEUR_COMPOSITE: {
			ConnecteurComposite connecteurComposite = (ConnecteurComposite) theEObject;
			T result = caseConnecteurComposite(connecteurComposite);
			if (result == null)
				result = caseConnecteur(connecteurComposite);
			if (result == null)
				result = caseelement(connecteurComposite);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case AsaPackage.INTERFACE_CONNNECTEUR: {
			InterfaceConnnecteur interfaceConnnecteur = (InterfaceConnnecteur) theEObject;
			T result = caseInterfaceConnnecteur(interfaceConnnecteur);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case AsaPackage.ROLE: {
			Role role = (Role) theEObject;
			T result = caseRole(role);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case AsaPackage.INTERFACE_COMPOSANT: {
			InterfaceComposant interfaceComposant = (InterfaceComposant) theEObject;
			T result = caseInterfaceComposant(interfaceComposant);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case AsaPackage.NEW_ECLASS25: {
			NewEClass25 newEClass25 = (NewEClass25) theEObject;
			T result = caseNewEClass25(newEClass25);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case AsaPackage.LIEN: {
			Lien lien = (Lien) theEObject;
			T result = caseLien(lien);
			if (result == null)
				result = caseelement(lien);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case AsaPackage.ELEMENT: {
			element element = (element) theEObject;
			T result = caseelement(element);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case AsaPackage.SYSTEM: {
			asa.System system = (asa.System) theEObject;
			T result = caseSystem(system);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case AsaPackage.PROPRIETE: {
			Propriete propriete = (Propriete) theEObject;
			T result = casePropriete(propriete);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case AsaPackage.CONFIGURATION_INTERFACE: {
			configurationInterface configurationInterface = (configurationInterface) theEObject;
			T result = caseconfigurationInterface(configurationInterface);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case AsaPackage.PORT_CONFIG: {
			PortConfig portConfig = (PortConfig) theEObject;
			T result = casePortConfig(portConfig);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case AsaPackage.PORT_CONFIG_FOURNIS: {
			PortConfigFournis portConfigFournis = (PortConfigFournis) theEObject;
			T result = casePortConfigFournis(portConfigFournis);
			if (result == null)
				result = casePortConfig(portConfigFournis);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case AsaPackage.PORT_CONFIG_REQUIS: {
			PortConfigRequis portConfigRequis = (PortConfigRequis) theEObject;
			T result = casePortConfigRequis(portConfigRequis);
			if (result == null)
				result = casePortConfig(portConfigRequis);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		default:
			return defaultCase(theEObject);
		}
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Composant</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Composant</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseComposant(Composant object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Configuration</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Configuration</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseConfiguration(Configuration object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Connecteur</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Connecteur</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseConnecteur(Connecteur object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Binding</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Binding</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseBinding(Binding object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Attachement</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Attachement</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAttachement(Attachement object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Glue</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Glue</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseGlue(Glue object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Role Requis</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Role Requis</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseRoleRequis(RoleRequis object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Role Fourni</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Role Fourni</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseRoleFourni(RoleFourni object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Composant Feuille</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Composant Feuille</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseComposantFeuille(ComposantFeuille object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Connecteur Feuille</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Connecteur Feuille</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseConnecteurFeuille(ConnecteurFeuille object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Service Requis</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Service Requis</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseServiceRequis(ServiceRequis object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Service Fourni</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Service Fourni</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseServiceFourni(ServiceFourni object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Ports Requis</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Ports Requis</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePortsRequis(PortsRequis object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Ports Fourni</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Ports Fourni</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePortsFourni(PortsFourni object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Composant Composite</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Composant Composite</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseComposantComposite(ComposantComposite object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Services</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Services</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseServices(Services object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Ports</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Ports</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePorts(Ports object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Connecteur Composite</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Connecteur Composite</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseConnecteurComposite(ConnecteurComposite object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Interface Connnecteur</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Interface Connnecteur</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseInterfaceConnnecteur(InterfaceConnnecteur object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Role</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Role</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseRole(Role object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Interface Composant</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Interface Composant</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseInterfaceComposant(InterfaceComposant object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>New EClass25</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>New EClass25</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseNewEClass25(NewEClass25 object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Lien</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Lien</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseLien(Lien object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>element</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>element</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseelement(element object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>System</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>System</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSystem(asa.System object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Propriete</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Propriete</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePropriete(Propriete object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>configuration Interface</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>configuration Interface</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseconfigurationInterface(configurationInterface object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Port Config</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Port Config</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePortConfig(PortConfig object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Port Config Fournis</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Port Config Fournis</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePortConfigFournis(PortConfigFournis object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Port Config Requis</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Port Config Requis</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePortConfigRequis(PortConfigRequis object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch, but this is the last case anyway.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	@Override
	public T defaultCase(EObject object) {
		return null;
	}

} //AsaSwitch

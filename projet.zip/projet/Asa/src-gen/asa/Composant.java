/**
 */
package asa;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Composant</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see asa.AsaPackage#getComposant()
 * @model
 * @generated
 */
public interface Composant extends element {
} // Composant

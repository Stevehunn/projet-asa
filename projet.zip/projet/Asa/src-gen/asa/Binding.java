/**
 */
package asa;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Binding</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link asa.Binding#getPortconfigfournis <em>Portconfigfournis</em>}</li>
 *   <li>{@link asa.Binding#getPortconfigrequis <em>Portconfigrequis</em>}</li>
 *   <li>{@link asa.Binding#getPortsfourni <em>Portsfourni</em>}</li>
 *   <li>{@link asa.Binding#getPortsrequis <em>Portsrequis</em>}</li>
 * </ul>
 *
 * @see asa.AsaPackage#getBinding()
 * @model
 * @generated
 */
public interface Binding extends Lien {
	/**
	 * Returns the value of the '<em><b>Portconfigfournis</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Portconfigfournis</em>' reference.
	 * @see #setPortconfigfournis(PortConfigFournis)
	 * @see asa.AsaPackage#getBinding_Portconfigfournis()
	 * @model required="true"
	 * @generated
	 */
	PortConfigFournis getPortconfigfournis();

	/**
	 * Sets the value of the '{@link asa.Binding#getPortconfigfournis <em>Portconfigfournis</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Portconfigfournis</em>' reference.
	 * @see #getPortconfigfournis()
	 * @generated
	 */
	void setPortconfigfournis(PortConfigFournis value);

	/**
	 * Returns the value of the '<em><b>Portconfigrequis</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Portconfigrequis</em>' reference.
	 * @see #setPortconfigrequis(PortConfigRequis)
	 * @see asa.AsaPackage#getBinding_Portconfigrequis()
	 * @model required="true"
	 * @generated
	 */
	PortConfigRequis getPortconfigrequis();

	/**
	 * Sets the value of the '{@link asa.Binding#getPortconfigrequis <em>Portconfigrequis</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Portconfigrequis</em>' reference.
	 * @see #getPortconfigrequis()
	 * @generated
	 */
	void setPortconfigrequis(PortConfigRequis value);

	/**
	 * Returns the value of the '<em><b>Portsfourni</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Portsfourni</em>' reference.
	 * @see #setPortsfourni(PortsFourni)
	 * @see asa.AsaPackage#getBinding_Portsfourni()
	 * @model required="true"
	 * @generated
	 */
	PortsFourni getPortsfourni();

	/**
	 * Sets the value of the '{@link asa.Binding#getPortsfourni <em>Portsfourni</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Portsfourni</em>' reference.
	 * @see #getPortsfourni()
	 * @generated
	 */
	void setPortsfourni(PortsFourni value);

	/**
	 * Returns the value of the '<em><b>Portsrequis</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Portsrequis</em>' reference.
	 * @see #setPortsrequis(PortsRequis)
	 * @see asa.AsaPackage#getBinding_Portsrequis()
	 * @model required="true"
	 * @generated
	 */
	PortsRequis getPortsrequis();

	/**
	 * Sets the value of the '{@link asa.Binding#getPortsrequis <em>Portsrequis</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Portsrequis</em>' reference.
	 * @see #getPortsrequis()
	 * @generated
	 */
	void setPortsrequis(PortsRequis value);

} // Binding

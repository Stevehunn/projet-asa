/**
 */
package asa;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Connecteur Feuille</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link asa.ConnecteurFeuille#getInterfaceconnnecteur <em>Interfaceconnnecteur</em>}</li>
 *   <li>{@link asa.ConnecteurFeuille#getGlue <em>Glue</em>}</li>
 * </ul>
 *
 * @see asa.AsaPackage#getConnecteurFeuille()
 * @model
 * @generated
 */
public interface ConnecteurFeuille extends Connecteur {
	/**
	 * Returns the value of the '<em><b>Interfaceconnnecteur</b></em>' containment reference list.
	 * The list contents are of type {@link asa.InterfaceConnnecteur}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Interfaceconnnecteur</em>' containment reference list.
	 * @see asa.AsaPackage#getConnecteurFeuille_Interfaceconnnecteur()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<InterfaceConnnecteur> getInterfaceconnnecteur();

	/**
	 * Returns the value of the '<em><b>Glue</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Glue</em>' containment reference.
	 * @see #setGlue(Glue)
	 * @see asa.AsaPackage#getConnecteurFeuille_Glue()
	 * @model containment="true"
	 * @generated
	 */
	Glue getGlue();

	/**
	 * Sets the value of the '{@link asa.ConnecteurFeuille#getGlue <em>Glue</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Glue</em>' containment reference.
	 * @see #getGlue()
	 * @generated
	 */
	void setGlue(Glue value);

} // ConnecteurFeuille

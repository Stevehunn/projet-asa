/**
 */
package asa;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Configuration</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link asa.Configuration#getComposant <em>Composant</em>}</li>
 *   <li>{@link asa.Configuration#getConnecteur <em>Connecteur</em>}</li>
 *   <li>{@link asa.Configuration#getLien <em>Lien</em>}</li>
 *   <li>{@link asa.Configuration#getConfigurationinterface <em>Configurationinterface</em>}</li>
 * </ul>
 *
 * @see asa.AsaPackage#getConfiguration()
 * @model
 * @generated
 */
public interface Configuration extends element {
	/**
	 * Returns the value of the '<em><b>Composant</b></em>' containment reference list.
	 * The list contents are of type {@link asa.Composant}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Composant</em>' containment reference list.
	 * @see asa.AsaPackage#getConfiguration_Composant()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Composant> getComposant();

	/**
	 * Returns the value of the '<em><b>Connecteur</b></em>' containment reference list.
	 * The list contents are of type {@link asa.Connecteur}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Connecteur</em>' containment reference list.
	 * @see asa.AsaPackage#getConfiguration_Connecteur()
	 * @model containment="true"
	 * @generated
	 */
	EList<Connecteur> getConnecteur();

	/**
	 * Returns the value of the '<em><b>Lien</b></em>' containment reference list.
	 * The list contents are of type {@link asa.Lien}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Lien</em>' containment reference list.
	 * @see asa.AsaPackage#getConfiguration_Lien()
	 * @model containment="true"
	 * @generated
	 */
	EList<Lien> getLien();

	/**
	 * Returns the value of the '<em><b>Configurationinterface</b></em>' containment reference list.
	 * The list contents are of type {@link asa.configurationInterface}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Configurationinterface</em>' containment reference list.
	 * @see asa.AsaPackage#getConfiguration_Configurationinterface()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<configurationInterface> getConfigurationinterface();

} // Configuration

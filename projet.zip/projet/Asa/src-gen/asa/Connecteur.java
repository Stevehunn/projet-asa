/**
 */
package asa;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Connecteur</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see asa.AsaPackage#getConnecteur()
 * @model
 * @generated
 */
public interface Connecteur extends element {
} // Connecteur

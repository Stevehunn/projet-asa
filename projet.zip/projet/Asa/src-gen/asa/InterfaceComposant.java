/**
 */
package asa;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Interface Composant</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link asa.InterfaceComposant#getService <em>Service</em>}</li>
 *   <li>{@link asa.InterfaceComposant#getPort <em>Port</em>}</li>
 * </ul>
 *
 * @see asa.AsaPackage#getInterfaceComposant()
 * @model interface="true" abstract="true"
 * @generated
 */
public interface InterfaceComposant extends EObject {
	/**
	 * Returns the value of the '<em><b>Service</b></em>' containment reference list.
	 * The list contents are of type {@link asa.Services}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Service</em>' containment reference list.
	 * @see asa.AsaPackage#getInterfaceComposant_Service()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Services> getService();

	/**
	 * Returns the value of the '<em><b>Port</b></em>' containment reference list.
	 * The list contents are of type {@link asa.Ports}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Port</em>' containment reference list.
	 * @see asa.AsaPackage#getInterfaceComposant_Port()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Ports> getPort();

} // InterfaceComposant

/**
 */
package asa;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Glue</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see asa.AsaPackage#getGlue()
 * @model
 * @generated
 */
public interface Glue extends EObject {
} // Glue

/**
 */
package asa;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Attachement</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link asa.Attachement#getRolefourni <em>Rolefourni</em>}</li>
 *   <li>{@link asa.Attachement#getRolerequis <em>Rolerequis</em>}</li>
 *   <li>{@link asa.Attachement#getPortsfourni <em>Portsfourni</em>}</li>
 *   <li>{@link asa.Attachement#getPortrequis <em>Portrequis</em>}</li>
 * </ul>
 *
 * @see asa.AsaPackage#getAttachement()
 * @model
 * @generated
 */
public interface Attachement extends Lien {
	/**
	 * Returns the value of the '<em><b>Rolefourni</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Rolefourni</em>' reference.
	 * @see #setRolefourni(RoleFourni)
	 * @see asa.AsaPackage#getAttachement_Rolefourni()
	 * @model required="true"
	 * @generated
	 */
	RoleFourni getRolefourni();

	/**
	 * Sets the value of the '{@link asa.Attachement#getRolefourni <em>Rolefourni</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Rolefourni</em>' reference.
	 * @see #getRolefourni()
	 * @generated
	 */
	void setRolefourni(RoleFourni value);

	/**
	 * Returns the value of the '<em><b>Rolerequis</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Rolerequis</em>' reference.
	 * @see #setRolerequis(RoleRequis)
	 * @see asa.AsaPackage#getAttachement_Rolerequis()
	 * @model required="true"
	 * @generated
	 */
	RoleRequis getRolerequis();

	/**
	 * Sets the value of the '{@link asa.Attachement#getRolerequis <em>Rolerequis</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Rolerequis</em>' reference.
	 * @see #getRolerequis()
	 * @generated
	 */
	void setRolerequis(RoleRequis value);

	/**
	 * Returns the value of the '<em><b>Portsfourni</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Portsfourni</em>' reference.
	 * @see #setPortsfourni(PortsFourni)
	 * @see asa.AsaPackage#getAttachement_Portsfourni()
	 * @model required="true"
	 * @generated
	 */
	PortsFourni getPortsfourni();

	/**
	 * Sets the value of the '{@link asa.Attachement#getPortsfourni <em>Portsfourni</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Portsfourni</em>' reference.
	 * @see #getPortsfourni()
	 * @generated
	 */
	void setPortsfourni(PortsFourni value);

	/**
	 * Returns the value of the '<em><b>Portrequis</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Portrequis</em>' reference.
	 * @see #setPortrequis(PortsRequis)
	 * @see asa.AsaPackage#getAttachement_Portrequis()
	 * @model required="true"
	 * @generated
	 */
	PortsRequis getPortrequis();

	/**
	 * Sets the value of the '{@link asa.Attachement#getPortrequis <em>Portrequis</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Portrequis</em>' reference.
	 * @see #getPortrequis()
	 * @generated
	 */
	void setPortrequis(PortsRequis value);

} // Attachement

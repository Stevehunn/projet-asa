/**
 */
package asa;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Ports Fourni</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see asa.AsaPackage#getPortsFourni()
 * @model
 * @generated
 */
public interface PortsFourni extends Ports {
} // PortsFourni

/**
 */
package modelM1;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Interface Connection Manager</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link modelM1.InterfaceConnectionManager#getExternalsocket <em>Externalsocket</em>}</li>
 *   <li>{@link modelM1.InterfaceConnectionManager#getDbquery <em>Dbquery</em>}</li>
 *   <li>{@link modelM1.InterfaceConnectionManager#getSecuritycheck <em>Securitycheck</em>}</li>
 * </ul>
 *
 * @see modelM1.ModelM1Package#getInterfaceConnectionManager()
 * @model
 * @generated
 */
public interface InterfaceConnectionManager extends EObject {
	/**
	 * Returns the value of the '<em><b>Externalsocket</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Externalsocket</em>' reference.
	 * @see #setExternalsocket(ExternalSocket)
	 * @see modelM1.ModelM1Package#getInterfaceConnectionManager_Externalsocket()
	 * @model
	 * @generated
	 */
	ExternalSocket getExternalsocket();

	/**
	 * Sets the value of the '{@link modelM1.InterfaceConnectionManager#getExternalsocket <em>Externalsocket</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Externalsocket</em>' reference.
	 * @see #getExternalsocket()
	 * @generated
	 */
	void setExternalsocket(ExternalSocket value);

	/**
	 * Returns the value of the '<em><b>Dbquery</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Dbquery</em>' reference.
	 * @see #setDbquery(DbQuery)
	 * @see modelM1.ModelM1Package#getInterfaceConnectionManager_Dbquery()
	 * @model
	 * @generated
	 */
	DbQuery getDbquery();

	/**
	 * Sets the value of the '{@link modelM1.InterfaceConnectionManager#getDbquery <em>Dbquery</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Dbquery</em>' reference.
	 * @see #getDbquery()
	 * @generated
	 */
	void setDbquery(DbQuery value);

	/**
	 * Returns the value of the '<em><b>Securitycheck</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Securitycheck</em>' reference.
	 * @see #setSecuritycheck(SecurityCheck)
	 * @see modelM1.ModelM1Package#getInterfaceConnectionManager_Securitycheck()
	 * @model
	 * @generated
	 */
	SecurityCheck getSecuritycheck();

	/**
	 * Sets the value of the '{@link modelM1.InterfaceConnectionManager#getSecuritycheck <em>Securitycheck</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Securitycheck</em>' reference.
	 * @see #getSecuritycheck()
	 * @generated
	 */
	void setSecuritycheck(SecurityCheck value);

} // InterfaceConnectionManager

/**
 */
package modelM1;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Interface Configuration Serveur</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link modelM1.InterfaceConfigurationServeur#getPortfourniconfigurationserveur <em>Portfourniconfigurationserveur</em>}</li>
 * </ul>
 *
 * @see modelM1.ModelM1Package#getInterfaceConfigurationServeur()
 * @model
 * @generated
 */
public interface InterfaceConfigurationServeur extends EObject {
	/**
	 * Returns the value of the '<em><b>Portfourniconfigurationserveur</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Portfourniconfigurationserveur</em>' reference.
	 * @see #setPortfourniconfigurationserveur(PortFourniConfigurationServeur)
	 * @see modelM1.ModelM1Package#getInterfaceConfigurationServeur_Portfourniconfigurationserveur()
	 * @model
	 * @generated
	 */
	PortFourniConfigurationServeur getPortfourniconfigurationserveur();

	/**
	 * Sets the value of the '{@link modelM1.InterfaceConfigurationServeur#getPortfourniconfigurationserveur <em>Portfourniconfigurationserveur</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Portfourniconfigurationserveur</em>' reference.
	 * @see #getPortfourniconfigurationserveur()
	 * @generated
	 */
	void setPortfourniconfigurationserveur(PortFourniConfigurationServeur value);

} // InterfaceConfigurationServeur

/**
 */
package modelM1;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Check Query</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see modelM1.ModelM1Package#getCheckQuery()
 * @model
 * @generated
 */
public interface CheckQuery extends EObject {
} // CheckQuery

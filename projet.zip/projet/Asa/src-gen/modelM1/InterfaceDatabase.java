/**
 */
package modelM1;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Interface Database</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link modelM1.InterfaceDatabase#getQueryinterogation <em>Queryinterogation</em>}</li>
 *   <li>{@link modelM1.InterfaceDatabase#getSecuritymanagement <em>Securitymanagement</em>}</li>
 * </ul>
 *
 * @see modelM1.ModelM1Package#getInterfaceDatabase()
 * @model
 * @generated
 */
public interface InterfaceDatabase extends EObject {
	/**
	 * Returns the value of the '<em><b>Queryinterogation</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Queryinterogation</em>' reference.
	 * @see #setQueryinterogation(QueryInterogation)
	 * @see modelM1.ModelM1Package#getInterfaceDatabase_Queryinterogation()
	 * @model
	 * @generated
	 */
	QueryInterogation getQueryinterogation();

	/**
	 * Sets the value of the '{@link modelM1.InterfaceDatabase#getQueryinterogation <em>Queryinterogation</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Queryinterogation</em>' reference.
	 * @see #getQueryinterogation()
	 * @generated
	 */
	void setQueryinterogation(QueryInterogation value);

	/**
	 * Returns the value of the '<em><b>Securitymanagement</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Securitymanagement</em>' reference.
	 * @see #setSecuritymanagement(SecurityManagement)
	 * @see modelM1.ModelM1Package#getInterfaceDatabase_Securitymanagement()
	 * @model
	 * @generated
	 */
	SecurityManagement getSecuritymanagement();

	/**
	 * Sets the value of the '{@link modelM1.InterfaceDatabase#getSecuritymanagement <em>Securitymanagement</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Securitymanagement</em>' reference.
	 * @see #getSecuritymanagement()
	 * @generated
	 */
	void setSecuritymanagement(SecurityManagement value);

} // InterfaceDatabase

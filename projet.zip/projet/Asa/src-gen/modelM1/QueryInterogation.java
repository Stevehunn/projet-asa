/**
 */
package modelM1;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Query Interogation</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see modelM1.ModelM1Package#getQueryInterogation()
 * @model
 * @generated
 */
public interface QueryInterogation extends EObject {
} // QueryInterogation

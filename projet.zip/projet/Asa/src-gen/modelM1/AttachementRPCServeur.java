/**
 */
package modelM1;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Attachement RPC Serveur</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link modelM1.AttachementRPCServeur#getInterfaceconnecteurrpc <em>Interfaceconnecteurrpc</em>}</li>
 *   <li>{@link modelM1.AttachementRPCServeur#getInterfaceconfigurationserveur <em>Interfaceconfigurationserveur</em>}</li>
 * </ul>
 *
 * @see modelM1.ModelM1Package#getAttachementRPCServeur()
 * @model
 * @generated
 */
public interface AttachementRPCServeur extends EObject {
	/**
	 * Returns the value of the '<em><b>Interfaceconnecteurrpc</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Interfaceconnecteurrpc</em>' reference.
	 * @see #setInterfaceconnecteurrpc(InterfaceConnecteurRPC)
	 * @see modelM1.ModelM1Package#getAttachementRPCServeur_Interfaceconnecteurrpc()
	 * @model
	 * @generated
	 */
	InterfaceConnecteurRPC getInterfaceconnecteurrpc();

	/**
	 * Sets the value of the '{@link modelM1.AttachementRPCServeur#getInterfaceconnecteurrpc <em>Interfaceconnecteurrpc</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Interfaceconnecteurrpc</em>' reference.
	 * @see #getInterfaceconnecteurrpc()
	 * @generated
	 */
	void setInterfaceconnecteurrpc(InterfaceConnecteurRPC value);

	/**
	 * Returns the value of the '<em><b>Interfaceconfigurationserveur</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Interfaceconfigurationserveur</em>' reference.
	 * @see #setInterfaceconfigurationserveur(InterfaceConfigurationServeur)
	 * @see modelM1.ModelM1Package#getAttachementRPCServeur_Interfaceconfigurationserveur()
	 * @model
	 * @generated
	 */
	InterfaceConfigurationServeur getInterfaceconfigurationserveur();

	/**
	 * Sets the value of the '{@link modelM1.AttachementRPCServeur#getInterfaceconfigurationserveur <em>Interfaceconfigurationserveur</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Interfaceconfigurationserveur</em>' reference.
	 * @see #getInterfaceconfigurationserveur()
	 * @generated
	 */
	void setInterfaceconfigurationserveur(InterfaceConfigurationServeur value);

} // AttachementRPCServeur

/**
 */
package modelM1;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Interface Connecteur Cm Db</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link modelM1.InterfaceConnecteurCmDb#getRoledb <em>Roledb</em>}</li>
 *   <li>{@link modelM1.InterfaceConnecteurCmDb#getRolecm <em>Rolecm</em>}</li>
 * </ul>
 *
 * @see modelM1.ModelM1Package#getInterfaceConnecteurCmDb()
 * @model
 * @generated
 */
public interface InterfaceConnecteurCmDb extends EObject {
	/**
	 * Returns the value of the '<em><b>Roledb</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Roledb</em>' reference.
	 * @see #setRoledb(RoleDb)
	 * @see modelM1.ModelM1Package#getInterfaceConnecteurCmDb_Roledb()
	 * @model
	 * @generated
	 */
	RoleDb getRoledb();

	/**
	 * Sets the value of the '{@link modelM1.InterfaceConnecteurCmDb#getRoledb <em>Roledb</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Roledb</em>' reference.
	 * @see #getRoledb()
	 * @generated
	 */
	void setRoledb(RoleDb value);

	/**
	 * Returns the value of the '<em><b>Rolecm</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Rolecm</em>' reference.
	 * @see #setRolecm(RoleCm)
	 * @see modelM1.ModelM1Package#getInterfaceConnecteurCmDb_Rolecm()
	 * @model
	 * @generated
	 */
	RoleCm getRolecm();

	/**
	 * Sets the value of the '{@link modelM1.InterfaceConnecteurCmDb#getRolecm <em>Rolecm</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Rolecm</em>' reference.
	 * @see #getRolecm()
	 * @generated
	 */
	void setRolecm(RoleCm value);

} // InterfaceConnecteurCmDb

/**
 */
package modelM1;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Client</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link modelM1.Client#getInterfaceclient <em>Interfaceclient</em>}</li>
 * </ul>
 *
 * @see modelM1.ModelM1Package#getClient()
 * @model
 * @generated
 */
public interface Client extends EObject {
	/**
	 * Returns the value of the '<em><b>Interfaceclient</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Interfaceclient</em>' reference.
	 * @see #setInterfaceclient(InterfaceClient)
	 * @see modelM1.ModelM1Package#getClient_Interfaceclient()
	 * @model
	 * @generated
	 */
	InterfaceClient getInterfaceclient();

	/**
	 * Sets the value of the '{@link modelM1.Client#getInterfaceclient <em>Interfaceclient</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Interfaceclient</em>' reference.
	 * @see #getInterfaceclient()
	 * @generated
	 */
	void setInterfaceclient(InterfaceClient value);

} // Client

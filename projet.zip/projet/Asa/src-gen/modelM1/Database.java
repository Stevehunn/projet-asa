/**
 */
package modelM1;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Database</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link modelM1.Database#getInterfacedatabase <em>Interfacedatabase</em>}</li>
 * </ul>
 *
 * @see modelM1.ModelM1Package#getDatabase()
 * @model
 * @generated
 */
public interface Database extends EObject {
	/**
	 * Returns the value of the '<em><b>Interfacedatabase</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Interfacedatabase</em>' reference.
	 * @see #setInterfacedatabase(InterfaceDatabase)
	 * @see modelM1.ModelM1Package#getDatabase_Interfacedatabase()
	 * @model
	 * @generated
	 */
	InterfaceDatabase getInterfacedatabase();

	/**
	 * Sets the value of the '{@link modelM1.Database#getInterfacedatabase <em>Interfacedatabase</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Interfacedatabase</em>' reference.
	 * @see #getInterfacedatabase()
	 * @generated
	 */
	void setInterfacedatabase(InterfaceDatabase value);

} // Database

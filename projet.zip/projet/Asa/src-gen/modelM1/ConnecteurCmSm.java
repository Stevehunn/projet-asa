/**
 */
package modelM1;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Connecteur Cm Sm</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link modelM1.ConnecteurCmSm#getInterfaceconnecteurcmsm <em>Interfaceconnecteurcmsm</em>}</li>
 * </ul>
 *
 * @see modelM1.ModelM1Package#getConnecteurCmSm()
 * @model
 * @generated
 */
public interface ConnecteurCmSm extends EObject {
	/**
	 * Returns the value of the '<em><b>Interfaceconnecteurcmsm</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Interfaceconnecteurcmsm</em>' reference.
	 * @see #setInterfaceconnecteurcmsm(InterfaceConnecteurCmSm)
	 * @see modelM1.ModelM1Package#getConnecteurCmSm_Interfaceconnecteurcmsm()
	 * @model
	 * @generated
	 */
	InterfaceConnecteurCmSm getInterfaceconnecteurcmsm();

	/**
	 * Sets the value of the '{@link modelM1.ConnecteurCmSm#getInterfaceconnecteurcmsm <em>Interfaceconnecteurcmsm</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Interfaceconnecteurcmsm</em>' reference.
	 * @see #getInterfaceconnecteurcmsm()
	 * @generated
	 */
	void setInterfaceconnecteurcmsm(InterfaceConnecteurCmSm value);

} // ConnecteurCmSm

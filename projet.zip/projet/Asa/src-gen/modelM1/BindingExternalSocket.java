/**
 */
package modelM1;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Binding External Socket</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link modelM1.BindingExternalSocket#getExternalsocket <em>Externalsocket</em>}</li>
 *   <li>{@link modelM1.BindingExternalSocket#getPortfourniconfigurationserveur <em>Portfourniconfigurationserveur</em>}</li>
 * </ul>
 *
 * @see modelM1.ModelM1Package#getBindingExternalSocket()
 * @model
 * @generated
 */
public interface BindingExternalSocket extends EObject {
	/**
	 * Returns the value of the '<em><b>Externalsocket</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Externalsocket</em>' reference.
	 * @see #setExternalsocket(ExternalSocket)
	 * @see modelM1.ModelM1Package#getBindingExternalSocket_Externalsocket()
	 * @model
	 * @generated
	 */
	ExternalSocket getExternalsocket();

	/**
	 * Sets the value of the '{@link modelM1.BindingExternalSocket#getExternalsocket <em>Externalsocket</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Externalsocket</em>' reference.
	 * @see #getExternalsocket()
	 * @generated
	 */
	void setExternalsocket(ExternalSocket value);

	/**
	 * Returns the value of the '<em><b>Portfourniconfigurationserveur</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Portfourniconfigurationserveur</em>' reference.
	 * @see #setPortfourniconfigurationserveur(PortFourniConfigurationServeur)
	 * @see modelM1.ModelM1Package#getBindingExternalSocket_Portfourniconfigurationserveur()
	 * @model
	 * @generated
	 */
	PortFourniConfigurationServeur getPortfourniconfigurationserveur();

	/**
	 * Sets the value of the '{@link modelM1.BindingExternalSocket#getPortfourniconfigurationserveur <em>Portfourniconfigurationserveur</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Portfourniconfigurationserveur</em>' reference.
	 * @see #getPortfourniconfigurationserveur()
	 * @generated
	 */
	void setPortfourniconfigurationserveur(PortFourniConfigurationServeur value);

} // BindingExternalSocket

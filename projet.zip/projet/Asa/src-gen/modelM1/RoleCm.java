/**
 */
package modelM1;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Role Cm</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see modelM1.ModelM1Package#getRoleCm()
 * @model
 * @generated
 */
public interface RoleCm extends EObject {
} // RoleCm

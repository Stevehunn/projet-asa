/**
 */
package modelM1;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Interface Client</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link modelM1.InterfaceClient#getAttachementclientrpc <em>Attachementclientrpc</em>}</li>
 *   <li>{@link modelM1.InterfaceClient#getPortfourniclient <em>Portfourniclient</em>}</li>
 *   <li>{@link modelM1.InterfaceClient#getPortrequisclient <em>Portrequisclient</em>}</li>
 *   <li>{@link modelM1.InterfaceClient#getServicefourniclient <em>Servicefourniclient</em>}</li>
 * </ul>
 *
 * @see modelM1.ModelM1Package#getInterfaceClient()
 * @model
 * @generated
 */
public interface InterfaceClient extends EObject {
	/**
	 * Returns the value of the '<em><b>Attachementclientrpc</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Attachementclientrpc</em>' reference.
	 * @see #setAttachementclientrpc(AttachementClientRPC)
	 * @see modelM1.ModelM1Package#getInterfaceClient_Attachementclientrpc()
	 * @model
	 * @generated
	 */
	AttachementClientRPC getAttachementclientrpc();

	/**
	 * Sets the value of the '{@link modelM1.InterfaceClient#getAttachementclientrpc <em>Attachementclientrpc</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Attachementclientrpc</em>' reference.
	 * @see #getAttachementclientrpc()
	 * @generated
	 */
	void setAttachementclientrpc(AttachementClientRPC value);

	/**
	 * Returns the value of the '<em><b>Portfourniclient</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Portfourniclient</em>' reference.
	 * @see #setPortfourniclient(PortFourniClient)
	 * @see modelM1.ModelM1Package#getInterfaceClient_Portfourniclient()
	 * @model
	 * @generated
	 */
	PortFourniClient getPortfourniclient();

	/**
	 * Sets the value of the '{@link modelM1.InterfaceClient#getPortfourniclient <em>Portfourniclient</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Portfourniclient</em>' reference.
	 * @see #getPortfourniclient()
	 * @generated
	 */
	void setPortfourniclient(PortFourniClient value);

	/**
	 * Returns the value of the '<em><b>Portrequisclient</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Portrequisclient</em>' reference.
	 * @see #setPortrequisclient(PortRequisClient)
	 * @see modelM1.ModelM1Package#getInterfaceClient_Portrequisclient()
	 * @model
	 * @generated
	 */
	PortRequisClient getPortrequisclient();

	/**
	 * Sets the value of the '{@link modelM1.InterfaceClient#getPortrequisclient <em>Portrequisclient</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Portrequisclient</em>' reference.
	 * @see #getPortrequisclient()
	 * @generated
	 */
	void setPortrequisclient(PortRequisClient value);

	/**
	 * Returns the value of the '<em><b>Servicefourniclient</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Servicefourniclient</em>' reference.
	 * @see #setServicefourniclient(ServiceFourniClient)
	 * @see modelM1.ModelM1Package#getInterfaceClient_Servicefourniclient()
	 * @model
	 * @generated
	 */
	ServiceFourniClient getServicefourniclient();

	/**
	 * Sets the value of the '{@link modelM1.InterfaceClient#getServicefourniclient <em>Servicefourniclient</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Servicefourniclient</em>' reference.
	 * @see #getServicefourniclient()
	 * @generated
	 */
	void setServicefourniclient(ServiceFourniClient value);

} // InterfaceClient

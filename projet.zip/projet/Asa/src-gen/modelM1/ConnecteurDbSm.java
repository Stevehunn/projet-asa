/**
 */
package modelM1;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Connecteur Db Sm</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link modelM1.ConnecteurDbSm#getInterfaceconnecteurdbsm <em>Interfaceconnecteurdbsm</em>}</li>
 * </ul>
 *
 * @see modelM1.ModelM1Package#getConnecteurDbSm()
 * @model
 * @generated
 */
public interface ConnecteurDbSm extends EObject {
	/**
	 * Returns the value of the '<em><b>Interfaceconnecteurdbsm</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Interfaceconnecteurdbsm</em>' reference.
	 * @see #setInterfaceconnecteurdbsm(InterfaceConnecteurDbSm)
	 * @see modelM1.ModelM1Package#getConnecteurDbSm_Interfaceconnecteurdbsm()
	 * @model
	 * @generated
	 */
	InterfaceConnecteurDbSm getInterfaceconnecteurdbsm();

	/**
	 * Sets the value of the '{@link modelM1.ConnecteurDbSm#getInterfaceconnecteurdbsm <em>Interfaceconnecteurdbsm</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Interfaceconnecteurdbsm</em>' reference.
	 * @see #getInterfaceconnecteurdbsm()
	 * @generated
	 */
	void setInterfaceconnecteurdbsm(InterfaceConnecteurDbSm value);

} // ConnecteurDbSm

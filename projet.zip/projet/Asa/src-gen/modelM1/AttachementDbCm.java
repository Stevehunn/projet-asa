/**
 */
package modelM1;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Attachement Db Cm</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link modelM1.AttachementDbCm#getQueryinterogation <em>Queryinterogation</em>}</li>
 *   <li>{@link modelM1.AttachementDbCm#getRolecm <em>Rolecm</em>}</li>
 * </ul>
 *
 * @see modelM1.ModelM1Package#getAttachementDbCm()
 * @model
 * @generated
 */
public interface AttachementDbCm extends EObject {
	/**
	 * Returns the value of the '<em><b>Queryinterogation</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Queryinterogation</em>' reference.
	 * @see #setQueryinterogation(QueryInterogation)
	 * @see modelM1.ModelM1Package#getAttachementDbCm_Queryinterogation()
	 * @model
	 * @generated
	 */
	QueryInterogation getQueryinterogation();

	/**
	 * Sets the value of the '{@link modelM1.AttachementDbCm#getQueryinterogation <em>Queryinterogation</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Queryinterogation</em>' reference.
	 * @see #getQueryinterogation()
	 * @generated
	 */
	void setQueryinterogation(QueryInterogation value);

	/**
	 * Returns the value of the '<em><b>Rolecm</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Rolecm</em>' reference.
	 * @see #setRolecm(RoleCm)
	 * @see modelM1.ModelM1Package#getAttachementDbCm_Rolecm()
	 * @model
	 * @generated
	 */
	RoleCm getRolecm();

	/**
	 * Sets the value of the '{@link modelM1.AttachementDbCm#getRolecm <em>Rolecm</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Rolecm</em>' reference.
	 * @see #getRolecm()
	 * @generated
	 */
	void setRolecm(RoleCm value);

} // AttachementDbCm

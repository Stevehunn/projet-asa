/**
 */
package modelM1.util;

import modelM1.AttachementClientRPC;
import modelM1.AttachementCmDb;
import modelM1.AttachementCmSm;
import modelM1.AttachementDbCm;
import modelM1.AttachementDbSm;
import modelM1.AttachementRPCServeur;
import modelM1.AttachementSmCm;
import modelM1.AttachementSmDb;
import modelM1.BindingExternalSocket;
import modelM1.CheckQuery;
import modelM1.Client;
import modelM1.ConfigurationServeur;
import modelM1.ConnecteurCmDb;
import modelM1.ConnecteurCmSm;
import modelM1.ConnecteurDbSm;
import modelM1.ConnecteurRPC;
import modelM1.ConnectionManager;
import modelM1.Database;
import modelM1.DbQuery;
import modelM1.ExternalSocket;
import modelM1.InterfaceClient;
import modelM1.InterfaceConfigurationServeur;
import modelM1.InterfaceConnecteurCmDb;
import modelM1.InterfaceConnecteurCmSm;
import modelM1.InterfaceConnecteurDbSm;
import modelM1.InterfaceConnecteurRPC;
import modelM1.InterfaceConnectionManager;
import modelM1.InterfaceDatabase;
import modelM1.InterfaceSecurityManager;
import modelM1.ModelM1Package;
import modelM1.PortFourniClient;
import modelM1.PortFourniConfigurationServeur;
import modelM1.PortRequisClient;
import modelM1.QueryInterogation;
import modelM1.RoleCm;
import modelM1.RoleDb;
import modelM1.RoleSm;
import modelM1.SecurityAuthentification;
import modelM1.SecurityCheck;
import modelM1.SecurityManagement;
import modelM1.Serveur;
import modelM1.ServiceFourniClient;
import modelM1.SystemeClientServeur;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see modelM1.ModelM1Package
 * @generated
 */
public class ModelM1AdapterFactory extends AdapterFactoryImpl {
	/**
	 * The cached model package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static ModelM1Package modelPackage;

	/**
	 * Creates an instance of the adapter factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ModelM1AdapterFactory() {
		if (modelPackage == null) {
			modelPackage = ModelM1Package.eINSTANCE;
		}
	}

	/**
	 * Returns whether this factory is applicable for the type of the object.
	 * <!-- begin-user-doc -->
	 * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
	 * <!-- end-user-doc -->
	 * @return whether this factory is applicable for the type of the object.
	 * @generated
	 */
	@Override
	public boolean isFactoryForType(Object object) {
		if (object == modelPackage) {
			return true;
		}
		if (object instanceof EObject) {
			return ((EObject) object).eClass().getEPackage() == modelPackage;
		}
		return false;
	}

	/**
	 * The switch that delegates to the <code>createXXX</code> methods.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ModelM1Switch<Adapter> modelSwitch = new ModelM1Switch<Adapter>() {
		@Override
		public Adapter caseSecurityAuthentification(SecurityAuthentification object) {
			return createSecurityAuthentificationAdapter();
		}

		@Override
		public Adapter caseInterfaceConnecteurCmSm(InterfaceConnecteurCmSm object) {
			return createInterfaceConnecteurCmSmAdapter();
		}

		@Override
		public Adapter caseDbQuery(DbQuery object) {
			return createDbQueryAdapter();
		}

		@Override
		public Adapter caseInterfaceConnecteurDbSm(InterfaceConnecteurDbSm object) {
			return createInterfaceConnecteurDbSmAdapter();
		}

		@Override
		public Adapter caseAttachementSmDb(AttachementSmDb object) {
			return createAttachementSmDbAdapter();
		}

		@Override
		public Adapter casePortFourniConfigurationServeur(PortFourniConfigurationServeur object) {
			return createPortFourniConfigurationServeurAdapter();
		}

		@Override
		public Adapter caseServiceFourniClient(ServiceFourniClient object) {
			return createServiceFourniClientAdapter();
		}

		@Override
		public Adapter caseInterfaceSecurityManager(InterfaceSecurityManager object) {
			return createInterfaceSecurityManagerAdapter();
		}

		@Override
		public Adapter caseBindingExternalSocket(BindingExternalSocket object) {
			return createBindingExternalSocketAdapter();
		}

		@Override
		public Adapter caseRoleDb(RoleDb object) {
			return createRoleDbAdapter();
		}

		@Override
		public Adapter caseCheckQuery(CheckQuery object) {
			return createCheckQueryAdapter();
		}

		@Override
		public Adapter caseAttachementRPCServeur(AttachementRPCServeur object) {
			return createAttachementRPCServeurAdapter();
		}

		@Override
		public Adapter caseAttachementClientRPC(AttachementClientRPC object) {
			return createAttachementClientRPCAdapter();
		}

		@Override
		public Adapter caseSecurityManagement(SecurityManagement object) {
			return createSecurityManagementAdapter();
		}

		@Override
		public Adapter casePortFourniClient(PortFourniClient object) {
			return createPortFourniClientAdapter();
		}

		@Override
		public Adapter casePortRequisClient(PortRequisClient object) {
			return createPortRequisClientAdapter();
		}

		@Override
		public Adapter caseAttachementDbSm(AttachementDbSm object) {
			return createAttachementDbSmAdapter();
		}

		@Override
		public Adapter caseSecurityManager(modelM1.SecurityManager object) {
			return createSecurityManagerAdapter();
		}

		@Override
		public Adapter caseRoleCm(RoleCm object) {
			return createRoleCmAdapter();
		}

		@Override
		public Adapter caseInterfaceConnectionManager(InterfaceConnectionManager object) {
			return createInterfaceConnectionManagerAdapter();
		}

		@Override
		public Adapter caseInterfaceClient(InterfaceClient object) {
			return createInterfaceClientAdapter();
		}

		@Override
		public Adapter caseExternalSocket(ExternalSocket object) {
			return createExternalSocketAdapter();
		}

		@Override
		public Adapter caseSystemeClientServeur(SystemeClientServeur object) {
			return createSystemeClientServeurAdapter();
		}

		@Override
		public Adapter caseConfigurationServeur(ConfigurationServeur object) {
			return createConfigurationServeurAdapter();
		}

		@Override
		public Adapter caseQueryInterogation(QueryInterogation object) {
			return createQueryInterogationAdapter();
		}

		@Override
		public Adapter caseInterfaceDatabase(InterfaceDatabase object) {
			return createInterfaceDatabaseAdapter();
		}

		@Override
		public Adapter caseDatabase(Database object) {
			return createDatabaseAdapter();
		}

		@Override
		public Adapter caseConnecteurCmSm(ConnecteurCmSm object) {
			return createConnecteurCmSmAdapter();
		}

		@Override
		public Adapter caseInterfaceConnecteurRPC(InterfaceConnecteurRPC object) {
			return createInterfaceConnecteurRPCAdapter();
		}

		@Override
		public Adapter caseAttachementCmSm(AttachementCmSm object) {
			return createAttachementCmSmAdapter();
		}

		@Override
		public Adapter caseAttachementCmDb(AttachementCmDb object) {
			return createAttachementCmDbAdapter();
		}

		@Override
		public Adapter caseInterfaceConnecteurCmDb(InterfaceConnecteurCmDb object) {
			return createInterfaceConnecteurCmDbAdapter();
		}

		@Override
		public Adapter caseAttachementSmCm(AttachementSmCm object) {
			return createAttachementSmCmAdapter();
		}

		@Override
		public Adapter caseClient(Client object) {
			return createClientAdapter();
		}

		@Override
		public Adapter caseConnecteurCmDb(ConnecteurCmDb object) {
			return createConnecteurCmDbAdapter();
		}

		@Override
		public Adapter caseRoleSm(RoleSm object) {
			return createRoleSmAdapter();
		}

		@Override
		public Adapter caseSecurityCheck(SecurityCheck object) {
			return createSecurityCheckAdapter();
		}

		@Override
		public Adapter caseConnecteurRPC(ConnecteurRPC object) {
			return createConnecteurRPCAdapter();
		}

		@Override
		public Adapter caseAttachementDbCm(AttachementDbCm object) {
			return createAttachementDbCmAdapter();
		}

		@Override
		public Adapter caseInterfaceConfigurationServeur(InterfaceConfigurationServeur object) {
			return createInterfaceConfigurationServeurAdapter();
		}

		@Override
		public Adapter caseConnectionManager(ConnectionManager object) {
			return createConnectionManagerAdapter();
		}

		@Override
		public Adapter caseServeur(Serveur object) {
			return createServeurAdapter();
		}

		@Override
		public Adapter caseConnecteurDbSm(ConnecteurDbSm object) {
			return createConnecteurDbSmAdapter();
		}

		@Override
		public Adapter defaultCase(EObject object) {
			return createEObjectAdapter();
		}
	};

	/**
	 * Creates an adapter for the <code>target</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param target the object to adapt.
	 * @return the adapter for the <code>target</code>.
	 * @generated
	 */
	@Override
	public Adapter createAdapter(Notifier target) {
		return modelSwitch.doSwitch((EObject) target);
	}

	/**
	 * Creates a new adapter for an object of class '{@link modelM1.SecurityAuthentification <em>Security Authentification</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modelM1.SecurityAuthentification
	 * @generated
	 */
	public Adapter createSecurityAuthentificationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modelM1.InterfaceConnecteurCmSm <em>Interface Connecteur Cm Sm</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modelM1.InterfaceConnecteurCmSm
	 * @generated
	 */
	public Adapter createInterfaceConnecteurCmSmAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modelM1.DbQuery <em>Db Query</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modelM1.DbQuery
	 * @generated
	 */
	public Adapter createDbQueryAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modelM1.InterfaceConnecteurDbSm <em>Interface Connecteur Db Sm</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modelM1.InterfaceConnecteurDbSm
	 * @generated
	 */
	public Adapter createInterfaceConnecteurDbSmAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modelM1.AttachementSmDb <em>Attachement Sm Db</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modelM1.AttachementSmDb
	 * @generated
	 */
	public Adapter createAttachementSmDbAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modelM1.PortFourniConfigurationServeur <em>Port Fourni Configuration Serveur</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modelM1.PortFourniConfigurationServeur
	 * @generated
	 */
	public Adapter createPortFourniConfigurationServeurAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modelM1.ServiceFourniClient <em>Service Fourni Client</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modelM1.ServiceFourniClient
	 * @generated
	 */
	public Adapter createServiceFourniClientAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modelM1.InterfaceSecurityManager <em>Interface Security Manager</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modelM1.InterfaceSecurityManager
	 * @generated
	 */
	public Adapter createInterfaceSecurityManagerAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modelM1.BindingExternalSocket <em>Binding External Socket</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modelM1.BindingExternalSocket
	 * @generated
	 */
	public Adapter createBindingExternalSocketAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modelM1.RoleDb <em>Role Db</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modelM1.RoleDb
	 * @generated
	 */
	public Adapter createRoleDbAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modelM1.CheckQuery <em>Check Query</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modelM1.CheckQuery
	 * @generated
	 */
	public Adapter createCheckQueryAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modelM1.AttachementRPCServeur <em>Attachement RPC Serveur</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modelM1.AttachementRPCServeur
	 * @generated
	 */
	public Adapter createAttachementRPCServeurAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modelM1.AttachementClientRPC <em>Attachement Client RPC</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modelM1.AttachementClientRPC
	 * @generated
	 */
	public Adapter createAttachementClientRPCAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modelM1.SecurityManagement <em>Security Management</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modelM1.SecurityManagement
	 * @generated
	 */
	public Adapter createSecurityManagementAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modelM1.PortFourniClient <em>Port Fourni Client</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modelM1.PortFourniClient
	 * @generated
	 */
	public Adapter createPortFourniClientAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modelM1.PortRequisClient <em>Port Requis Client</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modelM1.PortRequisClient
	 * @generated
	 */
	public Adapter createPortRequisClientAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modelM1.AttachementDbSm <em>Attachement Db Sm</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modelM1.AttachementDbSm
	 * @generated
	 */
	public Adapter createAttachementDbSmAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modelM1.SecurityManager <em>Security Manager</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modelM1.SecurityManager
	 * @generated
	 */
	public Adapter createSecurityManagerAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modelM1.RoleCm <em>Role Cm</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modelM1.RoleCm
	 * @generated
	 */
	public Adapter createRoleCmAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modelM1.InterfaceConnectionManager <em>Interface Connection Manager</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modelM1.InterfaceConnectionManager
	 * @generated
	 */
	public Adapter createInterfaceConnectionManagerAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modelM1.InterfaceClient <em>Interface Client</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modelM1.InterfaceClient
	 * @generated
	 */
	public Adapter createInterfaceClientAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modelM1.ExternalSocket <em>External Socket</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modelM1.ExternalSocket
	 * @generated
	 */
	public Adapter createExternalSocketAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modelM1.SystemeClientServeur <em>Systeme Client Serveur</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modelM1.SystemeClientServeur
	 * @generated
	 */
	public Adapter createSystemeClientServeurAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modelM1.ConfigurationServeur <em>Configuration Serveur</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modelM1.ConfigurationServeur
	 * @generated
	 */
	public Adapter createConfigurationServeurAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modelM1.QueryInterogation <em>Query Interogation</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modelM1.QueryInterogation
	 * @generated
	 */
	public Adapter createQueryInterogationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modelM1.InterfaceDatabase <em>Interface Database</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modelM1.InterfaceDatabase
	 * @generated
	 */
	public Adapter createInterfaceDatabaseAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modelM1.Database <em>Database</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modelM1.Database
	 * @generated
	 */
	public Adapter createDatabaseAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modelM1.ConnecteurCmSm <em>Connecteur Cm Sm</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modelM1.ConnecteurCmSm
	 * @generated
	 */
	public Adapter createConnecteurCmSmAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modelM1.InterfaceConnecteurRPC <em>Interface Connecteur RPC</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modelM1.InterfaceConnecteurRPC
	 * @generated
	 */
	public Adapter createInterfaceConnecteurRPCAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modelM1.AttachementCmSm <em>Attachement Cm Sm</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modelM1.AttachementCmSm
	 * @generated
	 */
	public Adapter createAttachementCmSmAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modelM1.AttachementCmDb <em>Attachement Cm Db</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modelM1.AttachementCmDb
	 * @generated
	 */
	public Adapter createAttachementCmDbAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modelM1.InterfaceConnecteurCmDb <em>Interface Connecteur Cm Db</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modelM1.InterfaceConnecteurCmDb
	 * @generated
	 */
	public Adapter createInterfaceConnecteurCmDbAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modelM1.AttachementSmCm <em>Attachement Sm Cm</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modelM1.AttachementSmCm
	 * @generated
	 */
	public Adapter createAttachementSmCmAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modelM1.Client <em>Client</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modelM1.Client
	 * @generated
	 */
	public Adapter createClientAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modelM1.ConnecteurCmDb <em>Connecteur Cm Db</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modelM1.ConnecteurCmDb
	 * @generated
	 */
	public Adapter createConnecteurCmDbAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modelM1.RoleSm <em>Role Sm</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modelM1.RoleSm
	 * @generated
	 */
	public Adapter createRoleSmAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modelM1.SecurityCheck <em>Security Check</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modelM1.SecurityCheck
	 * @generated
	 */
	public Adapter createSecurityCheckAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modelM1.ConnecteurRPC <em>Connecteur RPC</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modelM1.ConnecteurRPC
	 * @generated
	 */
	public Adapter createConnecteurRPCAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modelM1.AttachementDbCm <em>Attachement Db Cm</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modelM1.AttachementDbCm
	 * @generated
	 */
	public Adapter createAttachementDbCmAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modelM1.InterfaceConfigurationServeur <em>Interface Configuration Serveur</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modelM1.InterfaceConfigurationServeur
	 * @generated
	 */
	public Adapter createInterfaceConfigurationServeurAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modelM1.ConnectionManager <em>Connection Manager</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modelM1.ConnectionManager
	 * @generated
	 */
	public Adapter createConnectionManagerAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modelM1.Serveur <em>Serveur</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modelM1.Serveur
	 * @generated
	 */
	public Adapter createServeurAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modelM1.ConnecteurDbSm <em>Connecteur Db Sm</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modelM1.ConnecteurDbSm
	 * @generated
	 */
	public Adapter createConnecteurDbSmAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for the default case.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @generated
	 */
	public Adapter createEObjectAdapter() {
		return null;
	}

} //ModelM1AdapterFactory

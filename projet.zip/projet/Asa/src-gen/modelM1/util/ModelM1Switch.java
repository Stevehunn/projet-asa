/**
 */
package modelM1.util;

import modelM1.AttachementClientRPC;
import modelM1.AttachementCmDb;
import modelM1.AttachementCmSm;
import modelM1.AttachementDbCm;
import modelM1.AttachementDbSm;
import modelM1.AttachementRPCServeur;
import modelM1.AttachementSmCm;
import modelM1.AttachementSmDb;
import modelM1.BindingExternalSocket;
import modelM1.CheckQuery;
import modelM1.Client;
import modelM1.ConfigurationServeur;
import modelM1.ConnecteurCmDb;
import modelM1.ConnecteurCmSm;
import modelM1.ConnecteurDbSm;
import modelM1.ConnecteurRPC;
import modelM1.ConnectionManager;
import modelM1.Database;
import modelM1.DbQuery;
import modelM1.ExternalSocket;
import modelM1.InterfaceClient;
import modelM1.InterfaceConfigurationServeur;
import modelM1.InterfaceConnecteurCmDb;
import modelM1.InterfaceConnecteurCmSm;
import modelM1.InterfaceConnecteurDbSm;
import modelM1.InterfaceConnecteurRPC;
import modelM1.InterfaceConnectionManager;
import modelM1.InterfaceDatabase;
import modelM1.InterfaceSecurityManager;
import modelM1.ModelM1Package;
import modelM1.PortFourniClient;
import modelM1.PortFourniConfigurationServeur;
import modelM1.PortRequisClient;
import modelM1.QueryInterogation;
import modelM1.RoleCm;
import modelM1.RoleDb;
import modelM1.RoleSm;
import modelM1.SecurityAuthentification;
import modelM1.SecurityCheck;
import modelM1.SecurityManagement;
import modelM1.Serveur;
import modelM1.ServiceFourniClient;
import modelM1.SystemeClientServeur;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.Switch;

/**
 * <!-- begin-user-doc -->
 * The <b>Switch</b> for the model's inheritance hierarchy.
 * It supports the call {@link #doSwitch(EObject) doSwitch(object)}
 * to invoke the <code>caseXXX</code> method for each class of the model,
 * starting with the actual class of the object
 * and proceeding up the inheritance hierarchy
 * until a non-null result is returned,
 * which is the result of the switch.
 * <!-- end-user-doc -->
 * @see modelM1.ModelM1Package
 * @generated
 */
public class ModelM1Switch<T> extends Switch<T> {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static ModelM1Package modelPackage;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ModelM1Switch() {
		if (modelPackage == null) {
			modelPackage = ModelM1Package.eINSTANCE;
		}
	}

	/**
	 * Checks whether this is a switch for the given package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param ePackage the package in question.
	 * @return whether this is a switch for the given package.
	 * @generated
	 */
	@Override
	protected boolean isSwitchFor(EPackage ePackage) {
		return ePackage == modelPackage;
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	@Override
	protected T doSwitch(int classifierID, EObject theEObject) {
		switch (classifierID) {
		case ModelM1Package.SECURITY_AUTHENTIFICATION: {
			SecurityAuthentification securityAuthentification = (SecurityAuthentification) theEObject;
			T result = caseSecurityAuthentification(securityAuthentification);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModelM1Package.INTERFACE_CONNECTEUR_CM_SM: {
			InterfaceConnecteurCmSm interfaceConnecteurCmSm = (InterfaceConnecteurCmSm) theEObject;
			T result = caseInterfaceConnecteurCmSm(interfaceConnecteurCmSm);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModelM1Package.DB_QUERY: {
			DbQuery dbQuery = (DbQuery) theEObject;
			T result = caseDbQuery(dbQuery);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModelM1Package.INTERFACE_CONNECTEUR_DB_SM: {
			InterfaceConnecteurDbSm interfaceConnecteurDbSm = (InterfaceConnecteurDbSm) theEObject;
			T result = caseInterfaceConnecteurDbSm(interfaceConnecteurDbSm);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModelM1Package.ATTACHEMENT_SM_DB: {
			AttachementSmDb attachementSmDb = (AttachementSmDb) theEObject;
			T result = caseAttachementSmDb(attachementSmDb);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModelM1Package.PORT_FOURNI_CONFIGURATION_SERVEUR: {
			PortFourniConfigurationServeur portFourniConfigurationServeur = (PortFourniConfigurationServeur) theEObject;
			T result = casePortFourniConfigurationServeur(portFourniConfigurationServeur);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModelM1Package.SERVICE_FOURNI_CLIENT: {
			ServiceFourniClient serviceFourniClient = (ServiceFourniClient) theEObject;
			T result = caseServiceFourniClient(serviceFourniClient);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModelM1Package.INTERFACE_SECURITY_MANAGER: {
			InterfaceSecurityManager interfaceSecurityManager = (InterfaceSecurityManager) theEObject;
			T result = caseInterfaceSecurityManager(interfaceSecurityManager);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModelM1Package.BINDING_EXTERNAL_SOCKET: {
			BindingExternalSocket bindingExternalSocket = (BindingExternalSocket) theEObject;
			T result = caseBindingExternalSocket(bindingExternalSocket);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModelM1Package.ROLE_DB: {
			RoleDb roleDb = (RoleDb) theEObject;
			T result = caseRoleDb(roleDb);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModelM1Package.CHECK_QUERY: {
			CheckQuery checkQuery = (CheckQuery) theEObject;
			T result = caseCheckQuery(checkQuery);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModelM1Package.ATTACHEMENT_RPC_SERVEUR: {
			AttachementRPCServeur attachementRPCServeur = (AttachementRPCServeur) theEObject;
			T result = caseAttachementRPCServeur(attachementRPCServeur);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModelM1Package.ATTACHEMENT_CLIENT_RPC: {
			AttachementClientRPC attachementClientRPC = (AttachementClientRPC) theEObject;
			T result = caseAttachementClientRPC(attachementClientRPC);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModelM1Package.SECURITY_MANAGEMENT: {
			SecurityManagement securityManagement = (SecurityManagement) theEObject;
			T result = caseSecurityManagement(securityManagement);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModelM1Package.PORT_FOURNI_CLIENT: {
			PortFourniClient portFourniClient = (PortFourniClient) theEObject;
			T result = casePortFourniClient(portFourniClient);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModelM1Package.PORT_REQUIS_CLIENT: {
			PortRequisClient portRequisClient = (PortRequisClient) theEObject;
			T result = casePortRequisClient(portRequisClient);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModelM1Package.ATTACHEMENT_DB_SM: {
			AttachementDbSm attachementDbSm = (AttachementDbSm) theEObject;
			T result = caseAttachementDbSm(attachementDbSm);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModelM1Package.SECURITY_MANAGER: {
			modelM1.SecurityManager securityManager = (modelM1.SecurityManager) theEObject;
			T result = caseSecurityManager(securityManager);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModelM1Package.ROLE_CM: {
			RoleCm roleCm = (RoleCm) theEObject;
			T result = caseRoleCm(roleCm);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModelM1Package.INTERFACE_CONNECTION_MANAGER: {
			InterfaceConnectionManager interfaceConnectionManager = (InterfaceConnectionManager) theEObject;
			T result = caseInterfaceConnectionManager(interfaceConnectionManager);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModelM1Package.INTERFACE_CLIENT: {
			InterfaceClient interfaceClient = (InterfaceClient) theEObject;
			T result = caseInterfaceClient(interfaceClient);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModelM1Package.EXTERNAL_SOCKET: {
			ExternalSocket externalSocket = (ExternalSocket) theEObject;
			T result = caseExternalSocket(externalSocket);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModelM1Package.SYSTEME_CLIENT_SERVEUR: {
			SystemeClientServeur systemeClientServeur = (SystemeClientServeur) theEObject;
			T result = caseSystemeClientServeur(systemeClientServeur);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModelM1Package.CONFIGURATION_SERVEUR: {
			ConfigurationServeur configurationServeur = (ConfigurationServeur) theEObject;
			T result = caseConfigurationServeur(configurationServeur);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModelM1Package.QUERY_INTEROGATION: {
			QueryInterogation queryInterogation = (QueryInterogation) theEObject;
			T result = caseQueryInterogation(queryInterogation);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModelM1Package.INTERFACE_DATABASE: {
			InterfaceDatabase interfaceDatabase = (InterfaceDatabase) theEObject;
			T result = caseInterfaceDatabase(interfaceDatabase);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModelM1Package.DATABASE: {
			Database database = (Database) theEObject;
			T result = caseDatabase(database);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModelM1Package.CONNECTEUR_CM_SM: {
			ConnecteurCmSm connecteurCmSm = (ConnecteurCmSm) theEObject;
			T result = caseConnecteurCmSm(connecteurCmSm);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModelM1Package.INTERFACE_CONNECTEUR_RPC: {
			InterfaceConnecteurRPC interfaceConnecteurRPC = (InterfaceConnecteurRPC) theEObject;
			T result = caseInterfaceConnecteurRPC(interfaceConnecteurRPC);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModelM1Package.ATTACHEMENT_CM_SM: {
			AttachementCmSm attachementCmSm = (AttachementCmSm) theEObject;
			T result = caseAttachementCmSm(attachementCmSm);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModelM1Package.ATTACHEMENT_CM_DB: {
			AttachementCmDb attachementCmDb = (AttachementCmDb) theEObject;
			T result = caseAttachementCmDb(attachementCmDb);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModelM1Package.INTERFACE_CONNECTEUR_CM_DB: {
			InterfaceConnecteurCmDb interfaceConnecteurCmDb = (InterfaceConnecteurCmDb) theEObject;
			T result = caseInterfaceConnecteurCmDb(interfaceConnecteurCmDb);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModelM1Package.ATTACHEMENT_SM_CM: {
			AttachementSmCm attachementSmCm = (AttachementSmCm) theEObject;
			T result = caseAttachementSmCm(attachementSmCm);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModelM1Package.CLIENT: {
			Client client = (Client) theEObject;
			T result = caseClient(client);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModelM1Package.CONNECTEUR_CM_DB: {
			ConnecteurCmDb connecteurCmDb = (ConnecteurCmDb) theEObject;
			T result = caseConnecteurCmDb(connecteurCmDb);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModelM1Package.ROLE_SM: {
			RoleSm roleSm = (RoleSm) theEObject;
			T result = caseRoleSm(roleSm);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModelM1Package.SECURITY_CHECK: {
			SecurityCheck securityCheck = (SecurityCheck) theEObject;
			T result = caseSecurityCheck(securityCheck);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModelM1Package.CONNECTEUR_RPC: {
			ConnecteurRPC connecteurRPC = (ConnecteurRPC) theEObject;
			T result = caseConnecteurRPC(connecteurRPC);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModelM1Package.ATTACHEMENT_DB_CM: {
			AttachementDbCm attachementDbCm = (AttachementDbCm) theEObject;
			T result = caseAttachementDbCm(attachementDbCm);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModelM1Package.INTERFACE_CONFIGURATION_SERVEUR: {
			InterfaceConfigurationServeur interfaceConfigurationServeur = (InterfaceConfigurationServeur) theEObject;
			T result = caseInterfaceConfigurationServeur(interfaceConfigurationServeur);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModelM1Package.CONNECTION_MANAGER: {
			ConnectionManager connectionManager = (ConnectionManager) theEObject;
			T result = caseConnectionManager(connectionManager);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModelM1Package.SERVEUR: {
			Serveur serveur = (Serveur) theEObject;
			T result = caseServeur(serveur);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModelM1Package.CONNECTEUR_DB_SM: {
			ConnecteurDbSm connecteurDbSm = (ConnecteurDbSm) theEObject;
			T result = caseConnecteurDbSm(connecteurDbSm);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		default:
			return defaultCase(theEObject);
		}
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Security Authentification</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Security Authentification</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSecurityAuthentification(SecurityAuthentification object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Interface Connecteur Cm Sm</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Interface Connecteur Cm Sm</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseInterfaceConnecteurCmSm(InterfaceConnecteurCmSm object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Db Query</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Db Query</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseDbQuery(DbQuery object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Interface Connecteur Db Sm</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Interface Connecteur Db Sm</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseInterfaceConnecteurDbSm(InterfaceConnecteurDbSm object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Attachement Sm Db</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Attachement Sm Db</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAttachementSmDb(AttachementSmDb object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Port Fourni Configuration Serveur</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Port Fourni Configuration Serveur</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePortFourniConfigurationServeur(PortFourniConfigurationServeur object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Service Fourni Client</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Service Fourni Client</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseServiceFourniClient(ServiceFourniClient object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Interface Security Manager</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Interface Security Manager</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseInterfaceSecurityManager(InterfaceSecurityManager object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Binding External Socket</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Binding External Socket</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseBindingExternalSocket(BindingExternalSocket object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Role Db</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Role Db</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseRoleDb(RoleDb object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Check Query</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Check Query</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseCheckQuery(CheckQuery object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Attachement RPC Serveur</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Attachement RPC Serveur</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAttachementRPCServeur(AttachementRPCServeur object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Attachement Client RPC</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Attachement Client RPC</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAttachementClientRPC(AttachementClientRPC object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Security Management</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Security Management</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSecurityManagement(SecurityManagement object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Port Fourni Client</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Port Fourni Client</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePortFourniClient(PortFourniClient object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Port Requis Client</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Port Requis Client</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePortRequisClient(PortRequisClient object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Attachement Db Sm</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Attachement Db Sm</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAttachementDbSm(AttachementDbSm object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Security Manager</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Security Manager</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSecurityManager(modelM1.SecurityManager object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Role Cm</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Role Cm</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseRoleCm(RoleCm object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Interface Connection Manager</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Interface Connection Manager</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseInterfaceConnectionManager(InterfaceConnectionManager object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Interface Client</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Interface Client</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseInterfaceClient(InterfaceClient object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>External Socket</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>External Socket</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseExternalSocket(ExternalSocket object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Systeme Client Serveur</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Systeme Client Serveur</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSystemeClientServeur(SystemeClientServeur object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Configuration Serveur</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Configuration Serveur</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseConfigurationServeur(ConfigurationServeur object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Query Interogation</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Query Interogation</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseQueryInterogation(QueryInterogation object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Interface Database</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Interface Database</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseInterfaceDatabase(InterfaceDatabase object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Database</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Database</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseDatabase(Database object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Connecteur Cm Sm</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Connecteur Cm Sm</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseConnecteurCmSm(ConnecteurCmSm object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Interface Connecteur RPC</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Interface Connecteur RPC</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseInterfaceConnecteurRPC(InterfaceConnecteurRPC object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Attachement Cm Sm</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Attachement Cm Sm</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAttachementCmSm(AttachementCmSm object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Attachement Cm Db</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Attachement Cm Db</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAttachementCmDb(AttachementCmDb object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Interface Connecteur Cm Db</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Interface Connecteur Cm Db</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseInterfaceConnecteurCmDb(InterfaceConnecteurCmDb object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Attachement Sm Cm</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Attachement Sm Cm</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAttachementSmCm(AttachementSmCm object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Client</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Client</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseClient(Client object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Connecteur Cm Db</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Connecteur Cm Db</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseConnecteurCmDb(ConnecteurCmDb object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Role Sm</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Role Sm</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseRoleSm(RoleSm object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Security Check</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Security Check</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSecurityCheck(SecurityCheck object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Connecteur RPC</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Connecteur RPC</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseConnecteurRPC(ConnecteurRPC object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Attachement Db Cm</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Attachement Db Cm</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAttachementDbCm(AttachementDbCm object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Interface Configuration Serveur</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Interface Configuration Serveur</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseInterfaceConfigurationServeur(InterfaceConfigurationServeur object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Connection Manager</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Connection Manager</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseConnectionManager(ConnectionManager object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Serveur</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Serveur</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseServeur(Serveur object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Connecteur Db Sm</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Connecteur Db Sm</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseConnecteurDbSm(ConnecteurDbSm object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch, but this is the last case anyway.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	@Override
	public T defaultCase(EObject object) {
		return null;
	}

} //ModelM1Switch

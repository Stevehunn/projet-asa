/**
 */
package modelM1;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Attachement Db Sm</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link modelM1.AttachementDbSm#getRolesm <em>Rolesm</em>}</li>
 *   <li>{@link modelM1.AttachementDbSm#getSecuritymanagement <em>Securitymanagement</em>}</li>
 * </ul>
 *
 * @see modelM1.ModelM1Package#getAttachementDbSm()
 * @model
 * @generated
 */
public interface AttachementDbSm extends EObject {
	/**
	 * Returns the value of the '<em><b>Rolesm</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Rolesm</em>' reference.
	 * @see #setRolesm(RoleSm)
	 * @see modelM1.ModelM1Package#getAttachementDbSm_Rolesm()
	 * @model
	 * @generated
	 */
	RoleSm getRolesm();

	/**
	 * Sets the value of the '{@link modelM1.AttachementDbSm#getRolesm <em>Rolesm</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Rolesm</em>' reference.
	 * @see #getRolesm()
	 * @generated
	 */
	void setRolesm(RoleSm value);

	/**
	 * Returns the value of the '<em><b>Securitymanagement</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Securitymanagement</em>' reference.
	 * @see #setSecuritymanagement(SecurityManagement)
	 * @see modelM1.ModelM1Package#getAttachementDbSm_Securitymanagement()
	 * @model
	 * @generated
	 */
	SecurityManagement getSecuritymanagement();

	/**
	 * Sets the value of the '{@link modelM1.AttachementDbSm#getSecuritymanagement <em>Securitymanagement</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Securitymanagement</em>' reference.
	 * @see #getSecuritymanagement()
	 * @generated
	 */
	void setSecuritymanagement(SecurityManagement value);

} // AttachementDbSm

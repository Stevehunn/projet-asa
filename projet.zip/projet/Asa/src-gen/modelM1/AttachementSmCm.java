/**
 */
package modelM1;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Attachement Sm Cm</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link modelM1.AttachementSmCm#getSecurityauthentification <em>Securityauthentification</em>}</li>
 *   <li>{@link modelM1.AttachementSmCm#getRolecm <em>Rolecm</em>}</li>
 * </ul>
 *
 * @see modelM1.ModelM1Package#getAttachementSmCm()
 * @model
 * @generated
 */
public interface AttachementSmCm extends EObject {
	/**
	 * Returns the value of the '<em><b>Securityauthentification</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Securityauthentification</em>' reference.
	 * @see #setSecurityauthentification(SecurityAuthentification)
	 * @see modelM1.ModelM1Package#getAttachementSmCm_Securityauthentification()
	 * @model
	 * @generated
	 */
	SecurityAuthentification getSecurityauthentification();

	/**
	 * Sets the value of the '{@link modelM1.AttachementSmCm#getSecurityauthentification <em>Securityauthentification</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Securityauthentification</em>' reference.
	 * @see #getSecurityauthentification()
	 * @generated
	 */
	void setSecurityauthentification(SecurityAuthentification value);

	/**
	 * Returns the value of the '<em><b>Rolecm</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Rolecm</em>' reference.
	 * @see #setRolecm(RoleCm)
	 * @see modelM1.ModelM1Package#getAttachementSmCm_Rolecm()
	 * @model
	 * @generated
	 */
	RoleCm getRolecm();

	/**
	 * Sets the value of the '{@link modelM1.AttachementSmCm#getRolecm <em>Rolecm</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Rolecm</em>' reference.
	 * @see #getRolecm()
	 * @generated
	 */
	void setRolecm(RoleCm value);

} // AttachementSmCm

/**
 */
package modelM1;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Port Fourni Configuration Serveur</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see modelM1.ModelM1Package#getPortFourniConfigurationServeur()
 * @model
 * @generated
 */
public interface PortFourniConfigurationServeur extends EObject {
} // PortFourniConfigurationServeur

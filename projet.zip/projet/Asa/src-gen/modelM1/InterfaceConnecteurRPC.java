/**
 */
package modelM1;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Interface Connecteur RPC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see modelM1.ModelM1Package#getInterfaceConnecteurRPC()
 * @model
 * @generated
 */
public interface InterfaceConnecteurRPC extends EObject {
} // InterfaceConnecteurRPC

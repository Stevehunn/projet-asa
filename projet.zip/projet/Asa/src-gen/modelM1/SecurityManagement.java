/**
 */
package modelM1;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Security Management</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see modelM1.ModelM1Package#getSecurityManagement()
 * @model
 * @generated
 */
public interface SecurityManagement extends EObject {
} // SecurityManagement

/**
 */
package modelM1;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Systeme Client Serveur</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link modelM1.SystemeClientServeur#getClient <em>Client</em>}</li>
 *   <li>{@link modelM1.SystemeClientServeur#getServeur <em>Serveur</em>}</li>
 *   <li>{@link modelM1.SystemeClientServeur#getConnecteurrpc <em>Connecteurrpc</em>}</li>
 *   <li>{@link modelM1.SystemeClientServeur#getAttachementrpcserveur <em>Attachementrpcserveur</em>}</li>
 * </ul>
 *
 * @see modelM1.ModelM1Package#getSystemeClientServeur()
 * @model
 * @generated
 */
public interface SystemeClientServeur extends EObject {
	/**
	 * Returns the value of the '<em><b>Client</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Client</em>' reference.
	 * @see #setClient(Client)
	 * @see modelM1.ModelM1Package#getSystemeClientServeur_Client()
	 * @model
	 * @generated
	 */
	Client getClient();

	/**
	 * Sets the value of the '{@link modelM1.SystemeClientServeur#getClient <em>Client</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Client</em>' reference.
	 * @see #getClient()
	 * @generated
	 */
	void setClient(Client value);

	/**
	 * Returns the value of the '<em><b>Serveur</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Serveur</em>' reference.
	 * @see #setServeur(Serveur)
	 * @see modelM1.ModelM1Package#getSystemeClientServeur_Serveur()
	 * @model
	 * @generated
	 */
	Serveur getServeur();

	/**
	 * Sets the value of the '{@link modelM1.SystemeClientServeur#getServeur <em>Serveur</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Serveur</em>' reference.
	 * @see #getServeur()
	 * @generated
	 */
	void setServeur(Serveur value);

	/**
	 * Returns the value of the '<em><b>Connecteurrpc</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Connecteurrpc</em>' reference.
	 * @see #setConnecteurrpc(ConnecteurRPC)
	 * @see modelM1.ModelM1Package#getSystemeClientServeur_Connecteurrpc()
	 * @model
	 * @generated
	 */
	ConnecteurRPC getConnecteurrpc();

	/**
	 * Sets the value of the '{@link modelM1.SystemeClientServeur#getConnecteurrpc <em>Connecteurrpc</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Connecteurrpc</em>' reference.
	 * @see #getConnecteurrpc()
	 * @generated
	 */
	void setConnecteurrpc(ConnecteurRPC value);

	/**
	 * Returns the value of the '<em><b>Attachementrpcserveur</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Attachementrpcserveur</em>' reference.
	 * @see #setAttachementrpcserveur(AttachementRPCServeur)
	 * @see modelM1.ModelM1Package#getSystemeClientServeur_Attachementrpcserveur()
	 * @model
	 * @generated
	 */
	AttachementRPCServeur getAttachementrpcserveur();

	/**
	 * Sets the value of the '{@link modelM1.SystemeClientServeur#getAttachementrpcserveur <em>Attachementrpcserveur</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Attachementrpcserveur</em>' reference.
	 * @see #getAttachementrpcserveur()
	 * @generated
	 */
	void setAttachementrpcserveur(AttachementRPCServeur value);

} // SystemeClientServeur

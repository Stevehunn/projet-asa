/**
 */
package modelM1;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Interface Connecteur Db Sm</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link modelM1.InterfaceConnecteurDbSm#getRolesm <em>Rolesm</em>}</li>
 *   <li>{@link modelM1.InterfaceConnecteurDbSm#getRoledb <em>Roledb</em>}</li>
 * </ul>
 *
 * @see modelM1.ModelM1Package#getInterfaceConnecteurDbSm()
 * @model
 * @generated
 */
public interface InterfaceConnecteurDbSm extends EObject {
	/**
	 * Returns the value of the '<em><b>Rolesm</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Rolesm</em>' reference.
	 * @see #setRolesm(RoleSm)
	 * @see modelM1.ModelM1Package#getInterfaceConnecteurDbSm_Rolesm()
	 * @model
	 * @generated
	 */
	RoleSm getRolesm();

	/**
	 * Sets the value of the '{@link modelM1.InterfaceConnecteurDbSm#getRolesm <em>Rolesm</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Rolesm</em>' reference.
	 * @see #getRolesm()
	 * @generated
	 */
	void setRolesm(RoleSm value);

	/**
	 * Returns the value of the '<em><b>Roledb</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Roledb</em>' reference.
	 * @see #setRoledb(RoleDb)
	 * @see modelM1.ModelM1Package#getInterfaceConnecteurDbSm_Roledb()
	 * @model
	 * @generated
	 */
	RoleDb getRoledb();

	/**
	 * Sets the value of the '{@link modelM1.InterfaceConnecteurDbSm#getRoledb <em>Roledb</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Roledb</em>' reference.
	 * @see #getRoledb()
	 * @generated
	 */
	void setRoledb(RoleDb value);

} // InterfaceConnecteurDbSm

/**
 */
package modelM1;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Connecteur RPC</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link modelM1.ConnecteurRPC#getInterfaceconnecteurrpc <em>Interfaceconnecteurrpc</em>}</li>
 * </ul>
 *
 * @see modelM1.ModelM1Package#getConnecteurRPC()
 * @model
 * @generated
 */
public interface ConnecteurRPC extends EObject {
	/**
	 * Returns the value of the '<em><b>Interfaceconnecteurrpc</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Interfaceconnecteurrpc</em>' reference.
	 * @see #setInterfaceconnecteurrpc(InterfaceConnecteurRPC)
	 * @see modelM1.ModelM1Package#getConnecteurRPC_Interfaceconnecteurrpc()
	 * @model
	 * @generated
	 */
	InterfaceConnecteurRPC getInterfaceconnecteurrpc();

	/**
	 * Sets the value of the '{@link modelM1.ConnecteurRPC#getInterfaceconnecteurrpc <em>Interfaceconnecteurrpc</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Interfaceconnecteurrpc</em>' reference.
	 * @see #getInterfaceconnecteurrpc()
	 * @generated
	 */
	void setInterfaceconnecteurrpc(InterfaceConnecteurRPC value);

} // ConnecteurRPC

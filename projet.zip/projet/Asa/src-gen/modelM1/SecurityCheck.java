/**
 */
package modelM1;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Security Check</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see modelM1.ModelM1Package#getSecurityCheck()
 * @model
 * @generated
 */
public interface SecurityCheck extends EObject {
} // SecurityCheck

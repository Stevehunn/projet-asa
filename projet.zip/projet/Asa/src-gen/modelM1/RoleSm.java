/**
 */
package modelM1;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Role Sm</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see modelM1.ModelM1Package#getRoleSm()
 * @model
 * @generated
 */
public interface RoleSm extends EObject {
} // RoleSm

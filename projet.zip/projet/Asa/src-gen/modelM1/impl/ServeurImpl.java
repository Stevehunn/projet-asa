/**
 */
package modelM1.impl;

import modelM1.ConfigurationServeur;
import modelM1.ModelM1Package;
import modelM1.Serveur;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Serveur</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link modelM1.impl.ServeurImpl#getConfigurationserveur <em>Configurationserveur</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ServeurImpl extends MinimalEObjectImpl.Container implements Serveur {
	/**
	 * The cached value of the '{@link #getConfigurationserveur() <em>Configurationserveur</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getConfigurationserveur()
	 * @generated
	 * @ordered
	 */
	protected ConfigurationServeur configurationserveur;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ServeurImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModelM1Package.Literals.SERVEUR;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ConfigurationServeur getConfigurationserveur() {
		if (configurationserveur != null && configurationserveur.eIsProxy()) {
			InternalEObject oldConfigurationserveur = (InternalEObject) configurationserveur;
			configurationserveur = (ConfigurationServeur) eResolveProxy(oldConfigurationserveur);
			if (configurationserveur != oldConfigurationserveur) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ModelM1Package.SERVEUR__CONFIGURATIONSERVEUR, oldConfigurationserveur,
							configurationserveur));
			}
		}
		return configurationserveur;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ConfigurationServeur basicGetConfigurationserveur() {
		return configurationserveur;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setConfigurationserveur(ConfigurationServeur newConfigurationserveur) {
		ConfigurationServeur oldConfigurationserveur = configurationserveur;
		configurationserveur = newConfigurationserveur;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModelM1Package.SERVEUR__CONFIGURATIONSERVEUR,
					oldConfigurationserveur, configurationserveur));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ModelM1Package.SERVEUR__CONFIGURATIONSERVEUR:
			if (resolve)
				return getConfigurationserveur();
			return basicGetConfigurationserveur();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ModelM1Package.SERVEUR__CONFIGURATIONSERVEUR:
			setConfigurationserveur((ConfigurationServeur) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ModelM1Package.SERVEUR__CONFIGURATIONSERVEUR:
			setConfigurationserveur((ConfigurationServeur) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ModelM1Package.SERVEUR__CONFIGURATIONSERVEUR:
			return configurationserveur != null;
		}
		return super.eIsSet(featureID);
	}

} //ServeurImpl

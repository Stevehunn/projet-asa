/**
 */
package modelM1.impl;

import modelM1.Client;
import modelM1.InterfaceClient;
import modelM1.ModelM1Package;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Client</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link modelM1.impl.ClientImpl#getInterfaceclient <em>Interfaceclient</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ClientImpl extends MinimalEObjectImpl.Container implements Client {
	/**
	 * The cached value of the '{@link #getInterfaceclient() <em>Interfaceclient</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInterfaceclient()
	 * @generated
	 * @ordered
	 */
	protected InterfaceClient interfaceclient;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ClientImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModelM1Package.Literals.CLIENT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public InterfaceClient getInterfaceclient() {
		if (interfaceclient != null && interfaceclient.eIsProxy()) {
			InternalEObject oldInterfaceclient = (InternalEObject) interfaceclient;
			interfaceclient = (InterfaceClient) eResolveProxy(oldInterfaceclient);
			if (interfaceclient != oldInterfaceclient) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, ModelM1Package.CLIENT__INTERFACECLIENT,
							oldInterfaceclient, interfaceclient));
			}
		}
		return interfaceclient;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public InterfaceClient basicGetInterfaceclient() {
		return interfaceclient;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setInterfaceclient(InterfaceClient newInterfaceclient) {
		InterfaceClient oldInterfaceclient = interfaceclient;
		interfaceclient = newInterfaceclient;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModelM1Package.CLIENT__INTERFACECLIENT,
					oldInterfaceclient, interfaceclient));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ModelM1Package.CLIENT__INTERFACECLIENT:
			if (resolve)
				return getInterfaceclient();
			return basicGetInterfaceclient();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ModelM1Package.CLIENT__INTERFACECLIENT:
			setInterfaceclient((InterfaceClient) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ModelM1Package.CLIENT__INTERFACECLIENT:
			setInterfaceclient((InterfaceClient) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ModelM1Package.CLIENT__INTERFACECLIENT:
			return interfaceclient != null;
		}
		return super.eIsSet(featureID);
	}

} //ClientImpl

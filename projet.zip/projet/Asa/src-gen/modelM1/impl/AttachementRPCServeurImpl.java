/**
 */
package modelM1.impl;

import modelM1.AttachementRPCServeur;
import modelM1.InterfaceConfigurationServeur;
import modelM1.InterfaceConnecteurRPC;
import modelM1.ModelM1Package;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import asa.impl.RoleRequisImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Attachement RPC Serveur</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link modelM1.impl.AttachementRPCServeurImpl#getInterfaceconnecteurrpc <em>Interfaceconnecteurrpc</em>}</li>
 *   <li>{@link modelM1.impl.AttachementRPCServeurImpl#getInterfaceconfigurationserveur <em>Interfaceconfigurationserveur</em>}</li>
 * </ul>
 *
 * @generated
 */
public class AttachementRPCServeurImpl extends MinimalEObjectImpl.Container implements AttachementRPCServeur {
	/**
	 * The cached value of the '{@link #getInterfaceconnecteurrpc() <em>Interfaceconnecteurrpc</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInterfaceconnecteurrpc()
	 * @generated
	 * @ordered
	 */
	protected InterfaceConnecteurRPC interfaceconnecteurrpc;

	/**
	 * The cached value of the '{@link #getInterfaceconfigurationserveur() <em>Interfaceconfigurationserveur</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInterfaceconfigurationserveur()
	 * @generated
	 * @ordered
	 */
	protected InterfaceConfigurationServeur interfaceconfigurationserveur;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AttachementRPCServeurImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModelM1Package.Literals.ATTACHEMENT_RPC_SERVEUR;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public InterfaceConnecteurRPC getInterfaceconnecteurrpc() {
		if (interfaceconnecteurrpc != null && interfaceconnecteurrpc.eIsProxy()) {
			InternalEObject oldInterfaceconnecteurrpc = (InternalEObject) interfaceconnecteurrpc;
			interfaceconnecteurrpc = (InterfaceConnecteurRPC) eResolveProxy(oldInterfaceconnecteurrpc);
			if (interfaceconnecteurrpc != oldInterfaceconnecteurrpc) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ModelM1Package.ATTACHEMENT_RPC_SERVEUR__INTERFACECONNECTEURRPC, oldInterfaceconnecteurrpc,
							interfaceconnecteurrpc));
			}
		}
		return interfaceconnecteurrpc;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public InterfaceConnecteurRPC basicGetInterfaceconnecteurrpc() {
		return interfaceconnecteurrpc;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setInterfaceconnecteurrpc(InterfaceConnecteurRPC newInterfaceconnecteurrpc) {
		InterfaceConnecteurRPC oldInterfaceconnecteurrpc = interfaceconnecteurrpc;
		interfaceconnecteurrpc = newInterfaceconnecteurrpc;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					ModelM1Package.ATTACHEMENT_RPC_SERVEUR__INTERFACECONNECTEURRPC, oldInterfaceconnecteurrpc,
					interfaceconnecteurrpc));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public InterfaceConfigurationServeur getInterfaceconfigurationserveur() {
		if (interfaceconfigurationserveur != null && interfaceconfigurationserveur.eIsProxy()) {
			InternalEObject oldInterfaceconfigurationserveur = (InternalEObject) interfaceconfigurationserveur;
			interfaceconfigurationserveur = (InterfaceConfigurationServeur) eResolveProxy(
					oldInterfaceconfigurationserveur);
			if (interfaceconfigurationserveur != oldInterfaceconfigurationserveur) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ModelM1Package.ATTACHEMENT_RPC_SERVEUR__INTERFACECONFIGURATIONSERVEUR,
							oldInterfaceconfigurationserveur, interfaceconfigurationserveur));
			}
		}
		return interfaceconfigurationserveur;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public InterfaceConfigurationServeur basicGetInterfaceconfigurationserveur() {
		return interfaceconfigurationserveur;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setInterfaceconfigurationserveur(InterfaceConfigurationServeur newInterfaceconfigurationserveur) {
		InterfaceConfigurationServeur oldInterfaceconfigurationserveur = interfaceconfigurationserveur;
		interfaceconfigurationserveur = newInterfaceconfigurationserveur;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					ModelM1Package.ATTACHEMENT_RPC_SERVEUR__INTERFACECONFIGURATIONSERVEUR,
					oldInterfaceconfigurationserveur, interfaceconfigurationserveur));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ModelM1Package.ATTACHEMENT_RPC_SERVEUR__INTERFACECONNECTEURRPC:
			if (resolve)
				return getInterfaceconnecteurrpc();
			return basicGetInterfaceconnecteurrpc();
		case ModelM1Package.ATTACHEMENT_RPC_SERVEUR__INTERFACECONFIGURATIONSERVEUR:
			if (resolve)
				return getInterfaceconfigurationserveur();
			return basicGetInterfaceconfigurationserveur();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ModelM1Package.ATTACHEMENT_RPC_SERVEUR__INTERFACECONNECTEURRPC:
			setInterfaceconnecteurrpc((InterfaceConnecteurRPC) newValue);
			return;
		case ModelM1Package.ATTACHEMENT_RPC_SERVEUR__INTERFACECONFIGURATIONSERVEUR:
			setInterfaceconfigurationserveur((InterfaceConfigurationServeur) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ModelM1Package.ATTACHEMENT_RPC_SERVEUR__INTERFACECONNECTEURRPC:
			setInterfaceconnecteurrpc((InterfaceConnecteurRPC) null);
			return;
		case ModelM1Package.ATTACHEMENT_RPC_SERVEUR__INTERFACECONFIGURATIONSERVEUR:
			setInterfaceconfigurationserveur((InterfaceConfigurationServeur) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ModelM1Package.ATTACHEMENT_RPC_SERVEUR__INTERFACECONNECTEURRPC:
			return interfaceconnecteurrpc != null;
		case ModelM1Package.ATTACHEMENT_RPC_SERVEUR__INTERFACECONFIGURATIONSERVEUR:
			return interfaceconfigurationserveur != null;
		}
		return super.eIsSet(featureID);
	}

	public void setRoleRequis(RoleRequisImpl roleServeur) {
		// TODO Auto-generated method stub
		
	}

} //AttachementRPCServeurImpl

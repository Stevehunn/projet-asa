/**
 */
package modelM1.impl;

import modelM1.ModelM1Package;
import modelM1.PortRequisClient;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Port Requis Client</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class PortRequisClientImpl extends MinimalEObjectImpl.Container implements PortRequisClient {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PortRequisClientImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModelM1Package.Literals.PORT_REQUIS_CLIENT;
	}

	public void setValue(String string) {
		// TODO Auto-generated method stub
		
	}

} //PortRequisClientImpl

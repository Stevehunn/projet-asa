/**
 */
package modelM1.impl;

import modelM1.ConnecteurCmSm;
import modelM1.InterfaceConnecteurCmSm;
import modelM1.ModelM1Package;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Connecteur Cm Sm</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link modelM1.impl.ConnecteurCmSmImpl#getInterfaceconnecteurcmsm <em>Interfaceconnecteurcmsm</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ConnecteurCmSmImpl extends MinimalEObjectImpl.Container implements ConnecteurCmSm {
	/**
	 * The cached value of the '{@link #getInterfaceconnecteurcmsm() <em>Interfaceconnecteurcmsm</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInterfaceconnecteurcmsm()
	 * @generated
	 * @ordered
	 */
	protected InterfaceConnecteurCmSm interfaceconnecteurcmsm;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ConnecteurCmSmImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModelM1Package.Literals.CONNECTEUR_CM_SM;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public InterfaceConnecteurCmSm getInterfaceconnecteurcmsm() {
		if (interfaceconnecteurcmsm != null && interfaceconnecteurcmsm.eIsProxy()) {
			InternalEObject oldInterfaceconnecteurcmsm = (InternalEObject) interfaceconnecteurcmsm;
			interfaceconnecteurcmsm = (InterfaceConnecteurCmSm) eResolveProxy(oldInterfaceconnecteurcmsm);
			if (interfaceconnecteurcmsm != oldInterfaceconnecteurcmsm) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ModelM1Package.CONNECTEUR_CM_SM__INTERFACECONNECTEURCMSM, oldInterfaceconnecteurcmsm,
							interfaceconnecteurcmsm));
			}
		}
		return interfaceconnecteurcmsm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public InterfaceConnecteurCmSm basicGetInterfaceconnecteurcmsm() {
		return interfaceconnecteurcmsm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setInterfaceconnecteurcmsm(InterfaceConnecteurCmSm newInterfaceconnecteurcmsm) {
		InterfaceConnecteurCmSm oldInterfaceconnecteurcmsm = interfaceconnecteurcmsm;
		interfaceconnecteurcmsm = newInterfaceconnecteurcmsm;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					ModelM1Package.CONNECTEUR_CM_SM__INTERFACECONNECTEURCMSM, oldInterfaceconnecteurcmsm,
					interfaceconnecteurcmsm));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ModelM1Package.CONNECTEUR_CM_SM__INTERFACECONNECTEURCMSM:
			if (resolve)
				return getInterfaceconnecteurcmsm();
			return basicGetInterfaceconnecteurcmsm();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ModelM1Package.CONNECTEUR_CM_SM__INTERFACECONNECTEURCMSM:
			setInterfaceconnecteurcmsm((InterfaceConnecteurCmSm) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ModelM1Package.CONNECTEUR_CM_SM__INTERFACECONNECTEURCMSM:
			setInterfaceconnecteurcmsm((InterfaceConnecteurCmSm) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ModelM1Package.CONNECTEUR_CM_SM__INTERFACECONNECTEURCMSM:
			return interfaceconnecteurcmsm != null;
		}
		return super.eIsSet(featureID);
	}

} //ConnecteurCmSmImpl

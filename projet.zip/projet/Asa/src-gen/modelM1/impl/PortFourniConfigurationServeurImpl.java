/**
 */
package modelM1.impl;

import modelM1.ModelM1Package;
import modelM1.PortFourniConfigurationServeur;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Port Fourni Configuration Serveur</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class PortFourniConfigurationServeurImpl extends MinimalEObjectImpl.Container
		implements PortFourniConfigurationServeur {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PortFourniConfigurationServeurImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModelM1Package.Literals.PORT_FOURNI_CONFIGURATION_SERVEUR;
	}

} //PortFourniConfigurationServeurImpl

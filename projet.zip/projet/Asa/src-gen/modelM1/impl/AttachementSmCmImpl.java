/**
 */
package modelM1.impl;

import modelM1.AttachementSmCm;
import modelM1.ModelM1Package;
import modelM1.RoleCm;
import modelM1.SecurityAuthentification;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Attachement Sm Cm</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link modelM1.impl.AttachementSmCmImpl#getSecurityauthentification <em>Securityauthentification</em>}</li>
 *   <li>{@link modelM1.impl.AttachementSmCmImpl#getRolecm <em>Rolecm</em>}</li>
 * </ul>
 *
 * @generated
 */
public class AttachementSmCmImpl extends MinimalEObjectImpl.Container implements AttachementSmCm {
	/**
	 * The cached value of the '{@link #getSecurityauthentification() <em>Securityauthentification</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSecurityauthentification()
	 * @generated
	 * @ordered
	 */
	protected SecurityAuthentification securityauthentification;

	/**
	 * The cached value of the '{@link #getRolecm() <em>Rolecm</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRolecm()
	 * @generated
	 * @ordered
	 */
	protected RoleCm rolecm;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AttachementSmCmImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModelM1Package.Literals.ATTACHEMENT_SM_CM;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SecurityAuthentification getSecurityauthentification() {
		if (securityauthentification != null && securityauthentification.eIsProxy()) {
			InternalEObject oldSecurityauthentification = (InternalEObject) securityauthentification;
			securityauthentification = (SecurityAuthentification) eResolveProxy(oldSecurityauthentification);
			if (securityauthentification != oldSecurityauthentification) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ModelM1Package.ATTACHEMENT_SM_CM__SECURITYAUTHENTIFICATION, oldSecurityauthentification,
							securityauthentification));
			}
		}
		return securityauthentification;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SecurityAuthentification basicGetSecurityauthentification() {
		return securityauthentification;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setSecurityauthentification(SecurityAuthentification newSecurityauthentification) {
		SecurityAuthentification oldSecurityauthentification = securityauthentification;
		securityauthentification = newSecurityauthentification;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					ModelM1Package.ATTACHEMENT_SM_CM__SECURITYAUTHENTIFICATION, oldSecurityauthentification,
					securityauthentification));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public RoleCm getRolecm() {
		if (rolecm != null && rolecm.eIsProxy()) {
			InternalEObject oldRolecm = (InternalEObject) rolecm;
			rolecm = (RoleCm) eResolveProxy(oldRolecm);
			if (rolecm != oldRolecm) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, ModelM1Package.ATTACHEMENT_SM_CM__ROLECM,
							oldRolecm, rolecm));
			}
		}
		return rolecm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RoleCm basicGetRolecm() {
		return rolecm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setRolecm(RoleCm newRolecm) {
		RoleCm oldRolecm = rolecm;
		rolecm = newRolecm;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModelM1Package.ATTACHEMENT_SM_CM__ROLECM, oldRolecm,
					rolecm));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ModelM1Package.ATTACHEMENT_SM_CM__SECURITYAUTHENTIFICATION:
			if (resolve)
				return getSecurityauthentification();
			return basicGetSecurityauthentification();
		case ModelM1Package.ATTACHEMENT_SM_CM__ROLECM:
			if (resolve)
				return getRolecm();
			return basicGetRolecm();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ModelM1Package.ATTACHEMENT_SM_CM__SECURITYAUTHENTIFICATION:
			setSecurityauthentification((SecurityAuthentification) newValue);
			return;
		case ModelM1Package.ATTACHEMENT_SM_CM__ROLECM:
			setRolecm((RoleCm) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ModelM1Package.ATTACHEMENT_SM_CM__SECURITYAUTHENTIFICATION:
			setSecurityauthentification((SecurityAuthentification) null);
			return;
		case ModelM1Package.ATTACHEMENT_SM_CM__ROLECM:
			setRolecm((RoleCm) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ModelM1Package.ATTACHEMENT_SM_CM__SECURITYAUTHENTIFICATION:
			return securityauthentification != null;
		case ModelM1Package.ATTACHEMENT_SM_CM__ROLECM:
			return rolecm != null;
		}
		return super.eIsSet(featureID);
	}

} //AttachementSmCmImpl

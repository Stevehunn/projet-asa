/**
 */
package modelM1.impl;

import modelM1.InterfaceConnecteurRPC;

import modelM1.ModelM1Package;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;
import asa.*;
import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Interface Connecteur RPC</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class InterfaceConnecteurRPCImpl extends MinimalEObjectImpl.Container implements InterfaceConnecteurRPC {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Role> roles;

	public InterfaceConnecteurRPCImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModelM1Package.Literals.INTERFACE_CONNECTEUR_RPC;
	}

} //InterfaceConnecteurRPCImpl

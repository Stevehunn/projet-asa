/**
 */
package modelM1.impl;

import modelM1.AttachementRPCServeur;
import modelM1.Client;
import modelM1.ConnecteurRPC;
import modelM1.ModelM1Package;
import modelM1.Serveur;
import modelM1.SystemeClientServeur;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Systeme Client Serveur</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link modelM1.impl.SystemeClientServeurImpl#getClient <em>Client</em>}</li>
 *   <li>{@link modelM1.impl.SystemeClientServeurImpl#getServeur <em>Serveur</em>}</li>
 *   <li>{@link modelM1.impl.SystemeClientServeurImpl#getConnecteurrpc <em>Connecteurrpc</em>}</li>
 *   <li>{@link modelM1.impl.SystemeClientServeurImpl#getAttachementrpcserveur <em>Attachementrpcserveur</em>}</li>
 * </ul>
 *
 * @generated
 */
public class SystemeClientServeurImpl extends MinimalEObjectImpl.Container implements SystemeClientServeur {
	/**
	 * The cached value of the '{@link #getClient() <em>Client</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getClient()
	 * @generated
	 * @ordered
	 */
	protected Client client;

	/**
	 * The cached value of the '{@link #getServeur() <em>Serveur</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getServeur()
	 * @generated
	 * @ordered
	 */
	protected Serveur serveur;

	/**
	 * The cached value of the '{@link #getConnecteurrpc() <em>Connecteurrpc</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getConnecteurrpc()
	 * @generated
	 * @ordered
	 */
	protected ConnecteurRPC connecteurrpc;

	/**
	 * The cached value of the '{@link #getAttachementrpcserveur() <em>Attachementrpcserveur</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAttachementrpcserveur()
	 * @generated
	 * @ordered
	 */
	protected AttachementRPCServeur attachementrpcserveur;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SystemeClientServeurImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModelM1Package.Literals.SYSTEME_CLIENT_SERVEUR;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Client getClient() {
		if (client != null && client.eIsProxy()) {
			InternalEObject oldClient = (InternalEObject) client;
			client = (Client) eResolveProxy(oldClient);
			if (client != oldClient) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ModelM1Package.SYSTEME_CLIENT_SERVEUR__CLIENT, oldClient, client));
			}
		}
		return client;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Client basicGetClient() {
		return client;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setClient(Client newClient) {
		Client oldClient = client;
		client = newClient;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModelM1Package.SYSTEME_CLIENT_SERVEUR__CLIENT,
					oldClient, client));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Serveur getServeur() {
		if (serveur != null && serveur.eIsProxy()) {
			InternalEObject oldServeur = (InternalEObject) serveur;
			serveur = (Serveur) eResolveProxy(oldServeur);
			if (serveur != oldServeur) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ModelM1Package.SYSTEME_CLIENT_SERVEUR__SERVEUR, oldServeur, serveur));
			}
		}
		return serveur;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Serveur basicGetServeur() {
		return serveur;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setServeur(Serveur newServeur) {
		Serveur oldServeur = serveur;
		serveur = newServeur;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModelM1Package.SYSTEME_CLIENT_SERVEUR__SERVEUR,
					oldServeur, serveur));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ConnecteurRPC getConnecteurrpc() {
		if (connecteurrpc != null && connecteurrpc.eIsProxy()) {
			InternalEObject oldConnecteurrpc = (InternalEObject) connecteurrpc;
			connecteurrpc = (ConnecteurRPC) eResolveProxy(oldConnecteurrpc);
			if (connecteurrpc != oldConnecteurrpc) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ModelM1Package.SYSTEME_CLIENT_SERVEUR__CONNECTEURRPC, oldConnecteurrpc, connecteurrpc));
			}
		}
		return connecteurrpc;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ConnecteurRPC basicGetConnecteurrpc() {
		return connecteurrpc;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setConnecteurrpc(ConnecteurRPC newConnecteurrpc) {
		ConnecteurRPC oldConnecteurrpc = connecteurrpc;
		connecteurrpc = newConnecteurrpc;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModelM1Package.SYSTEME_CLIENT_SERVEUR__CONNECTEURRPC,
					oldConnecteurrpc, connecteurrpc));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public AttachementRPCServeur getAttachementrpcserveur() {
		if (attachementrpcserveur != null && attachementrpcserveur.eIsProxy()) {
			InternalEObject oldAttachementrpcserveur = (InternalEObject) attachementrpcserveur;
			attachementrpcserveur = (AttachementRPCServeur) eResolveProxy(oldAttachementrpcserveur);
			if (attachementrpcserveur != oldAttachementrpcserveur) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ModelM1Package.SYSTEME_CLIENT_SERVEUR__ATTACHEMENTRPCSERVEUR, oldAttachementrpcserveur,
							attachementrpcserveur));
			}
		}
		return attachementrpcserveur;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AttachementRPCServeur basicGetAttachementrpcserveur() {
		return attachementrpcserveur;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setAttachementrpcserveur(AttachementRPCServeur newAttachementrpcserveur) {
		AttachementRPCServeur oldAttachementrpcserveur = attachementrpcserveur;
		attachementrpcserveur = newAttachementrpcserveur;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					ModelM1Package.SYSTEME_CLIENT_SERVEUR__ATTACHEMENTRPCSERVEUR, oldAttachementrpcserveur,
					attachementrpcserveur));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ModelM1Package.SYSTEME_CLIENT_SERVEUR__CLIENT:
			if (resolve)
				return getClient();
			return basicGetClient();
		case ModelM1Package.SYSTEME_CLIENT_SERVEUR__SERVEUR:
			if (resolve)
				return getServeur();
			return basicGetServeur();
		case ModelM1Package.SYSTEME_CLIENT_SERVEUR__CONNECTEURRPC:
			if (resolve)
				return getConnecteurrpc();
			return basicGetConnecteurrpc();
		case ModelM1Package.SYSTEME_CLIENT_SERVEUR__ATTACHEMENTRPCSERVEUR:
			if (resolve)
				return getAttachementrpcserveur();
			return basicGetAttachementrpcserveur();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ModelM1Package.SYSTEME_CLIENT_SERVEUR__CLIENT:
			setClient((Client) newValue);
			return;
		case ModelM1Package.SYSTEME_CLIENT_SERVEUR__SERVEUR:
			setServeur((Serveur) newValue);
			return;
		case ModelM1Package.SYSTEME_CLIENT_SERVEUR__CONNECTEURRPC:
			setConnecteurrpc((ConnecteurRPC) newValue);
			return;
		case ModelM1Package.SYSTEME_CLIENT_SERVEUR__ATTACHEMENTRPCSERVEUR:
			setAttachementrpcserveur((AttachementRPCServeur) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ModelM1Package.SYSTEME_CLIENT_SERVEUR__CLIENT:
			setClient((Client) null);
			return;
		case ModelM1Package.SYSTEME_CLIENT_SERVEUR__SERVEUR:
			setServeur((Serveur) null);
			return;
		case ModelM1Package.SYSTEME_CLIENT_SERVEUR__CONNECTEURRPC:
			setConnecteurrpc((ConnecteurRPC) null);
			return;
		case ModelM1Package.SYSTEME_CLIENT_SERVEUR__ATTACHEMENTRPCSERVEUR:
			setAttachementrpcserveur((AttachementRPCServeur) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ModelM1Package.SYSTEME_CLIENT_SERVEUR__CLIENT:
			return client != null;
		case ModelM1Package.SYSTEME_CLIENT_SERVEUR__SERVEUR:
			return serveur != null;
		case ModelM1Package.SYSTEME_CLIENT_SERVEUR__CONNECTEURRPC:
			return connecteurrpc != null;
		case ModelM1Package.SYSTEME_CLIENT_SERVEUR__ATTACHEMENTRPCSERVEUR:
			return attachementrpcserveur != null;
		}
		return super.eIsSet(featureID);
	}

	public void setComposantFeuilleClient(ClientImpl client2) {
		// TODO Auto-generated method stub
		
	}

	public void setComposantCompositeServeur(ServeurImpl serveur2) {
		// TODO Auto-generated method stub
		
	}

	public void setAttachementrpcclient(AttachementClientRPCImpl attachRPCClient) {
		// TODO Auto-generated method stub
		
	}

} //SystemeClientServeurImpl

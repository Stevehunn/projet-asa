/**
 */
package modelM1.impl;

import modelM1.AttachementClientRPC;
import modelM1.AttachementCmDb;
import modelM1.AttachementCmSm;
import modelM1.AttachementDbCm;
import modelM1.AttachementDbSm;
import modelM1.AttachementRPCServeur;
import modelM1.AttachementSmCm;
import modelM1.AttachementSmDb;
import modelM1.BindingExternalSocket;
import modelM1.CheckQuery;
import modelM1.Client;
import modelM1.ConfigurationServeur;
import modelM1.ConnecteurCmDb;
import modelM1.ConnecteurCmSm;
import modelM1.ConnecteurDbSm;
import modelM1.ConnecteurRPC;
import modelM1.ConnectionManager;
import modelM1.Database;
import modelM1.DbQuery;
import modelM1.ExternalSocket;
import modelM1.InterfaceClient;
import modelM1.InterfaceConfigurationServeur;
import modelM1.InterfaceConnecteurCmDb;
import modelM1.InterfaceConnecteurCmSm;
import modelM1.InterfaceConnecteurDbSm;
import modelM1.InterfaceConnecteurRPC;
import modelM1.InterfaceConnectionManager;
import modelM1.InterfaceDatabase;
import modelM1.InterfaceSecurityManager;
import modelM1.ModelM1Factory;
import modelM1.ModelM1Package;
import modelM1.PortFourniClient;
import modelM1.PortFourniConfigurationServeur;
import modelM1.PortRequisClient;
import modelM1.QueryInterogation;
import modelM1.RoleCm;
import modelM1.RoleDb;
import modelM1.RoleSm;
import modelM1.SecurityAuthentification;
import modelM1.SecurityCheck;
import modelM1.SecurityManagement;
import modelM1.Serveur;
import modelM1.ServiceFourniClient;
import modelM1.SystemeClientServeur;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class ModelM1FactoryImpl extends EFactoryImpl implements ModelM1Factory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static ModelM1Factory init() {
		try {
			ModelM1Factory theModelM1Factory = (ModelM1Factory) EPackage.Registry.INSTANCE
					.getEFactory(ModelM1Package.eNS_URI);
			if (theModelM1Factory != null) {
				return theModelM1Factory;
			}
		} catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new ModelM1FactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ModelM1FactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		case ModelM1Package.SECURITY_AUTHENTIFICATION:
			return createSecurityAuthentification();
		case ModelM1Package.INTERFACE_CONNECTEUR_CM_SM:
			return createInterfaceConnecteurCmSm();
		case ModelM1Package.DB_QUERY:
			return createDbQuery();
		case ModelM1Package.INTERFACE_CONNECTEUR_DB_SM:
			return createInterfaceConnecteurDbSm();
		case ModelM1Package.ATTACHEMENT_SM_DB:
			return createAttachementSmDb();
		case ModelM1Package.PORT_FOURNI_CONFIGURATION_SERVEUR:
			return createPortFourniConfigurationServeur();
		case ModelM1Package.SERVICE_FOURNI_CLIENT:
			return createServiceFourniClient();
		case ModelM1Package.INTERFACE_SECURITY_MANAGER:
			return createInterfaceSecurityManager();
		case ModelM1Package.BINDING_EXTERNAL_SOCKET:
			return createBindingExternalSocket();
		case ModelM1Package.ROLE_DB:
			return createRoleDb();
		case ModelM1Package.CHECK_QUERY:
			return createCheckQuery();
		case ModelM1Package.ATTACHEMENT_RPC_SERVEUR:
			return createAttachementRPCServeur();
		case ModelM1Package.ATTACHEMENT_CLIENT_RPC:
			return createAttachementClientRPC();
		case ModelM1Package.SECURITY_MANAGEMENT:
			return createSecurityManagement();
		case ModelM1Package.PORT_FOURNI_CLIENT:
			return createPortFourniClient();
		case ModelM1Package.PORT_REQUIS_CLIENT:
			return createPortRequisClient();
		case ModelM1Package.ATTACHEMENT_DB_SM:
			return createAttachementDbSm();
		case ModelM1Package.SECURITY_MANAGER:
			return createSecurityManager();
		case ModelM1Package.ROLE_CM:
			return createRoleCm();
		case ModelM1Package.INTERFACE_CONNECTION_MANAGER:
			return createInterfaceConnectionManager();
		case ModelM1Package.INTERFACE_CLIENT:
			return createInterfaceClient();
		case ModelM1Package.EXTERNAL_SOCKET:
			return createExternalSocket();
		case ModelM1Package.SYSTEME_CLIENT_SERVEUR:
			return createSystemeClientServeur();
		case ModelM1Package.CONFIGURATION_SERVEUR:
			return createConfigurationServeur();
		case ModelM1Package.QUERY_INTEROGATION:
			return createQueryInterogation();
		case ModelM1Package.INTERFACE_DATABASE:
			return createInterfaceDatabase();
		case ModelM1Package.DATABASE:
			return createDatabase();
		case ModelM1Package.CONNECTEUR_CM_SM:
			return createConnecteurCmSm();
		case ModelM1Package.INTERFACE_CONNECTEUR_RPC:
			return createInterfaceConnecteurRPC();
		case ModelM1Package.ATTACHEMENT_CM_SM:
			return createAttachementCmSm();
		case ModelM1Package.ATTACHEMENT_CM_DB:
			return createAttachementCmDb();
		case ModelM1Package.INTERFACE_CONNECTEUR_CM_DB:
			return createInterfaceConnecteurCmDb();
		case ModelM1Package.ATTACHEMENT_SM_CM:
			return createAttachementSmCm();
		case ModelM1Package.CLIENT:
			return createClient();
		case ModelM1Package.CONNECTEUR_CM_DB:
			return createConnecteurCmDb();
		case ModelM1Package.ROLE_SM:
			return createRoleSm();
		case ModelM1Package.SECURITY_CHECK:
			return createSecurityCheck();
		case ModelM1Package.CONNECTEUR_RPC:
			return createConnecteurRPC();
		case ModelM1Package.ATTACHEMENT_DB_CM:
			return createAttachementDbCm();
		case ModelM1Package.INTERFACE_CONFIGURATION_SERVEUR:
			return createInterfaceConfigurationServeur();
		case ModelM1Package.CONNECTION_MANAGER:
			return createConnectionManager();
		case ModelM1Package.SERVEUR:
			return createServeur();
		case ModelM1Package.CONNECTEUR_DB_SM:
			return createConnecteurDbSm();
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SecurityAuthentification createSecurityAuthentification() {
		SecurityAuthentificationImpl securityAuthentification = new SecurityAuthentificationImpl();
		return securityAuthentification;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public InterfaceConnecteurCmSm createInterfaceConnecteurCmSm() {
		InterfaceConnecteurCmSmImpl interfaceConnecteurCmSm = new InterfaceConnecteurCmSmImpl();
		return interfaceConnecteurCmSm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public DbQuery createDbQuery() {
		DbQueryImpl dbQuery = new DbQueryImpl();
		return dbQuery;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public InterfaceConnecteurDbSm createInterfaceConnecteurDbSm() {
		InterfaceConnecteurDbSmImpl interfaceConnecteurDbSm = new InterfaceConnecteurDbSmImpl();
		return interfaceConnecteurDbSm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public AttachementSmDb createAttachementSmDb() {
		AttachementSmDbImpl attachementSmDb = new AttachementSmDbImpl();
		return attachementSmDb;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public PortFourniConfigurationServeur createPortFourniConfigurationServeur() {
		PortFourniConfigurationServeurImpl portFourniConfigurationServeur = new PortFourniConfigurationServeurImpl();
		return portFourniConfigurationServeur;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ServiceFourniClient createServiceFourniClient() {
		ServiceFourniClientImpl serviceFourniClient = new ServiceFourniClientImpl();
		return serviceFourniClient;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public InterfaceSecurityManager createInterfaceSecurityManager() {
		InterfaceSecurityManagerImpl interfaceSecurityManager = new InterfaceSecurityManagerImpl();
		return interfaceSecurityManager;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public BindingExternalSocket createBindingExternalSocket() {
		BindingExternalSocketImpl bindingExternalSocket = new BindingExternalSocketImpl();
		return bindingExternalSocket;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public RoleDb createRoleDb() {
		RoleDbImpl roleDb = new RoleDbImpl();
		return roleDb;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public CheckQuery createCheckQuery() {
		CheckQueryImpl checkQuery = new CheckQueryImpl();
		return checkQuery;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public AttachementRPCServeur createAttachementRPCServeur() {
		AttachementRPCServeurImpl attachementRPCServeur = new AttachementRPCServeurImpl();
		return attachementRPCServeur;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public AttachementClientRPC createAttachementClientRPC() {
		AttachementClientRPCImpl attachementClientRPC = new AttachementClientRPCImpl();
		return attachementClientRPC;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SecurityManagement createSecurityManagement() {
		SecurityManagementImpl securityManagement = new SecurityManagementImpl();
		return securityManagement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public PortFourniClient createPortFourniClient() {
		PortFourniClientImpl portFourniClient = new PortFourniClientImpl();
		return portFourniClient;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public PortRequisClient createPortRequisClient() {
		PortRequisClientImpl portRequisClient = new PortRequisClientImpl();
		return portRequisClient;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public AttachementDbSm createAttachementDbSm() {
		AttachementDbSmImpl attachementDbSm = new AttachementDbSmImpl();
		return attachementDbSm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public modelM1.SecurityManager createSecurityManager() {
		SecurityManagerImpl securityManager = new SecurityManagerImpl();
		return securityManager;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public RoleCm createRoleCm() {
		RoleCmImpl roleCm = new RoleCmImpl();
		return roleCm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public InterfaceConnectionManager createInterfaceConnectionManager() {
		InterfaceConnectionManagerImpl interfaceConnectionManager = new InterfaceConnectionManagerImpl();
		return interfaceConnectionManager;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public InterfaceClient createInterfaceClient() {
		InterfaceClientImpl interfaceClient = new InterfaceClientImpl();
		return interfaceClient;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ExternalSocket createExternalSocket() {
		ExternalSocketImpl externalSocket = new ExternalSocketImpl();
		return externalSocket;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SystemeClientServeur createSystemeClientServeur() {
		SystemeClientServeurImpl systemeClientServeur = new SystemeClientServeurImpl();
		return systemeClientServeur;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ConfigurationServeur createConfigurationServeur() {
		ConfigurationServeurImpl configurationServeur = new ConfigurationServeurImpl();
		return configurationServeur;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public QueryInterogation createQueryInterogation() {
		QueryInterogationImpl queryInterogation = new QueryInterogationImpl();
		return queryInterogation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public InterfaceDatabase createInterfaceDatabase() {
		InterfaceDatabaseImpl interfaceDatabase = new InterfaceDatabaseImpl();
		return interfaceDatabase;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Database createDatabase() {
		DatabaseImpl database = new DatabaseImpl();
		return database;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ConnecteurCmSm createConnecteurCmSm() {
		ConnecteurCmSmImpl connecteurCmSm = new ConnecteurCmSmImpl();
		return connecteurCmSm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public InterfaceConnecteurRPC createInterfaceConnecteurRPC() {
		InterfaceConnecteurRPCImpl interfaceConnecteurRPC = new InterfaceConnecteurRPCImpl();
		return interfaceConnecteurRPC;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public AttachementCmSm createAttachementCmSm() {
		AttachementCmSmImpl attachementCmSm = new AttachementCmSmImpl();
		return attachementCmSm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public AttachementCmDb createAttachementCmDb() {
		AttachementCmDbImpl attachementCmDb = new AttachementCmDbImpl();
		return attachementCmDb;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public InterfaceConnecteurCmDb createInterfaceConnecteurCmDb() {
		InterfaceConnecteurCmDbImpl interfaceConnecteurCmDb = new InterfaceConnecteurCmDbImpl();
		return interfaceConnecteurCmDb;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public AttachementSmCm createAttachementSmCm() {
		AttachementSmCmImpl attachementSmCm = new AttachementSmCmImpl();
		return attachementSmCm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Client createClient() {
		ClientImpl client = new ClientImpl();
		return client;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ConnecteurCmDb createConnecteurCmDb() {
		ConnecteurCmDbImpl connecteurCmDb = new ConnecteurCmDbImpl();
		return connecteurCmDb;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public RoleSm createRoleSm() {
		RoleSmImpl roleSm = new RoleSmImpl();
		return roleSm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SecurityCheck createSecurityCheck() {
		SecurityCheckImpl securityCheck = new SecurityCheckImpl();
		return securityCheck;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ConnecteurRPC createConnecteurRPC() {
		ConnecteurRPCImpl connecteurRPC = new ConnecteurRPCImpl();
		return connecteurRPC;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public AttachementDbCm createAttachementDbCm() {
		AttachementDbCmImpl attachementDbCm = new AttachementDbCmImpl();
		return attachementDbCm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public InterfaceConfigurationServeur createInterfaceConfigurationServeur() {
		InterfaceConfigurationServeurImpl interfaceConfigurationServeur = new InterfaceConfigurationServeurImpl();
		return interfaceConfigurationServeur;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ConnectionManager createConnectionManager() {
		ConnectionManagerImpl connectionManager = new ConnectionManagerImpl();
		return connectionManager;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Serveur createServeur() {
		ServeurImpl serveur = new ServeurImpl();
		return serveur;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ConnecteurDbSm createConnecteurDbSm() {
		ConnecteurDbSmImpl connecteurDbSm = new ConnecteurDbSmImpl();
		return connecteurDbSm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ModelM1Package getModelM1Package() {
		return (ModelM1Package) getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static ModelM1Package getPackage() {
		return ModelM1Package.eINSTANCE;
	}

} //ModelM1FactoryImpl

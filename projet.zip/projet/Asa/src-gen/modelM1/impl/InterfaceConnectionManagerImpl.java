/**
 */
package modelM1.impl;

import modelM1.DbQuery;
import modelM1.ExternalSocket;
import modelM1.InterfaceConnectionManager;
import modelM1.ModelM1Package;
import modelM1.SecurityCheck;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Interface Connection Manager</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link modelM1.impl.InterfaceConnectionManagerImpl#getExternalsocket <em>Externalsocket</em>}</li>
 *   <li>{@link modelM1.impl.InterfaceConnectionManagerImpl#getDbquery <em>Dbquery</em>}</li>
 *   <li>{@link modelM1.impl.InterfaceConnectionManagerImpl#getSecuritycheck <em>Securitycheck</em>}</li>
 * </ul>
 *
 * @generated
 */
public class InterfaceConnectionManagerImpl extends MinimalEObjectImpl.Container implements InterfaceConnectionManager {
	/**
	 * The cached value of the '{@link #getExternalsocket() <em>Externalsocket</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getExternalsocket()
	 * @generated
	 * @ordered
	 */
	protected ExternalSocket externalsocket;

	/**
	 * The cached value of the '{@link #getDbquery() <em>Dbquery</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDbquery()
	 * @generated
	 * @ordered
	 */
	protected DbQuery dbquery;

	/**
	 * The cached value of the '{@link #getSecuritycheck() <em>Securitycheck</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSecuritycheck()
	 * @generated
	 * @ordered
	 */
	protected SecurityCheck securitycheck;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected InterfaceConnectionManagerImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModelM1Package.Literals.INTERFACE_CONNECTION_MANAGER;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ExternalSocket getExternalsocket() {
		if (externalsocket != null && externalsocket.eIsProxy()) {
			InternalEObject oldExternalsocket = (InternalEObject) externalsocket;
			externalsocket = (ExternalSocket) eResolveProxy(oldExternalsocket);
			if (externalsocket != oldExternalsocket) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ModelM1Package.INTERFACE_CONNECTION_MANAGER__EXTERNALSOCKET, oldExternalsocket,
							externalsocket));
			}
		}
		return externalsocket;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ExternalSocket basicGetExternalsocket() {
		return externalsocket;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setExternalsocket(ExternalSocket newExternalsocket) {
		ExternalSocket oldExternalsocket = externalsocket;
		externalsocket = newExternalsocket;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					ModelM1Package.INTERFACE_CONNECTION_MANAGER__EXTERNALSOCKET, oldExternalsocket, externalsocket));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public DbQuery getDbquery() {
		if (dbquery != null && dbquery.eIsProxy()) {
			InternalEObject oldDbquery = (InternalEObject) dbquery;
			dbquery = (DbQuery) eResolveProxy(oldDbquery);
			if (dbquery != oldDbquery) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ModelM1Package.INTERFACE_CONNECTION_MANAGER__DBQUERY, oldDbquery, dbquery));
			}
		}
		return dbquery;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DbQuery basicGetDbquery() {
		return dbquery;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setDbquery(DbQuery newDbquery) {
		DbQuery oldDbquery = dbquery;
		dbquery = newDbquery;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModelM1Package.INTERFACE_CONNECTION_MANAGER__DBQUERY,
					oldDbquery, dbquery));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SecurityCheck getSecuritycheck() {
		if (securitycheck != null && securitycheck.eIsProxy()) {
			InternalEObject oldSecuritycheck = (InternalEObject) securitycheck;
			securitycheck = (SecurityCheck) eResolveProxy(oldSecuritycheck);
			if (securitycheck != oldSecuritycheck) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ModelM1Package.INTERFACE_CONNECTION_MANAGER__SECURITYCHECK, oldSecuritycheck,
							securitycheck));
			}
		}
		return securitycheck;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SecurityCheck basicGetSecuritycheck() {
		return securitycheck;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setSecuritycheck(SecurityCheck newSecuritycheck) {
		SecurityCheck oldSecuritycheck = securitycheck;
		securitycheck = newSecuritycheck;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					ModelM1Package.INTERFACE_CONNECTION_MANAGER__SECURITYCHECK, oldSecuritycheck, securitycheck));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ModelM1Package.INTERFACE_CONNECTION_MANAGER__EXTERNALSOCKET:
			if (resolve)
				return getExternalsocket();
			return basicGetExternalsocket();
		case ModelM1Package.INTERFACE_CONNECTION_MANAGER__DBQUERY:
			if (resolve)
				return getDbquery();
			return basicGetDbquery();
		case ModelM1Package.INTERFACE_CONNECTION_MANAGER__SECURITYCHECK:
			if (resolve)
				return getSecuritycheck();
			return basicGetSecuritycheck();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ModelM1Package.INTERFACE_CONNECTION_MANAGER__EXTERNALSOCKET:
			setExternalsocket((ExternalSocket) newValue);
			return;
		case ModelM1Package.INTERFACE_CONNECTION_MANAGER__DBQUERY:
			setDbquery((DbQuery) newValue);
			return;
		case ModelM1Package.INTERFACE_CONNECTION_MANAGER__SECURITYCHECK:
			setSecuritycheck((SecurityCheck) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ModelM1Package.INTERFACE_CONNECTION_MANAGER__EXTERNALSOCKET:
			setExternalsocket((ExternalSocket) null);
			return;
		case ModelM1Package.INTERFACE_CONNECTION_MANAGER__DBQUERY:
			setDbquery((DbQuery) null);
			return;
		case ModelM1Package.INTERFACE_CONNECTION_MANAGER__SECURITYCHECK:
			setSecuritycheck((SecurityCheck) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ModelM1Package.INTERFACE_CONNECTION_MANAGER__EXTERNALSOCKET:
			return externalsocket != null;
		case ModelM1Package.INTERFACE_CONNECTION_MANAGER__DBQUERY:
			return dbquery != null;
		case ModelM1Package.INTERFACE_CONNECTION_MANAGER__SECURITYCHECK:
			return securitycheck != null;
		}
		return super.eIsSet(featureID);
	}

} //InterfaceConnectionManagerImpl

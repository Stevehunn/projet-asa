/**
 */
package modelM1.impl;

import modelM1.AttachementClientRPC;
import modelM1.AttachementCmDb;
import modelM1.AttachementCmSm;
import modelM1.AttachementDbCm;
import modelM1.AttachementDbSm;
import modelM1.AttachementRPCServeur;
import modelM1.AttachementSmCm;
import modelM1.AttachementSmDb;
import modelM1.BindingExternalSocket;
import modelM1.CheckQuery;
import modelM1.Client;
import modelM1.ConfigurationServeur;
import modelM1.ConnecteurCmDb;
import modelM1.ConnecteurCmSm;
import modelM1.ConnecteurDbSm;
import modelM1.ConnecteurRPC;
import modelM1.ConnectionManager;
import modelM1.Database;
import modelM1.DbQuery;
import modelM1.ExternalSocket;
import modelM1.InterfaceClient;
import modelM1.InterfaceConfigurationServeur;
import modelM1.InterfaceConnecteurCmDb;
import modelM1.InterfaceConnecteurCmSm;
import modelM1.InterfaceConnecteurDbSm;
import modelM1.InterfaceConnecteurRPC;
import modelM1.InterfaceConnectionManager;
import modelM1.InterfaceDatabase;
import modelM1.InterfaceSecurityManager;
import modelM1.ModelM1Factory;
import modelM1.ModelM1Package;
import modelM1.PortFourniClient;
import modelM1.PortFourniConfigurationServeur;
import modelM1.PortRequisClient;
import modelM1.QueryInterogation;
import modelM1.RoleCm;
import modelM1.RoleDb;
import modelM1.RoleSm;
import modelM1.SecurityAuthentification;
import modelM1.SecurityCheck;
import modelM1.SecurityManagement;
import modelM1.Serveur;
import modelM1.ServiceFourniClient;
import modelM1.SystemeClientServeur;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class ModelM1PackageImpl extends EPackageImpl implements ModelM1Package {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass securityAuthentificationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass interfaceConnecteurCmSmEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass dbQueryEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass interfaceConnecteurDbSmEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass attachementSmDbEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass portFourniConfigurationServeurEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass serviceFourniClientEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass interfaceSecurityManagerEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass bindingExternalSocketEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass roleDbEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass checkQueryEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass attachementRPCServeurEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass attachementClientRPCEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass securityManagementEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass portFourniClientEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass portRequisClientEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass attachementDbSmEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass securityManagerEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass roleCmEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass interfaceConnectionManagerEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass interfaceClientEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass externalSocketEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass systemeClientServeurEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass configurationServeurEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass queryInterogationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass interfaceDatabaseEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass databaseEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass connecteurCmSmEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass interfaceConnecteurRPCEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass attachementCmSmEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass attachementCmDbEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass interfaceConnecteurCmDbEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass attachementSmCmEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass clientEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass connecteurCmDbEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass roleSmEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass securityCheckEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass connecteurRPCEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass attachementDbCmEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass interfaceConfigurationServeurEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass connectionManagerEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass serveurEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass connecteurDbSmEClass = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see modelM1.ModelM1Package#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private ModelM1PackageImpl() {
		super(eNS_URI, ModelM1Factory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 *
	 * <p>This method is used to initialize {@link ModelM1Package#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static ModelM1Package init() {
		if (isInited)
			return (ModelM1Package) EPackage.Registry.INSTANCE.getEPackage(ModelM1Package.eNS_URI);

		// Obtain or create and register package
		Object registeredModelM1Package = EPackage.Registry.INSTANCE.get(eNS_URI);
		ModelM1PackageImpl theModelM1Package = registeredModelM1Package instanceof ModelM1PackageImpl
				? (ModelM1PackageImpl) registeredModelM1Package
				: new ModelM1PackageImpl();

		isInited = true;

		// Create package meta-data objects
		theModelM1Package.createPackageContents();

		// Initialize created meta-data
		theModelM1Package.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theModelM1Package.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(ModelM1Package.eNS_URI, theModelM1Package);
		return theModelM1Package;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getSecurityAuthentification() {
		return securityAuthentificationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getInterfaceConnecteurCmSm() {
		return interfaceConnecteurCmSmEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getInterfaceConnecteurCmSm_Rolecm() {
		return (EReference) interfaceConnecteurCmSmEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getInterfaceConnecteurCmSm_Rolesm() {
		return (EReference) interfaceConnecteurCmSmEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getDbQuery() {
		return dbQueryEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getInterfaceConnecteurDbSm() {
		return interfaceConnecteurDbSmEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getInterfaceConnecteurDbSm_Rolesm() {
		return (EReference) interfaceConnecteurDbSmEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getInterfaceConnecteurDbSm_Roledb() {
		return (EReference) interfaceConnecteurDbSmEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getAttachementSmDb() {
		return attachementSmDbEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getAttachementSmDb_Checkquery() {
		return (EReference) attachementSmDbEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getAttachementSmDb_Roledb() {
		return (EReference) attachementSmDbEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getPortFourniConfigurationServeur() {
		return portFourniConfigurationServeurEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getServiceFourniClient() {
		return serviceFourniClientEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getInterfaceSecurityManager() {
		return interfaceSecurityManagerEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getInterfaceSecurityManager_Checkquery() {
		return (EReference) interfaceSecurityManagerEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getInterfaceSecurityManager_Securityauthentification() {
		return (EReference) interfaceSecurityManagerEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getBindingExternalSocket() {
		return bindingExternalSocketEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getBindingExternalSocket_Externalsocket() {
		return (EReference) bindingExternalSocketEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getBindingExternalSocket_Portfourniconfigurationserveur() {
		return (EReference) bindingExternalSocketEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getRoleDb() {
		return roleDbEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getCheckQuery() {
		return checkQueryEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getAttachementRPCServeur() {
		return attachementRPCServeurEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getAttachementRPCServeur_Interfaceconnecteurrpc() {
		return (EReference) attachementRPCServeurEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getAttachementRPCServeur_Interfaceconfigurationserveur() {
		return (EReference) attachementRPCServeurEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getAttachementClientRPC() {
		return attachementClientRPCEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getAttachementClientRPC_Interfaceconnecteurrpc() {
		return (EReference) attachementClientRPCEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getSecurityManagement() {
		return securityManagementEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getPortFourniClient() {
		return portFourniClientEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getPortRequisClient() {
		return portRequisClientEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getAttachementDbSm() {
		return attachementDbSmEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getAttachementDbSm_Rolesm() {
		return (EReference) attachementDbSmEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getAttachementDbSm_Securitymanagement() {
		return (EReference) attachementDbSmEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getSecurityManager() {
		return securityManagerEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getRoleCm() {
		return roleCmEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getInterfaceConnectionManager() {
		return interfaceConnectionManagerEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getInterfaceConnectionManager_Externalsocket() {
		return (EReference) interfaceConnectionManagerEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getInterfaceConnectionManager_Dbquery() {
		return (EReference) interfaceConnectionManagerEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getInterfaceConnectionManager_Securitycheck() {
		return (EReference) interfaceConnectionManagerEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getInterfaceClient() {
		return interfaceClientEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getInterfaceClient_Attachementclientrpc() {
		return (EReference) interfaceClientEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getInterfaceClient_Portfourniclient() {
		return (EReference) interfaceClientEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getInterfaceClient_Portrequisclient() {
		return (EReference) interfaceClientEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getInterfaceClient_Servicefourniclient() {
		return (EReference) interfaceClientEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getExternalSocket() {
		return externalSocketEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getSystemeClientServeur() {
		return systemeClientServeurEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getSystemeClientServeur_Client() {
		return (EReference) systemeClientServeurEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getSystemeClientServeur_Serveur() {
		return (EReference) systemeClientServeurEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getSystemeClientServeur_Connecteurrpc() {
		return (EReference) systemeClientServeurEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getSystemeClientServeur_Attachementrpcserveur() {
		return (EReference) systemeClientServeurEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getConfigurationServeur() {
		return configurationServeurEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getConfigurationServeur_Interfaceconfigurationserveur() {
		return (EReference) configurationServeurEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getConfigurationServeur_Securitymanager() {
		return (EReference) configurationServeurEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getConfigurationServeur_Connecteurcmdb() {
		return (EReference) configurationServeurEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getConfigurationServeur_Connectionmanager() {
		return (EReference) configurationServeurEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getConfigurationServeur_Attachementcmdb() {
		return (EReference) configurationServeurEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getConfigurationServeur_Attachementsmdb() {
		return (EReference) configurationServeurEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getConfigurationServeur_Securitymanagement() {
		return (EReference) configurationServeurEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getConfigurationServeur_Attachementcmsm() {
		return (EReference) configurationServeurEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getConfigurationServeur_Connecteurdbsm() {
		return (EReference) configurationServeurEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getConfigurationServeur_Attachementsmcm() {
		return (EReference) configurationServeurEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getConfigurationServeur_Database() {
		return (EReference) configurationServeurEClass.getEStructuralFeatures().get(10);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getConfigurationServeur_Attachementdbcm() {
		return (EReference) configurationServeurEClass.getEStructuralFeatures().get(11);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getConfigurationServeur_Attachementdbsm() {
		return (EReference) configurationServeurEClass.getEStructuralFeatures().get(12);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getConfigurationServeur_Connecteurcmsm() {
		return (EReference) configurationServeurEClass.getEStructuralFeatures().get(13);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getQueryInterogation() {
		return queryInterogationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getInterfaceDatabase() {
		return interfaceDatabaseEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getInterfaceDatabase_Queryinterogation() {
		return (EReference) interfaceDatabaseEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getInterfaceDatabase_Securitymanagement() {
		return (EReference) interfaceDatabaseEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getDatabase() {
		return databaseEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getDatabase_Interfacedatabase() {
		return (EReference) databaseEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getConnecteurCmSm() {
		return connecteurCmSmEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getConnecteurCmSm_Interfaceconnecteurcmsm() {
		return (EReference) connecteurCmSmEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getInterfaceConnecteurRPC() {
		return interfaceConnecteurRPCEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getAttachementCmSm() {
		return attachementCmSmEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getAttachementCmSm_Rolesm() {
		return (EReference) attachementCmSmEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getAttachementCmSm_Securitycheck() {
		return (EReference) attachementCmSmEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getAttachementCmDb() {
		return attachementCmDbEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getAttachementCmDb_Roledb() {
		return (EReference) attachementCmDbEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getAttachementCmDb_Dbquery() {
		return (EReference) attachementCmDbEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getInterfaceConnecteurCmDb() {
		return interfaceConnecteurCmDbEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getInterfaceConnecteurCmDb_Roledb() {
		return (EReference) interfaceConnecteurCmDbEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getInterfaceConnecteurCmDb_Rolecm() {
		return (EReference) interfaceConnecteurCmDbEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getAttachementSmCm() {
		return attachementSmCmEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getAttachementSmCm_Securityauthentification() {
		return (EReference) attachementSmCmEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getAttachementSmCm_Rolecm() {
		return (EReference) attachementSmCmEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getClient() {
		return clientEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getClient_Interfaceclient() {
		return (EReference) clientEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getConnecteurCmDb() {
		return connecteurCmDbEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getConnecteurCmDb_Interfaceconnecteurcmdb() {
		return (EReference) connecteurCmDbEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getRoleSm() {
		return roleSmEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getSecurityCheck() {
		return securityCheckEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getConnecteurRPC() {
		return connecteurRPCEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getConnecteurRPC_Interfaceconnecteurrpc() {
		return (EReference) connecteurRPCEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getAttachementDbCm() {
		return attachementDbCmEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getAttachementDbCm_Queryinterogation() {
		return (EReference) attachementDbCmEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getAttachementDbCm_Rolecm() {
		return (EReference) attachementDbCmEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getInterfaceConfigurationServeur() {
		return interfaceConfigurationServeurEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getInterfaceConfigurationServeur_Portfourniconfigurationserveur() {
		return (EReference) interfaceConfigurationServeurEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getConnectionManager() {
		return connectionManagerEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getConnectionManager_Interfaceconnectionmanager() {
		return (EReference) connectionManagerEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getServeur() {
		return serveurEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getServeur_Configurationserveur() {
		return (EReference) serveurEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getConnecteurDbSm() {
		return connecteurDbSmEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getConnecteurDbSm_Interfaceconnecteurdbsm() {
		return (EReference) connecteurDbSmEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ModelM1Factory getModelM1Factory() {
		return (ModelM1Factory) getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated)
			return;
		isCreated = true;

		// Create classes and their features
		securityAuthentificationEClass = createEClass(SECURITY_AUTHENTIFICATION);

		interfaceConnecteurCmSmEClass = createEClass(INTERFACE_CONNECTEUR_CM_SM);
		createEReference(interfaceConnecteurCmSmEClass, INTERFACE_CONNECTEUR_CM_SM__ROLECM);
		createEReference(interfaceConnecteurCmSmEClass, INTERFACE_CONNECTEUR_CM_SM__ROLESM);

		dbQueryEClass = createEClass(DB_QUERY);

		interfaceConnecteurDbSmEClass = createEClass(INTERFACE_CONNECTEUR_DB_SM);
		createEReference(interfaceConnecteurDbSmEClass, INTERFACE_CONNECTEUR_DB_SM__ROLESM);
		createEReference(interfaceConnecteurDbSmEClass, INTERFACE_CONNECTEUR_DB_SM__ROLEDB);

		attachementSmDbEClass = createEClass(ATTACHEMENT_SM_DB);
		createEReference(attachementSmDbEClass, ATTACHEMENT_SM_DB__CHECKQUERY);
		createEReference(attachementSmDbEClass, ATTACHEMENT_SM_DB__ROLEDB);

		portFourniConfigurationServeurEClass = createEClass(PORT_FOURNI_CONFIGURATION_SERVEUR);

		serviceFourniClientEClass = createEClass(SERVICE_FOURNI_CLIENT);

		interfaceSecurityManagerEClass = createEClass(INTERFACE_SECURITY_MANAGER);
		createEReference(interfaceSecurityManagerEClass, INTERFACE_SECURITY_MANAGER__CHECKQUERY);
		createEReference(interfaceSecurityManagerEClass, INTERFACE_SECURITY_MANAGER__SECURITYAUTHENTIFICATION);

		bindingExternalSocketEClass = createEClass(BINDING_EXTERNAL_SOCKET);
		createEReference(bindingExternalSocketEClass, BINDING_EXTERNAL_SOCKET__EXTERNALSOCKET);
		createEReference(bindingExternalSocketEClass, BINDING_EXTERNAL_SOCKET__PORTFOURNICONFIGURATIONSERVEUR);

		roleDbEClass = createEClass(ROLE_DB);

		checkQueryEClass = createEClass(CHECK_QUERY);

		attachementRPCServeurEClass = createEClass(ATTACHEMENT_RPC_SERVEUR);
		createEReference(attachementRPCServeurEClass, ATTACHEMENT_RPC_SERVEUR__INTERFACECONNECTEURRPC);
		createEReference(attachementRPCServeurEClass, ATTACHEMENT_RPC_SERVEUR__INTERFACECONFIGURATIONSERVEUR);

		attachementClientRPCEClass = createEClass(ATTACHEMENT_CLIENT_RPC);
		createEReference(attachementClientRPCEClass, ATTACHEMENT_CLIENT_RPC__INTERFACECONNECTEURRPC);

		securityManagementEClass = createEClass(SECURITY_MANAGEMENT);

		portFourniClientEClass = createEClass(PORT_FOURNI_CLIENT);

		portRequisClientEClass = createEClass(PORT_REQUIS_CLIENT);

		attachementDbSmEClass = createEClass(ATTACHEMENT_DB_SM);
		createEReference(attachementDbSmEClass, ATTACHEMENT_DB_SM__ROLESM);
		createEReference(attachementDbSmEClass, ATTACHEMENT_DB_SM__SECURITYMANAGEMENT);

		securityManagerEClass = createEClass(SECURITY_MANAGER);

		roleCmEClass = createEClass(ROLE_CM);

		interfaceConnectionManagerEClass = createEClass(INTERFACE_CONNECTION_MANAGER);
		createEReference(interfaceConnectionManagerEClass, INTERFACE_CONNECTION_MANAGER__EXTERNALSOCKET);
		createEReference(interfaceConnectionManagerEClass, INTERFACE_CONNECTION_MANAGER__DBQUERY);
		createEReference(interfaceConnectionManagerEClass, INTERFACE_CONNECTION_MANAGER__SECURITYCHECK);

		interfaceClientEClass = createEClass(INTERFACE_CLIENT);
		createEReference(interfaceClientEClass, INTERFACE_CLIENT__ATTACHEMENTCLIENTRPC);
		createEReference(interfaceClientEClass, INTERFACE_CLIENT__PORTFOURNICLIENT);
		createEReference(interfaceClientEClass, INTERFACE_CLIENT__PORTREQUISCLIENT);
		createEReference(interfaceClientEClass, INTERFACE_CLIENT__SERVICEFOURNICLIENT);

		externalSocketEClass = createEClass(EXTERNAL_SOCKET);

		systemeClientServeurEClass = createEClass(SYSTEME_CLIENT_SERVEUR);
		createEReference(systemeClientServeurEClass, SYSTEME_CLIENT_SERVEUR__CLIENT);
		createEReference(systemeClientServeurEClass, SYSTEME_CLIENT_SERVEUR__SERVEUR);
		createEReference(systemeClientServeurEClass, SYSTEME_CLIENT_SERVEUR__CONNECTEURRPC);
		createEReference(systemeClientServeurEClass, SYSTEME_CLIENT_SERVEUR__ATTACHEMENTRPCSERVEUR);

		configurationServeurEClass = createEClass(CONFIGURATION_SERVEUR);
		createEReference(configurationServeurEClass, CONFIGURATION_SERVEUR__INTERFACECONFIGURATIONSERVEUR);
		createEReference(configurationServeurEClass, CONFIGURATION_SERVEUR__SECURITYMANAGER);
		createEReference(configurationServeurEClass, CONFIGURATION_SERVEUR__CONNECTEURCMDB);
		createEReference(configurationServeurEClass, CONFIGURATION_SERVEUR__CONNECTIONMANAGER);
		createEReference(configurationServeurEClass, CONFIGURATION_SERVEUR__ATTACHEMENTCMDB);
		createEReference(configurationServeurEClass, CONFIGURATION_SERVEUR__ATTACHEMENTSMDB);
		createEReference(configurationServeurEClass, CONFIGURATION_SERVEUR__SECURITYMANAGEMENT);
		createEReference(configurationServeurEClass, CONFIGURATION_SERVEUR__ATTACHEMENTCMSM);
		createEReference(configurationServeurEClass, CONFIGURATION_SERVEUR__CONNECTEURDBSM);
		createEReference(configurationServeurEClass, CONFIGURATION_SERVEUR__ATTACHEMENTSMCM);
		createEReference(configurationServeurEClass, CONFIGURATION_SERVEUR__DATABASE);
		createEReference(configurationServeurEClass, CONFIGURATION_SERVEUR__ATTACHEMENTDBCM);
		createEReference(configurationServeurEClass, CONFIGURATION_SERVEUR__ATTACHEMENTDBSM);
		createEReference(configurationServeurEClass, CONFIGURATION_SERVEUR__CONNECTEURCMSM);

		queryInterogationEClass = createEClass(QUERY_INTEROGATION);

		interfaceDatabaseEClass = createEClass(INTERFACE_DATABASE);
		createEReference(interfaceDatabaseEClass, INTERFACE_DATABASE__QUERYINTEROGATION);
		createEReference(interfaceDatabaseEClass, INTERFACE_DATABASE__SECURITYMANAGEMENT);

		databaseEClass = createEClass(DATABASE);
		createEReference(databaseEClass, DATABASE__INTERFACEDATABASE);

		connecteurCmSmEClass = createEClass(CONNECTEUR_CM_SM);
		createEReference(connecteurCmSmEClass, CONNECTEUR_CM_SM__INTERFACECONNECTEURCMSM);

		interfaceConnecteurRPCEClass = createEClass(INTERFACE_CONNECTEUR_RPC);

		attachementCmSmEClass = createEClass(ATTACHEMENT_CM_SM);
		createEReference(attachementCmSmEClass, ATTACHEMENT_CM_SM__ROLESM);
		createEReference(attachementCmSmEClass, ATTACHEMENT_CM_SM__SECURITYCHECK);

		attachementCmDbEClass = createEClass(ATTACHEMENT_CM_DB);
		createEReference(attachementCmDbEClass, ATTACHEMENT_CM_DB__ROLEDB);
		createEReference(attachementCmDbEClass, ATTACHEMENT_CM_DB__DBQUERY);

		interfaceConnecteurCmDbEClass = createEClass(INTERFACE_CONNECTEUR_CM_DB);
		createEReference(interfaceConnecteurCmDbEClass, INTERFACE_CONNECTEUR_CM_DB__ROLEDB);
		createEReference(interfaceConnecteurCmDbEClass, INTERFACE_CONNECTEUR_CM_DB__ROLECM);

		attachementSmCmEClass = createEClass(ATTACHEMENT_SM_CM);
		createEReference(attachementSmCmEClass, ATTACHEMENT_SM_CM__SECURITYAUTHENTIFICATION);
		createEReference(attachementSmCmEClass, ATTACHEMENT_SM_CM__ROLECM);

		clientEClass = createEClass(CLIENT);
		createEReference(clientEClass, CLIENT__INTERFACECLIENT);

		connecteurCmDbEClass = createEClass(CONNECTEUR_CM_DB);
		createEReference(connecteurCmDbEClass, CONNECTEUR_CM_DB__INTERFACECONNECTEURCMDB);

		roleSmEClass = createEClass(ROLE_SM);

		securityCheckEClass = createEClass(SECURITY_CHECK);

		connecteurRPCEClass = createEClass(CONNECTEUR_RPC);
		createEReference(connecteurRPCEClass, CONNECTEUR_RPC__INTERFACECONNECTEURRPC);

		attachementDbCmEClass = createEClass(ATTACHEMENT_DB_CM);
		createEReference(attachementDbCmEClass, ATTACHEMENT_DB_CM__QUERYINTEROGATION);
		createEReference(attachementDbCmEClass, ATTACHEMENT_DB_CM__ROLECM);

		interfaceConfigurationServeurEClass = createEClass(INTERFACE_CONFIGURATION_SERVEUR);
		createEReference(interfaceConfigurationServeurEClass,
				INTERFACE_CONFIGURATION_SERVEUR__PORTFOURNICONFIGURATIONSERVEUR);

		connectionManagerEClass = createEClass(CONNECTION_MANAGER);
		createEReference(connectionManagerEClass, CONNECTION_MANAGER__INTERFACECONNECTIONMANAGER);

		serveurEClass = createEClass(SERVEUR);
		createEReference(serveurEClass, SERVEUR__CONFIGURATIONSERVEUR);

		connecteurDbSmEClass = createEClass(CONNECTEUR_DB_SM);
		createEReference(connecteurDbSmEClass, CONNECTEUR_DB_SM__INTERFACECONNECTEURDBSM);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized)
			return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes

		// Initialize classes, features, and operations; add parameters
		initEClass(securityAuthentificationEClass, SecurityAuthentification.class, "SecurityAuthentification",
				!IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(interfaceConnecteurCmSmEClass, InterfaceConnecteurCmSm.class, "InterfaceConnecteurCmSm",
				!IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getInterfaceConnecteurCmSm_Rolecm(), this.getRoleCm(), null, "rolecm", null, 0, 1,
				InterfaceConnecteurCmSm.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getInterfaceConnecteurCmSm_Rolesm(), this.getRoleSm(), null, "rolesm", null, 0, 1,
				InterfaceConnecteurCmSm.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(dbQueryEClass, DbQuery.class, "DbQuery", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(interfaceConnecteurDbSmEClass, InterfaceConnecteurDbSm.class, "InterfaceConnecteurDbSm",
				!IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getInterfaceConnecteurDbSm_Rolesm(), this.getRoleSm(), null, "rolesm", null, 0, 1,
				InterfaceConnecteurDbSm.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getInterfaceConnecteurDbSm_Roledb(), this.getRoleDb(), null, "roledb", null, 0, 1,
				InterfaceConnecteurDbSm.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(attachementSmDbEClass, AttachementSmDb.class, "AttachementSmDb", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getAttachementSmDb_Checkquery(), this.getCheckQuery(), null, "checkquery", null, 0, 1,
				AttachementSmDb.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getAttachementSmDb_Roledb(), this.getRoleDb(), null, "roledb", null, 0, 1, AttachementSmDb.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(portFourniConfigurationServeurEClass, PortFourniConfigurationServeur.class,
				"PortFourniConfigurationServeur", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(serviceFourniClientEClass, ServiceFourniClient.class, "ServiceFourniClient", !IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(interfaceSecurityManagerEClass, InterfaceSecurityManager.class, "InterfaceSecurityManager",
				!IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getInterfaceSecurityManager_Checkquery(), this.getCheckQuery(), null, "checkquery", null, 0, 1,
				InterfaceSecurityManager.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getInterfaceSecurityManager_Securityauthentification(), this.getSecurityAuthentification(), null,
				"securityauthentification", null, 0, 1, InterfaceSecurityManager.class, !IS_TRANSIENT, !IS_VOLATILE,
				IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(bindingExternalSocketEClass, BindingExternalSocket.class, "BindingExternalSocket", !IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getBindingExternalSocket_Externalsocket(), this.getExternalSocket(), null, "externalsocket",
				null, 0, 1, BindingExternalSocket.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getBindingExternalSocket_Portfourniconfigurationserveur(),
				this.getPortFourniConfigurationServeur(), null, "portfourniconfigurationserveur", null, 0, 1,
				BindingExternalSocket.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(roleDbEClass, RoleDb.class, "RoleDb", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(checkQueryEClass, CheckQuery.class, "CheckQuery", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(attachementRPCServeurEClass, AttachementRPCServeur.class, "AttachementRPCServeur", !IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getAttachementRPCServeur_Interfaceconnecteurrpc(), this.getInterfaceConnecteurRPC(), null,
				"interfaceconnecteurrpc", null, 0, 1, AttachementRPCServeur.class, !IS_TRANSIENT, !IS_VOLATILE,
				IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getAttachementRPCServeur_Interfaceconfigurationserveur(),
				this.getInterfaceConfigurationServeur(), null, "interfaceconfigurationserveur", null, 0, 1,
				AttachementRPCServeur.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(attachementClientRPCEClass, AttachementClientRPC.class, "AttachementClientRPC", !IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getAttachementClientRPC_Interfaceconnecteurrpc(), this.getInterfaceConnecteurRPC(), null,
				"interfaceconnecteurrpc", null, 0, 1, AttachementClientRPC.class, !IS_TRANSIENT, !IS_VOLATILE,
				IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(securityManagementEClass, SecurityManagement.class, "SecurityManagement", !IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(portFourniClientEClass, PortFourniClient.class, "PortFourniClient", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(portRequisClientEClass, PortRequisClient.class, "PortRequisClient", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(attachementDbSmEClass, AttachementDbSm.class, "AttachementDbSm", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getAttachementDbSm_Rolesm(), this.getRoleSm(), null, "rolesm", null, 0, 1, AttachementDbSm.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getAttachementDbSm_Securitymanagement(), this.getSecurityManagement(), null,
				"securitymanagement", null, 0, 1, AttachementDbSm.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(securityManagerEClass, modelM1.SecurityManager.class, "SecurityManager", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(roleCmEClass, RoleCm.class, "RoleCm", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(interfaceConnectionManagerEClass, InterfaceConnectionManager.class, "InterfaceConnectionManager",
				!IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getInterfaceConnectionManager_Externalsocket(), this.getExternalSocket(), null, "externalsocket",
				null, 0, 1, InterfaceConnectionManager.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getInterfaceConnectionManager_Dbquery(), this.getDbQuery(), null, "dbquery", null, 0, 1,
				InterfaceConnectionManager.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getInterfaceConnectionManager_Securitycheck(), this.getSecurityCheck(), null, "securitycheck",
				null, 0, 1, InterfaceConnectionManager.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(interfaceClientEClass, InterfaceClient.class, "InterfaceClient", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getInterfaceClient_Attachementclientrpc(), this.getAttachementClientRPC(), null,
				"attachementclientrpc", null, 0, 1, InterfaceClient.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getInterfaceClient_Portfourniclient(), this.getPortFourniClient(), null, "portfourniclient",
				null, 0, 1, InterfaceClient.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getInterfaceClient_Portrequisclient(), this.getPortRequisClient(), null, "portrequisclient",
				null, 0, 1, InterfaceClient.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getInterfaceClient_Servicefourniclient(), this.getServiceFourniClient(), null,
				"servicefourniclient", null, 0, 1, InterfaceClient.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(externalSocketEClass, ExternalSocket.class, "ExternalSocket", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(systemeClientServeurEClass, SystemeClientServeur.class, "SystemeClientServeur", !IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getSystemeClientServeur_Client(), this.getClient(), null, "client", null, 0, 1,
				SystemeClientServeur.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSystemeClientServeur_Serveur(), this.getServeur(), null, "serveur", null, 0, 1,
				SystemeClientServeur.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSystemeClientServeur_Connecteurrpc(), this.getConnecteurRPC(), null, "connecteurrpc", null, 0,
				1, SystemeClientServeur.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSystemeClientServeur_Attachementrpcserveur(), this.getAttachementRPCServeur(), null,
				"attachementrpcserveur", null, 0, 1, SystemeClientServeur.class, !IS_TRANSIENT, !IS_VOLATILE,
				IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(configurationServeurEClass, ConfigurationServeur.class, "ConfigurationServeur", !IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getConfigurationServeur_Interfaceconfigurationserveur(), this.getInterfaceConfigurationServeur(),
				null, "interfaceconfigurationserveur", null, 0, 1, ConfigurationServeur.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);
		initEReference(getConfigurationServeur_Securitymanager(), this.getSecurityManager(), null, "securitymanager",
				null, 0, 1, ConfigurationServeur.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getConfigurationServeur_Connecteurcmdb(), this.getConnecteurCmDb(), null, "connecteurcmdb", null,
				0, 1, ConfigurationServeur.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getConfigurationServeur_Connectionmanager(), this.getConnectionManager(), null,
				"connectionmanager", null, 0, 1, ConfigurationServeur.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getConfigurationServeur_Attachementcmdb(), this.getAttachementCmDb(), null, "attachementcmdb",
				null, 0, 1, ConfigurationServeur.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getConfigurationServeur_Attachementsmdb(), this.getAttachementSmDb(), null, "attachementsmdb",
				null, 0, 1, ConfigurationServeur.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getConfigurationServeur_Securitymanagement(), this.getSecurityManagement(), null,
				"securitymanagement", null, 0, 1, ConfigurationServeur.class, !IS_TRANSIENT, !IS_VOLATILE,
				IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getConfigurationServeur_Attachementcmsm(), this.getAttachementCmSm(), null, "attachementcmsm",
				null, 0, 1, ConfigurationServeur.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getConfigurationServeur_Connecteurdbsm(), this.getConnecteurDbSm(), null, "connecteurdbsm", null,
				0, 1, ConfigurationServeur.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getConfigurationServeur_Attachementsmcm(), this.getAttachementSmCm(), null, "attachementsmcm",
				null, 0, 1, ConfigurationServeur.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getConfigurationServeur_Database(), this.getDatabase(), null, "database", null, 0, 1,
				ConfigurationServeur.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getConfigurationServeur_Attachementdbcm(), this.getAttachementDbCm(), null, "attachementdbcm",
				null, 0, 1, ConfigurationServeur.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getConfigurationServeur_Attachementdbsm(), this.getAttachementDbSm(), null, "attachementdbsm",
				null, 0, 1, ConfigurationServeur.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getConfigurationServeur_Connecteurcmsm(), this.getConnecteurCmSm(), null, "connecteurcmsm", null,
				0, 1, ConfigurationServeur.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(queryInterogationEClass, QueryInterogation.class, "QueryInterogation", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(interfaceDatabaseEClass, InterfaceDatabase.class, "InterfaceDatabase", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getInterfaceDatabase_Queryinterogation(), this.getQueryInterogation(), null, "queryinterogation",
				null, 0, 1, InterfaceDatabase.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getInterfaceDatabase_Securitymanagement(), this.getSecurityManagement(), null,
				"securitymanagement", null, 0, 1, InterfaceDatabase.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(databaseEClass, Database.class, "Database", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getDatabase_Interfacedatabase(), this.getInterfaceDatabase(), null, "interfacedatabase", null, 0,
				1, Database.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(connecteurCmSmEClass, ConnecteurCmSm.class, "ConnecteurCmSm", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getConnecteurCmSm_Interfaceconnecteurcmsm(), this.getInterfaceConnecteurCmSm(), null,
				"interfaceconnecteurcmsm", null, 0, 1, ConnecteurCmSm.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(interfaceConnecteurRPCEClass, InterfaceConnecteurRPC.class, "InterfaceConnecteurRPC", !IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(attachementCmSmEClass, AttachementCmSm.class, "AttachementCmSm", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getAttachementCmSm_Rolesm(), this.getRoleSm(), null, "rolesm", null, 0, 1, AttachementCmSm.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getAttachementCmSm_Securitycheck(), this.getSecurityCheck(), null, "securitycheck", null, 0, 1,
				AttachementCmSm.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(attachementCmDbEClass, AttachementCmDb.class, "AttachementCmDb", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getAttachementCmDb_Roledb(), this.getRoleDb(), null, "roledb", null, 0, 1, AttachementCmDb.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getAttachementCmDb_Dbquery(), this.getDbQuery(), null, "dbquery", null, 0, 1,
				AttachementCmDb.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(interfaceConnecteurCmDbEClass, InterfaceConnecteurCmDb.class, "InterfaceConnecteurCmDb",
				!IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getInterfaceConnecteurCmDb_Roledb(), this.getRoleDb(), null, "roledb", null, 0, 1,
				InterfaceConnecteurCmDb.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getInterfaceConnecteurCmDb_Rolecm(), this.getRoleCm(), null, "rolecm", null, 0, 1,
				InterfaceConnecteurCmDb.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(attachementSmCmEClass, AttachementSmCm.class, "AttachementSmCm", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getAttachementSmCm_Securityauthentification(), this.getSecurityAuthentification(), null,
				"securityauthentification", null, 0, 1, AttachementSmCm.class, !IS_TRANSIENT, !IS_VOLATILE,
				IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getAttachementSmCm_Rolecm(), this.getRoleCm(), null, "rolecm", null, 0, 1, AttachementSmCm.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(clientEClass, Client.class, "Client", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getClient_Interfaceclient(), this.getInterfaceClient(), null, "interfaceclient", null, 0, 1,
				Client.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(connecteurCmDbEClass, ConnecteurCmDb.class, "ConnecteurCmDb", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getConnecteurCmDb_Interfaceconnecteurcmdb(), this.getInterfaceConnecteurCmDb(), null,
				"interfaceconnecteurcmdb", null, 0, 1, ConnecteurCmDb.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(roleSmEClass, RoleSm.class, "RoleSm", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(securityCheckEClass, SecurityCheck.class, "SecurityCheck", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(connecteurRPCEClass, ConnecteurRPC.class, "ConnecteurRPC", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getConnecteurRPC_Interfaceconnecteurrpc(), this.getInterfaceConnecteurRPC(), null,
				"interfaceconnecteurrpc", null, 0, 1, ConnecteurRPC.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(attachementDbCmEClass, AttachementDbCm.class, "AttachementDbCm", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getAttachementDbCm_Queryinterogation(), this.getQueryInterogation(), null, "queryinterogation",
				null, 0, 1, AttachementDbCm.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getAttachementDbCm_Rolecm(), this.getRoleCm(), null, "rolecm", null, 0, 1, AttachementDbCm.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(interfaceConfigurationServeurEClass, InterfaceConfigurationServeur.class,
				"InterfaceConfigurationServeur", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getInterfaceConfigurationServeur_Portfourniconfigurationserveur(),
				this.getPortFourniConfigurationServeur(), null, "portfourniconfigurationserveur", null, 0, 1,
				InterfaceConfigurationServeur.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(connectionManagerEClass, ConnectionManager.class, "ConnectionManager", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getConnectionManager_Interfaceconnectionmanager(), this.getInterfaceConnectionManager(), null,
				"interfaceconnectionmanager", null, 0, 1, ConnectionManager.class, !IS_TRANSIENT, !IS_VOLATILE,
				IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(serveurEClass, Serveur.class, "Serveur", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getServeur_Configurationserveur(), this.getConfigurationServeur(), null, "configurationserveur",
				null, 0, 1, Serveur.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(connecteurDbSmEClass, ConnecteurDbSm.class, "ConnecteurDbSm", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getConnecteurDbSm_Interfaceconnecteurdbsm(), this.getInterfaceConnecteurDbSm(), null,
				"interfaceconnecteurdbsm", null, 0, 1, ConnecteurDbSm.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		// Create resource
		createResource(eNS_URI);
	}

} //ModelM1PackageImpl

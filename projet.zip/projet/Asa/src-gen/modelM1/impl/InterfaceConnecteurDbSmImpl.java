/**
 */
package modelM1.impl;

import modelM1.InterfaceConnecteurDbSm;
import modelM1.ModelM1Package;
import modelM1.RoleDb;
import modelM1.RoleSm;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Interface Connecteur Db Sm</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link modelM1.impl.InterfaceConnecteurDbSmImpl#getRolesm <em>Rolesm</em>}</li>
 *   <li>{@link modelM1.impl.InterfaceConnecteurDbSmImpl#getRoledb <em>Roledb</em>}</li>
 * </ul>
 *
 * @generated
 */
public class InterfaceConnecteurDbSmImpl extends MinimalEObjectImpl.Container implements InterfaceConnecteurDbSm {
	/**
	 * The cached value of the '{@link #getRolesm() <em>Rolesm</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRolesm()
	 * @generated
	 * @ordered
	 */
	protected RoleSm rolesm;

	/**
	 * The cached value of the '{@link #getRoledb() <em>Roledb</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRoledb()
	 * @generated
	 * @ordered
	 */
	protected RoleDb roledb;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected InterfaceConnecteurDbSmImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModelM1Package.Literals.INTERFACE_CONNECTEUR_DB_SM;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public RoleSm getRolesm() {
		if (rolesm != null && rolesm.eIsProxy()) {
			InternalEObject oldRolesm = (InternalEObject) rolesm;
			rolesm = (RoleSm) eResolveProxy(oldRolesm);
			if (rolesm != oldRolesm) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ModelM1Package.INTERFACE_CONNECTEUR_DB_SM__ROLESM, oldRolesm, rolesm));
			}
		}
		return rolesm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RoleSm basicGetRolesm() {
		return rolesm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setRolesm(RoleSm newRolesm) {
		RoleSm oldRolesm = rolesm;
		rolesm = newRolesm;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModelM1Package.INTERFACE_CONNECTEUR_DB_SM__ROLESM,
					oldRolesm, rolesm));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public RoleDb getRoledb() {
		if (roledb != null && roledb.eIsProxy()) {
			InternalEObject oldRoledb = (InternalEObject) roledb;
			roledb = (RoleDb) eResolveProxy(oldRoledb);
			if (roledb != oldRoledb) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ModelM1Package.INTERFACE_CONNECTEUR_DB_SM__ROLEDB, oldRoledb, roledb));
			}
		}
		return roledb;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RoleDb basicGetRoledb() {
		return roledb;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setRoledb(RoleDb newRoledb) {
		RoleDb oldRoledb = roledb;
		roledb = newRoledb;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModelM1Package.INTERFACE_CONNECTEUR_DB_SM__ROLEDB,
					oldRoledb, roledb));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ModelM1Package.INTERFACE_CONNECTEUR_DB_SM__ROLESM:
			if (resolve)
				return getRolesm();
			return basicGetRolesm();
		case ModelM1Package.INTERFACE_CONNECTEUR_DB_SM__ROLEDB:
			if (resolve)
				return getRoledb();
			return basicGetRoledb();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ModelM1Package.INTERFACE_CONNECTEUR_DB_SM__ROLESM:
			setRolesm((RoleSm) newValue);
			return;
		case ModelM1Package.INTERFACE_CONNECTEUR_DB_SM__ROLEDB:
			setRoledb((RoleDb) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ModelM1Package.INTERFACE_CONNECTEUR_DB_SM__ROLESM:
			setRolesm((RoleSm) null);
			return;
		case ModelM1Package.INTERFACE_CONNECTEUR_DB_SM__ROLEDB:
			setRoledb((RoleDb) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ModelM1Package.INTERFACE_CONNECTEUR_DB_SM__ROLESM:
			return rolesm != null;
		case ModelM1Package.INTERFACE_CONNECTEUR_DB_SM__ROLEDB:
			return roledb != null;
		}
		return super.eIsSet(featureID);
	}

} //InterfaceConnecteurDbSmImpl

/**
 */
package modelM1.impl;

import modelM1.InterfaceConfigurationServeur;
import modelM1.ModelM1Package;
import modelM1.PortFourniConfigurationServeur;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Interface Configuration Serveur</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link modelM1.impl.InterfaceConfigurationServeurImpl#getPortfourniconfigurationserveur <em>Portfourniconfigurationserveur</em>}</li>
 * </ul>
 *
 * @generated
 */
public class InterfaceConfigurationServeurImpl extends MinimalEObjectImpl.Container
		implements InterfaceConfigurationServeur {
	/**
	 * The cached value of the '{@link #getPortfourniconfigurationserveur() <em>Portfourniconfigurationserveur</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPortfourniconfigurationserveur()
	 * @generated
	 * @ordered
	 */
	protected PortFourniConfigurationServeur portfourniconfigurationserveur;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public InterfaceConfigurationServeurImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModelM1Package.Literals.INTERFACE_CONFIGURATION_SERVEUR;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public PortFourniConfigurationServeur getPortfourniconfigurationserveur() {
		if (portfourniconfigurationserveur != null && portfourniconfigurationserveur.eIsProxy()) {
			InternalEObject oldPortfourniconfigurationserveur = (InternalEObject) portfourniconfigurationserveur;
			portfourniconfigurationserveur = (PortFourniConfigurationServeur) eResolveProxy(
					oldPortfourniconfigurationserveur);
			if (portfourniconfigurationserveur != oldPortfourniconfigurationserveur) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ModelM1Package.INTERFACE_CONFIGURATION_SERVEUR__PORTFOURNICONFIGURATIONSERVEUR,
							oldPortfourniconfigurationserveur, portfourniconfigurationserveur));
			}
		}
		return portfourniconfigurationserveur;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PortFourniConfigurationServeur basicGetPortfourniconfigurationserveur() {
		return portfourniconfigurationserveur;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setPortfourniconfigurationserveur(PortFourniConfigurationServeur newPortfourniconfigurationserveur) {
		PortFourniConfigurationServeur oldPortfourniconfigurationserveur = portfourniconfigurationserveur;
		portfourniconfigurationserveur = newPortfourniconfigurationserveur;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					ModelM1Package.INTERFACE_CONFIGURATION_SERVEUR__PORTFOURNICONFIGURATIONSERVEUR,
					oldPortfourniconfigurationserveur, portfourniconfigurationserveur));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ModelM1Package.INTERFACE_CONFIGURATION_SERVEUR__PORTFOURNICONFIGURATIONSERVEUR:
			if (resolve)
				return getPortfourniconfigurationserveur();
			return basicGetPortfourniconfigurationserveur();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ModelM1Package.INTERFACE_CONFIGURATION_SERVEUR__PORTFOURNICONFIGURATIONSERVEUR:
			setPortfourniconfigurationserveur((PortFourniConfigurationServeur) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ModelM1Package.INTERFACE_CONFIGURATION_SERVEUR__PORTFOURNICONFIGURATIONSERVEUR:
			setPortfourniconfigurationserveur((PortFourniConfigurationServeur) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ModelM1Package.INTERFACE_CONFIGURATION_SERVEUR__PORTFOURNICONFIGURATIONSERVEUR:
			return portfourniconfigurationserveur != null;
		}
		return super.eIsSet(featureID);
	}

} //InterfaceConfigurationServeurImpl

/**
 */
package modelM1.impl;

import modelM1.ModelM1Package;
import modelM1.SecurityCheck;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Security Check</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SecurityCheckImpl extends MinimalEObjectImpl.Container implements SecurityCheck {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SecurityCheckImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModelM1Package.Literals.SECURITY_CHECK;
	}

} //SecurityCheckImpl

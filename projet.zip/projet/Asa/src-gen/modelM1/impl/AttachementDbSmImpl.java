/**
 */
package modelM1.impl;

import modelM1.AttachementDbSm;
import modelM1.ModelM1Package;
import modelM1.RoleSm;
import modelM1.SecurityManagement;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Attachement Db Sm</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link modelM1.impl.AttachementDbSmImpl#getRolesm <em>Rolesm</em>}</li>
 *   <li>{@link modelM1.impl.AttachementDbSmImpl#getSecuritymanagement <em>Securitymanagement</em>}</li>
 * </ul>
 *
 * @generated
 */
public class AttachementDbSmImpl extends MinimalEObjectImpl.Container implements AttachementDbSm {
	/**
	 * The cached value of the '{@link #getRolesm() <em>Rolesm</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRolesm()
	 * @generated
	 * @ordered
	 */
	protected RoleSm rolesm;

	/**
	 * The cached value of the '{@link #getSecuritymanagement() <em>Securitymanagement</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSecuritymanagement()
	 * @generated
	 * @ordered
	 */
	protected SecurityManagement securitymanagement;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AttachementDbSmImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModelM1Package.Literals.ATTACHEMENT_DB_SM;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public RoleSm getRolesm() {
		if (rolesm != null && rolesm.eIsProxy()) {
			InternalEObject oldRolesm = (InternalEObject) rolesm;
			rolesm = (RoleSm) eResolveProxy(oldRolesm);
			if (rolesm != oldRolesm) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, ModelM1Package.ATTACHEMENT_DB_SM__ROLESM,
							oldRolesm, rolesm));
			}
		}
		return rolesm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RoleSm basicGetRolesm() {
		return rolesm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setRolesm(RoleSm newRolesm) {
		RoleSm oldRolesm = rolesm;
		rolesm = newRolesm;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModelM1Package.ATTACHEMENT_DB_SM__ROLESM, oldRolesm,
					rolesm));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SecurityManagement getSecuritymanagement() {
		if (securitymanagement != null && securitymanagement.eIsProxy()) {
			InternalEObject oldSecuritymanagement = (InternalEObject) securitymanagement;
			securitymanagement = (SecurityManagement) eResolveProxy(oldSecuritymanagement);
			if (securitymanagement != oldSecuritymanagement) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ModelM1Package.ATTACHEMENT_DB_SM__SECURITYMANAGEMENT, oldSecuritymanagement,
							securitymanagement));
			}
		}
		return securitymanagement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SecurityManagement basicGetSecuritymanagement() {
		return securitymanagement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setSecuritymanagement(SecurityManagement newSecuritymanagement) {
		SecurityManagement oldSecuritymanagement = securitymanagement;
		securitymanagement = newSecuritymanagement;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModelM1Package.ATTACHEMENT_DB_SM__SECURITYMANAGEMENT,
					oldSecuritymanagement, securitymanagement));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ModelM1Package.ATTACHEMENT_DB_SM__ROLESM:
			if (resolve)
				return getRolesm();
			return basicGetRolesm();
		case ModelM1Package.ATTACHEMENT_DB_SM__SECURITYMANAGEMENT:
			if (resolve)
				return getSecuritymanagement();
			return basicGetSecuritymanagement();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ModelM1Package.ATTACHEMENT_DB_SM__ROLESM:
			setRolesm((RoleSm) newValue);
			return;
		case ModelM1Package.ATTACHEMENT_DB_SM__SECURITYMANAGEMENT:
			setSecuritymanagement((SecurityManagement) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ModelM1Package.ATTACHEMENT_DB_SM__ROLESM:
			setRolesm((RoleSm) null);
			return;
		case ModelM1Package.ATTACHEMENT_DB_SM__SECURITYMANAGEMENT:
			setSecuritymanagement((SecurityManagement) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ModelM1Package.ATTACHEMENT_DB_SM__ROLESM:
			return rolesm != null;
		case ModelM1Package.ATTACHEMENT_DB_SM__SECURITYMANAGEMENT:
			return securitymanagement != null;
		}
		return super.eIsSet(featureID);
	}

} //AttachementDbSmImpl

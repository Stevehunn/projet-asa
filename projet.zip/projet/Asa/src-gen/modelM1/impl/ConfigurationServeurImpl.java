/**
 */
package modelM1.impl;

import modelM1.AttachementCmDb;
import modelM1.AttachementCmSm;
import modelM1.AttachementDbCm;
import modelM1.AttachementDbSm;
import modelM1.AttachementSmCm;
import modelM1.AttachementSmDb;
import modelM1.ConfigurationServeur;
import modelM1.ConnecteurCmDb;
import modelM1.ConnecteurCmSm;
import modelM1.ConnecteurDbSm;
import modelM1.ConnectionManager;
import modelM1.Database;
import modelM1.InterfaceConfigurationServeur;
import modelM1.ModelM1Package;
import modelM1.SecurityManagement;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Configuration Serveur</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link modelM1.impl.ConfigurationServeurImpl#getInterfaceconfigurationserveur <em>Interfaceconfigurationserveur</em>}</li>
 *   <li>{@link modelM1.impl.ConfigurationServeurImpl#getSecuritymanager <em>Securitymanager</em>}</li>
 *   <li>{@link modelM1.impl.ConfigurationServeurImpl#getConnecteurcmdb <em>Connecteurcmdb</em>}</li>
 *   <li>{@link modelM1.impl.ConfigurationServeurImpl#getConnectionmanager <em>Connectionmanager</em>}</li>
 *   <li>{@link modelM1.impl.ConfigurationServeurImpl#getAttachementcmdb <em>Attachementcmdb</em>}</li>
 *   <li>{@link modelM1.impl.ConfigurationServeurImpl#getAttachementsmdb <em>Attachementsmdb</em>}</li>
 *   <li>{@link modelM1.impl.ConfigurationServeurImpl#getSecuritymanagement <em>Securitymanagement</em>}</li>
 *   <li>{@link modelM1.impl.ConfigurationServeurImpl#getAttachementcmsm <em>Attachementcmsm</em>}</li>
 *   <li>{@link modelM1.impl.ConfigurationServeurImpl#getConnecteurdbsm <em>Connecteurdbsm</em>}</li>
 *   <li>{@link modelM1.impl.ConfigurationServeurImpl#getAttachementsmcm <em>Attachementsmcm</em>}</li>
 *   <li>{@link modelM1.impl.ConfigurationServeurImpl#getDatabase <em>Database</em>}</li>
 *   <li>{@link modelM1.impl.ConfigurationServeurImpl#getAttachementdbcm <em>Attachementdbcm</em>}</li>
 *   <li>{@link modelM1.impl.ConfigurationServeurImpl#getAttachementdbsm <em>Attachementdbsm</em>}</li>
 *   <li>{@link modelM1.impl.ConfigurationServeurImpl#getConnecteurcmsm <em>Connecteurcmsm</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ConfigurationServeurImpl extends MinimalEObjectImpl.Container implements ConfigurationServeur {
	/**
	 * The cached value of the '{@link #getInterfaceconfigurationserveur() <em>Interfaceconfigurationserveur</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInterfaceconfigurationserveur()
	 * @generated
	 * @ordered
	 */
	protected InterfaceConfigurationServeur interfaceconfigurationserveur;

	/**
	 * The cached value of the '{@link #getSecuritymanager() <em>Securitymanager</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSecuritymanager()
	 * @generated
	 * @ordered
	 */
	protected modelM1.SecurityManager securitymanager;

	/**
	 * The cached value of the '{@link #getConnecteurcmdb() <em>Connecteurcmdb</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getConnecteurcmdb()
	 * @generated
	 * @ordered
	 */
	protected ConnecteurCmDb connecteurcmdb;

	/**
	 * The cached value of the '{@link #getConnectionmanager() <em>Connectionmanager</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getConnectionmanager()
	 * @generated
	 * @ordered
	 */
	protected ConnectionManager connectionmanager;

	/**
	 * The cached value of the '{@link #getAttachementcmdb() <em>Attachementcmdb</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAttachementcmdb()
	 * @generated
	 * @ordered
	 */
	protected AttachementCmDb attachementcmdb;

	/**
	 * The cached value of the '{@link #getAttachementsmdb() <em>Attachementsmdb</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAttachementsmdb()
	 * @generated
	 * @ordered
	 */
	protected AttachementSmDb attachementsmdb;

	/**
	 * The cached value of the '{@link #getSecuritymanagement() <em>Securitymanagement</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSecuritymanagement()
	 * @generated
	 * @ordered
	 */
	protected SecurityManagement securitymanagement;

	/**
	 * The cached value of the '{@link #getAttachementcmsm() <em>Attachementcmsm</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAttachementcmsm()
	 * @generated
	 * @ordered
	 */
	protected AttachementCmSm attachementcmsm;

	/**
	 * The cached value of the '{@link #getConnecteurdbsm() <em>Connecteurdbsm</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getConnecteurdbsm()
	 * @generated
	 * @ordered
	 */
	protected ConnecteurDbSm connecteurdbsm;

	/**
	 * The cached value of the '{@link #getAttachementsmcm() <em>Attachementsmcm</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAttachementsmcm()
	 * @generated
	 * @ordered
	 */
	protected AttachementSmCm attachementsmcm;

	/**
	 * The cached value of the '{@link #getDatabase() <em>Database</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDatabase()
	 * @generated
	 * @ordered
	 */
	protected Database database;

	/**
	 * The cached value of the '{@link #getAttachementdbcm() <em>Attachementdbcm</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAttachementdbcm()
	 * @generated
	 * @ordered
	 */
	protected AttachementDbCm attachementdbcm;

	/**
	 * The cached value of the '{@link #getAttachementdbsm() <em>Attachementdbsm</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAttachementdbsm()
	 * @generated
	 * @ordered
	 */
	protected AttachementDbSm attachementdbsm;

	/**
	 * The cached value of the '{@link #getConnecteurcmsm() <em>Connecteurcmsm</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getConnecteurcmsm()
	 * @generated
	 * @ordered
	 */
	protected ConnecteurCmSm connecteurcmsm;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ConfigurationServeurImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModelM1Package.Literals.CONFIGURATION_SERVEUR;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public InterfaceConfigurationServeur getInterfaceconfigurationserveur() {
		if (interfaceconfigurationserveur != null && interfaceconfigurationserveur.eIsProxy()) {
			InternalEObject oldInterfaceconfigurationserveur = (InternalEObject) interfaceconfigurationserveur;
			interfaceconfigurationserveur = (InterfaceConfigurationServeur) eResolveProxy(
					oldInterfaceconfigurationserveur);
			if (interfaceconfigurationserveur != oldInterfaceconfigurationserveur) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ModelM1Package.CONFIGURATION_SERVEUR__INTERFACECONFIGURATIONSERVEUR,
							oldInterfaceconfigurationserveur, interfaceconfigurationserveur));
			}
		}
		return interfaceconfigurationserveur;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public InterfaceConfigurationServeur basicGetInterfaceconfigurationserveur() {
		return interfaceconfigurationserveur;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setInterfaceconfigurationserveur(InterfaceConfigurationServeur newInterfaceconfigurationserveur) {
		InterfaceConfigurationServeur oldInterfaceconfigurationserveur = interfaceconfigurationserveur;
		interfaceconfigurationserveur = newInterfaceconfigurationserveur;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					ModelM1Package.CONFIGURATION_SERVEUR__INTERFACECONFIGURATIONSERVEUR,
					oldInterfaceconfigurationserveur, interfaceconfigurationserveur));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public modelM1.SecurityManager getSecuritymanager() {
		if (securitymanager != null && securitymanager.eIsProxy()) {
			InternalEObject oldSecuritymanager = (InternalEObject) securitymanager;
			securitymanager = (modelM1.SecurityManager) eResolveProxy(oldSecuritymanager);
			if (securitymanager != oldSecuritymanager) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ModelM1Package.CONFIGURATION_SERVEUR__SECURITYMANAGER, oldSecuritymanager,
							securitymanager));
			}
		}
		return securitymanager;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public modelM1.SecurityManager basicGetSecuritymanager() {
		return securitymanager;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setSecuritymanager(modelM1.SecurityManager newSecuritymanager) {
		modelM1.SecurityManager oldSecuritymanager = securitymanager;
		securitymanager = newSecuritymanager;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModelM1Package.CONFIGURATION_SERVEUR__SECURITYMANAGER,
					oldSecuritymanager, securitymanager));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ConnecteurCmDb getConnecteurcmdb() {
		if (connecteurcmdb != null && connecteurcmdb.eIsProxy()) {
			InternalEObject oldConnecteurcmdb = (InternalEObject) connecteurcmdb;
			connecteurcmdb = (ConnecteurCmDb) eResolveProxy(oldConnecteurcmdb);
			if (connecteurcmdb != oldConnecteurcmdb) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ModelM1Package.CONFIGURATION_SERVEUR__CONNECTEURCMDB, oldConnecteurcmdb, connecteurcmdb));
			}
		}
		return connecteurcmdb;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ConnecteurCmDb basicGetConnecteurcmdb() {
		return connecteurcmdb;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setConnecteurcmdb(ConnecteurCmDb newConnecteurcmdb) {
		ConnecteurCmDb oldConnecteurcmdb = connecteurcmdb;
		connecteurcmdb = newConnecteurcmdb;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModelM1Package.CONFIGURATION_SERVEUR__CONNECTEURCMDB,
					oldConnecteurcmdb, connecteurcmdb));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ConnectionManager getConnectionmanager() {
		if (connectionmanager != null && connectionmanager.eIsProxy()) {
			InternalEObject oldConnectionmanager = (InternalEObject) connectionmanager;
			connectionmanager = (ConnectionManager) eResolveProxy(oldConnectionmanager);
			if (connectionmanager != oldConnectionmanager) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ModelM1Package.CONFIGURATION_SERVEUR__CONNECTIONMANAGER, oldConnectionmanager,
							connectionmanager));
			}
		}
		return connectionmanager;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ConnectionManager basicGetConnectionmanager() {
		return connectionmanager;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setConnectionmanager(ConnectionManager newConnectionmanager) {
		ConnectionManager oldConnectionmanager = connectionmanager;
		connectionmanager = newConnectionmanager;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					ModelM1Package.CONFIGURATION_SERVEUR__CONNECTIONMANAGER, oldConnectionmanager, connectionmanager));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public AttachementCmDb getAttachementcmdb() {
		if (attachementcmdb != null && attachementcmdb.eIsProxy()) {
			InternalEObject oldAttachementcmdb = (InternalEObject) attachementcmdb;
			attachementcmdb = (AttachementCmDb) eResolveProxy(oldAttachementcmdb);
			if (attachementcmdb != oldAttachementcmdb) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ModelM1Package.CONFIGURATION_SERVEUR__ATTACHEMENTCMDB, oldAttachementcmdb,
							attachementcmdb));
			}
		}
		return attachementcmdb;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AttachementCmDb basicGetAttachementcmdb() {
		return attachementcmdb;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setAttachementcmdb(AttachementCmDb newAttachementcmdb) {
		AttachementCmDb oldAttachementcmdb = attachementcmdb;
		attachementcmdb = newAttachementcmdb;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModelM1Package.CONFIGURATION_SERVEUR__ATTACHEMENTCMDB,
					oldAttachementcmdb, attachementcmdb));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public AttachementSmDb getAttachementsmdb() {
		if (attachementsmdb != null && attachementsmdb.eIsProxy()) {
			InternalEObject oldAttachementsmdb = (InternalEObject) attachementsmdb;
			attachementsmdb = (AttachementSmDb) eResolveProxy(oldAttachementsmdb);
			if (attachementsmdb != oldAttachementsmdb) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ModelM1Package.CONFIGURATION_SERVEUR__ATTACHEMENTSMDB, oldAttachementsmdb,
							attachementsmdb));
			}
		}
		return attachementsmdb;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AttachementSmDb basicGetAttachementsmdb() {
		return attachementsmdb;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setAttachementsmdb(AttachementSmDb newAttachementsmdb) {
		AttachementSmDb oldAttachementsmdb = attachementsmdb;
		attachementsmdb = newAttachementsmdb;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModelM1Package.CONFIGURATION_SERVEUR__ATTACHEMENTSMDB,
					oldAttachementsmdb, attachementsmdb));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SecurityManagement getSecuritymanagement() {
		if (securitymanagement != null && securitymanagement.eIsProxy()) {
			InternalEObject oldSecuritymanagement = (InternalEObject) securitymanagement;
			securitymanagement = (SecurityManagement) eResolveProxy(oldSecuritymanagement);
			if (securitymanagement != oldSecuritymanagement) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ModelM1Package.CONFIGURATION_SERVEUR__SECURITYMANAGEMENT, oldSecuritymanagement,
							securitymanagement));
			}
		}
		return securitymanagement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SecurityManagement basicGetSecuritymanagement() {
		return securitymanagement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setSecuritymanagement(SecurityManagement newSecuritymanagement) {
		SecurityManagement oldSecuritymanagement = securitymanagement;
		securitymanagement = newSecuritymanagement;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					ModelM1Package.CONFIGURATION_SERVEUR__SECURITYMANAGEMENT, oldSecuritymanagement,
					securitymanagement));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public AttachementCmSm getAttachementcmsm() {
		if (attachementcmsm != null && attachementcmsm.eIsProxy()) {
			InternalEObject oldAttachementcmsm = (InternalEObject) attachementcmsm;
			attachementcmsm = (AttachementCmSm) eResolveProxy(oldAttachementcmsm);
			if (attachementcmsm != oldAttachementcmsm) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ModelM1Package.CONFIGURATION_SERVEUR__ATTACHEMENTCMSM, oldAttachementcmsm,
							attachementcmsm));
			}
		}
		return attachementcmsm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AttachementCmSm basicGetAttachementcmsm() {
		return attachementcmsm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setAttachementcmsm(AttachementCmSm newAttachementcmsm) {
		AttachementCmSm oldAttachementcmsm = attachementcmsm;
		attachementcmsm = newAttachementcmsm;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModelM1Package.CONFIGURATION_SERVEUR__ATTACHEMENTCMSM,
					oldAttachementcmsm, attachementcmsm));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ConnecteurDbSm getConnecteurdbsm() {
		if (connecteurdbsm != null && connecteurdbsm.eIsProxy()) {
			InternalEObject oldConnecteurdbsm = (InternalEObject) connecteurdbsm;
			connecteurdbsm = (ConnecteurDbSm) eResolveProxy(oldConnecteurdbsm);
			if (connecteurdbsm != oldConnecteurdbsm) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ModelM1Package.CONFIGURATION_SERVEUR__CONNECTEURDBSM, oldConnecteurdbsm, connecteurdbsm));
			}
		}
		return connecteurdbsm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ConnecteurDbSm basicGetConnecteurdbsm() {
		return connecteurdbsm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setConnecteurdbsm(ConnecteurDbSm newConnecteurdbsm) {
		ConnecteurDbSm oldConnecteurdbsm = connecteurdbsm;
		connecteurdbsm = newConnecteurdbsm;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModelM1Package.CONFIGURATION_SERVEUR__CONNECTEURDBSM,
					oldConnecteurdbsm, connecteurdbsm));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public AttachementSmCm getAttachementsmcm() {
		if (attachementsmcm != null && attachementsmcm.eIsProxy()) {
			InternalEObject oldAttachementsmcm = (InternalEObject) attachementsmcm;
			attachementsmcm = (AttachementSmCm) eResolveProxy(oldAttachementsmcm);
			if (attachementsmcm != oldAttachementsmcm) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ModelM1Package.CONFIGURATION_SERVEUR__ATTACHEMENTSMCM, oldAttachementsmcm,
							attachementsmcm));
			}
		}
		return attachementsmcm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AttachementSmCm basicGetAttachementsmcm() {
		return attachementsmcm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setAttachementsmcm(AttachementSmCm newAttachementsmcm) {
		AttachementSmCm oldAttachementsmcm = attachementsmcm;
		attachementsmcm = newAttachementsmcm;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModelM1Package.CONFIGURATION_SERVEUR__ATTACHEMENTSMCM,
					oldAttachementsmcm, attachementsmcm));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Database getDatabase() {
		if (database != null && database.eIsProxy()) {
			InternalEObject oldDatabase = (InternalEObject) database;
			database = (Database) eResolveProxy(oldDatabase);
			if (database != oldDatabase) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ModelM1Package.CONFIGURATION_SERVEUR__DATABASE, oldDatabase, database));
			}
		}
		return database;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Database basicGetDatabase() {
		return database;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setDatabase(Database newDatabase) {
		Database oldDatabase = database;
		database = newDatabase;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModelM1Package.CONFIGURATION_SERVEUR__DATABASE,
					oldDatabase, database));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public AttachementDbCm getAttachementdbcm() {
		if (attachementdbcm != null && attachementdbcm.eIsProxy()) {
			InternalEObject oldAttachementdbcm = (InternalEObject) attachementdbcm;
			attachementdbcm = (AttachementDbCm) eResolveProxy(oldAttachementdbcm);
			if (attachementdbcm != oldAttachementdbcm) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ModelM1Package.CONFIGURATION_SERVEUR__ATTACHEMENTDBCM, oldAttachementdbcm,
							attachementdbcm));
			}
		}
		return attachementdbcm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AttachementDbCm basicGetAttachementdbcm() {
		return attachementdbcm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setAttachementdbcm(AttachementDbCm newAttachementdbcm) {
		AttachementDbCm oldAttachementdbcm = attachementdbcm;
		attachementdbcm = newAttachementdbcm;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModelM1Package.CONFIGURATION_SERVEUR__ATTACHEMENTDBCM,
					oldAttachementdbcm, attachementdbcm));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public AttachementDbSm getAttachementdbsm() {
		if (attachementdbsm != null && attachementdbsm.eIsProxy()) {
			InternalEObject oldAttachementdbsm = (InternalEObject) attachementdbsm;
			attachementdbsm = (AttachementDbSm) eResolveProxy(oldAttachementdbsm);
			if (attachementdbsm != oldAttachementdbsm) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ModelM1Package.CONFIGURATION_SERVEUR__ATTACHEMENTDBSM, oldAttachementdbsm,
							attachementdbsm));
			}
		}
		return attachementdbsm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AttachementDbSm basicGetAttachementdbsm() {
		return attachementdbsm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setAttachementdbsm(AttachementDbSm newAttachementdbsm) {
		AttachementDbSm oldAttachementdbsm = attachementdbsm;
		attachementdbsm = newAttachementdbsm;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModelM1Package.CONFIGURATION_SERVEUR__ATTACHEMENTDBSM,
					oldAttachementdbsm, attachementdbsm));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ConnecteurCmSm getConnecteurcmsm() {
		if (connecteurcmsm != null && connecteurcmsm.eIsProxy()) {
			InternalEObject oldConnecteurcmsm = (InternalEObject) connecteurcmsm;
			connecteurcmsm = (ConnecteurCmSm) eResolveProxy(oldConnecteurcmsm);
			if (connecteurcmsm != oldConnecteurcmsm) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ModelM1Package.CONFIGURATION_SERVEUR__CONNECTEURCMSM, oldConnecteurcmsm, connecteurcmsm));
			}
		}
		return connecteurcmsm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ConnecteurCmSm basicGetConnecteurcmsm() {
		return connecteurcmsm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setConnecteurcmsm(ConnecteurCmSm newConnecteurcmsm) {
		ConnecteurCmSm oldConnecteurcmsm = connecteurcmsm;
		connecteurcmsm = newConnecteurcmsm;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModelM1Package.CONFIGURATION_SERVEUR__CONNECTEURCMSM,
					oldConnecteurcmsm, connecteurcmsm));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ModelM1Package.CONFIGURATION_SERVEUR__INTERFACECONFIGURATIONSERVEUR:
			if (resolve)
				return getInterfaceconfigurationserveur();
			return basicGetInterfaceconfigurationserveur();
		case ModelM1Package.CONFIGURATION_SERVEUR__SECURITYMANAGER:
			if (resolve)
				return getSecuritymanager();
			return basicGetSecuritymanager();
		case ModelM1Package.CONFIGURATION_SERVEUR__CONNECTEURCMDB:
			if (resolve)
				return getConnecteurcmdb();
			return basicGetConnecteurcmdb();
		case ModelM1Package.CONFIGURATION_SERVEUR__CONNECTIONMANAGER:
			if (resolve)
				return getConnectionmanager();
			return basicGetConnectionmanager();
		case ModelM1Package.CONFIGURATION_SERVEUR__ATTACHEMENTCMDB:
			if (resolve)
				return getAttachementcmdb();
			return basicGetAttachementcmdb();
		case ModelM1Package.CONFIGURATION_SERVEUR__ATTACHEMENTSMDB:
			if (resolve)
				return getAttachementsmdb();
			return basicGetAttachementsmdb();
		case ModelM1Package.CONFIGURATION_SERVEUR__SECURITYMANAGEMENT:
			if (resolve)
				return getSecuritymanagement();
			return basicGetSecuritymanagement();
		case ModelM1Package.CONFIGURATION_SERVEUR__ATTACHEMENTCMSM:
			if (resolve)
				return getAttachementcmsm();
			return basicGetAttachementcmsm();
		case ModelM1Package.CONFIGURATION_SERVEUR__CONNECTEURDBSM:
			if (resolve)
				return getConnecteurdbsm();
			return basicGetConnecteurdbsm();
		case ModelM1Package.CONFIGURATION_SERVEUR__ATTACHEMENTSMCM:
			if (resolve)
				return getAttachementsmcm();
			return basicGetAttachementsmcm();
		case ModelM1Package.CONFIGURATION_SERVEUR__DATABASE:
			if (resolve)
				return getDatabase();
			return basicGetDatabase();
		case ModelM1Package.CONFIGURATION_SERVEUR__ATTACHEMENTDBCM:
			if (resolve)
				return getAttachementdbcm();
			return basicGetAttachementdbcm();
		case ModelM1Package.CONFIGURATION_SERVEUR__ATTACHEMENTDBSM:
			if (resolve)
				return getAttachementdbsm();
			return basicGetAttachementdbsm();
		case ModelM1Package.CONFIGURATION_SERVEUR__CONNECTEURCMSM:
			if (resolve)
				return getConnecteurcmsm();
			return basicGetConnecteurcmsm();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ModelM1Package.CONFIGURATION_SERVEUR__INTERFACECONFIGURATIONSERVEUR:
			setInterfaceconfigurationserveur((InterfaceConfigurationServeur) newValue);
			return;
		case ModelM1Package.CONFIGURATION_SERVEUR__SECURITYMANAGER:
			setSecuritymanager((modelM1.SecurityManager) newValue);
			return;
		case ModelM1Package.CONFIGURATION_SERVEUR__CONNECTEURCMDB:
			setConnecteurcmdb((ConnecteurCmDb) newValue);
			return;
		case ModelM1Package.CONFIGURATION_SERVEUR__CONNECTIONMANAGER:
			setConnectionmanager((ConnectionManager) newValue);
			return;
		case ModelM1Package.CONFIGURATION_SERVEUR__ATTACHEMENTCMDB:
			setAttachementcmdb((AttachementCmDb) newValue);
			return;
		case ModelM1Package.CONFIGURATION_SERVEUR__ATTACHEMENTSMDB:
			setAttachementsmdb((AttachementSmDb) newValue);
			return;
		case ModelM1Package.CONFIGURATION_SERVEUR__SECURITYMANAGEMENT:
			setSecuritymanagement((SecurityManagement) newValue);
			return;
		case ModelM1Package.CONFIGURATION_SERVEUR__ATTACHEMENTCMSM:
			setAttachementcmsm((AttachementCmSm) newValue);
			return;
		case ModelM1Package.CONFIGURATION_SERVEUR__CONNECTEURDBSM:
			setConnecteurdbsm((ConnecteurDbSm) newValue);
			return;
		case ModelM1Package.CONFIGURATION_SERVEUR__ATTACHEMENTSMCM:
			setAttachementsmcm((AttachementSmCm) newValue);
			return;
		case ModelM1Package.CONFIGURATION_SERVEUR__DATABASE:
			setDatabase((Database) newValue);
			return;
		case ModelM1Package.CONFIGURATION_SERVEUR__ATTACHEMENTDBCM:
			setAttachementdbcm((AttachementDbCm) newValue);
			return;
		case ModelM1Package.CONFIGURATION_SERVEUR__ATTACHEMENTDBSM:
			setAttachementdbsm((AttachementDbSm) newValue);
			return;
		case ModelM1Package.CONFIGURATION_SERVEUR__CONNECTEURCMSM:
			setConnecteurcmsm((ConnecteurCmSm) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ModelM1Package.CONFIGURATION_SERVEUR__INTERFACECONFIGURATIONSERVEUR:
			setInterfaceconfigurationserveur((InterfaceConfigurationServeur) null);
			return;
		case ModelM1Package.CONFIGURATION_SERVEUR__SECURITYMANAGER:
			setSecuritymanager((modelM1.SecurityManager) null);
			return;
		case ModelM1Package.CONFIGURATION_SERVEUR__CONNECTEURCMDB:
			setConnecteurcmdb((ConnecteurCmDb) null);
			return;
		case ModelM1Package.CONFIGURATION_SERVEUR__CONNECTIONMANAGER:
			setConnectionmanager((ConnectionManager) null);
			return;
		case ModelM1Package.CONFIGURATION_SERVEUR__ATTACHEMENTCMDB:
			setAttachementcmdb((AttachementCmDb) null);
			return;
		case ModelM1Package.CONFIGURATION_SERVEUR__ATTACHEMENTSMDB:
			setAttachementsmdb((AttachementSmDb) null);
			return;
		case ModelM1Package.CONFIGURATION_SERVEUR__SECURITYMANAGEMENT:
			setSecuritymanagement((SecurityManagement) null);
			return;
		case ModelM1Package.CONFIGURATION_SERVEUR__ATTACHEMENTCMSM:
			setAttachementcmsm((AttachementCmSm) null);
			return;
		case ModelM1Package.CONFIGURATION_SERVEUR__CONNECTEURDBSM:
			setConnecteurdbsm((ConnecteurDbSm) null);
			return;
		case ModelM1Package.CONFIGURATION_SERVEUR__ATTACHEMENTSMCM:
			setAttachementsmcm((AttachementSmCm) null);
			return;
		case ModelM1Package.CONFIGURATION_SERVEUR__DATABASE:
			setDatabase((Database) null);
			return;
		case ModelM1Package.CONFIGURATION_SERVEUR__ATTACHEMENTDBCM:
			setAttachementdbcm((AttachementDbCm) null);
			return;
		case ModelM1Package.CONFIGURATION_SERVEUR__ATTACHEMENTDBSM:
			setAttachementdbsm((AttachementDbSm) null);
			return;
		case ModelM1Package.CONFIGURATION_SERVEUR__CONNECTEURCMSM:
			setConnecteurcmsm((ConnecteurCmSm) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ModelM1Package.CONFIGURATION_SERVEUR__INTERFACECONFIGURATIONSERVEUR:
			return interfaceconfigurationserveur != null;
		case ModelM1Package.CONFIGURATION_SERVEUR__SECURITYMANAGER:
			return securitymanager != null;
		case ModelM1Package.CONFIGURATION_SERVEUR__CONNECTEURCMDB:
			return connecteurcmdb != null;
		case ModelM1Package.CONFIGURATION_SERVEUR__CONNECTIONMANAGER:
			return connectionmanager != null;
		case ModelM1Package.CONFIGURATION_SERVEUR__ATTACHEMENTCMDB:
			return attachementcmdb != null;
		case ModelM1Package.CONFIGURATION_SERVEUR__ATTACHEMENTSMDB:
			return attachementsmdb != null;
		case ModelM1Package.CONFIGURATION_SERVEUR__SECURITYMANAGEMENT:
			return securitymanagement != null;
		case ModelM1Package.CONFIGURATION_SERVEUR__ATTACHEMENTCMSM:
			return attachementcmsm != null;
		case ModelM1Package.CONFIGURATION_SERVEUR__CONNECTEURDBSM:
			return connecteurdbsm != null;
		case ModelM1Package.CONFIGURATION_SERVEUR__ATTACHEMENTSMCM:
			return attachementsmcm != null;
		case ModelM1Package.CONFIGURATION_SERVEUR__DATABASE:
			return database != null;
		case ModelM1Package.CONFIGURATION_SERVEUR__ATTACHEMENTDBCM:
			return attachementdbcm != null;
		case ModelM1Package.CONFIGURATION_SERVEUR__ATTACHEMENTDBSM:
			return attachementdbsm != null;
		case ModelM1Package.CONFIGURATION_SERVEUR__CONNECTEURCMSM:
			return connecteurcmsm != null;
		}
		return super.eIsSet(featureID);
	}

} //ConfigurationServeurImpl

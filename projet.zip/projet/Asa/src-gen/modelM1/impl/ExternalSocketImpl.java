/**
 */
package modelM1.impl;

import modelM1.ExternalSocket;
import modelM1.ModelM1Package;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>External Socket</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ExternalSocketImpl extends MinimalEObjectImpl.Container implements ExternalSocket {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ExternalSocketImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModelM1Package.Literals.EXTERNAL_SOCKET;
	}

} //ExternalSocketImpl

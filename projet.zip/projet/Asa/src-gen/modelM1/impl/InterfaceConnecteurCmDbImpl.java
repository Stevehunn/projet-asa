/**
 */
package modelM1.impl;

import modelM1.InterfaceConnecteurCmDb;
import modelM1.ModelM1Package;
import modelM1.RoleCm;
import modelM1.RoleDb;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Interface Connecteur Cm Db</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link modelM1.impl.InterfaceConnecteurCmDbImpl#getRoledb <em>Roledb</em>}</li>
 *   <li>{@link modelM1.impl.InterfaceConnecteurCmDbImpl#getRolecm <em>Rolecm</em>}</li>
 * </ul>
 *
 * @generated
 */
public class InterfaceConnecteurCmDbImpl extends MinimalEObjectImpl.Container implements InterfaceConnecteurCmDb {
	/**
	 * The cached value of the '{@link #getRoledb() <em>Roledb</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRoledb()
	 * @generated
	 * @ordered
	 */
	protected RoleDb roledb;

	/**
	 * The cached value of the '{@link #getRolecm() <em>Rolecm</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRolecm()
	 * @generated
	 * @ordered
	 */
	protected RoleCm rolecm;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected InterfaceConnecteurCmDbImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModelM1Package.Literals.INTERFACE_CONNECTEUR_CM_DB;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public RoleDb getRoledb() {
		if (roledb != null && roledb.eIsProxy()) {
			InternalEObject oldRoledb = (InternalEObject) roledb;
			roledb = (RoleDb) eResolveProxy(oldRoledb);
			if (roledb != oldRoledb) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ModelM1Package.INTERFACE_CONNECTEUR_CM_DB__ROLEDB, oldRoledb, roledb));
			}
		}
		return roledb;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RoleDb basicGetRoledb() {
		return roledb;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setRoledb(RoleDb newRoledb) {
		RoleDb oldRoledb = roledb;
		roledb = newRoledb;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModelM1Package.INTERFACE_CONNECTEUR_CM_DB__ROLEDB,
					oldRoledb, roledb));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public RoleCm getRolecm() {
		if (rolecm != null && rolecm.eIsProxy()) {
			InternalEObject oldRolecm = (InternalEObject) rolecm;
			rolecm = (RoleCm) eResolveProxy(oldRolecm);
			if (rolecm != oldRolecm) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ModelM1Package.INTERFACE_CONNECTEUR_CM_DB__ROLECM, oldRolecm, rolecm));
			}
		}
		return rolecm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RoleCm basicGetRolecm() {
		return rolecm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setRolecm(RoleCm newRolecm) {
		RoleCm oldRolecm = rolecm;
		rolecm = newRolecm;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModelM1Package.INTERFACE_CONNECTEUR_CM_DB__ROLECM,
					oldRolecm, rolecm));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ModelM1Package.INTERFACE_CONNECTEUR_CM_DB__ROLEDB:
			if (resolve)
				return getRoledb();
			return basicGetRoledb();
		case ModelM1Package.INTERFACE_CONNECTEUR_CM_DB__ROLECM:
			if (resolve)
				return getRolecm();
			return basicGetRolecm();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ModelM1Package.INTERFACE_CONNECTEUR_CM_DB__ROLEDB:
			setRoledb((RoleDb) newValue);
			return;
		case ModelM1Package.INTERFACE_CONNECTEUR_CM_DB__ROLECM:
			setRolecm((RoleCm) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ModelM1Package.INTERFACE_CONNECTEUR_CM_DB__ROLEDB:
			setRoledb((RoleDb) null);
			return;
		case ModelM1Package.INTERFACE_CONNECTEUR_CM_DB__ROLECM:
			setRolecm((RoleCm) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ModelM1Package.INTERFACE_CONNECTEUR_CM_DB__ROLEDB:
			return roledb != null;
		case ModelM1Package.INTERFACE_CONNECTEUR_CM_DB__ROLECM:
			return rolecm != null;
		}
		return super.eIsSet(featureID);
	}

} //InterfaceConnecteurCmDbImpl

/**
 */
package modelM1.impl;

import modelM1.BindingExternalSocket;
import modelM1.ExternalSocket;
import modelM1.ModelM1Package;
import modelM1.PortFourniConfigurationServeur;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Binding External Socket</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link modelM1.impl.BindingExternalSocketImpl#getExternalsocket <em>Externalsocket</em>}</li>
 *   <li>{@link modelM1.impl.BindingExternalSocketImpl#getPortfourniconfigurationserveur <em>Portfourniconfigurationserveur</em>}</li>
 * </ul>
 *
 * @generated
 */
public class BindingExternalSocketImpl extends MinimalEObjectImpl.Container implements BindingExternalSocket {
	/**
	 * The cached value of the '{@link #getExternalsocket() <em>Externalsocket</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getExternalsocket()
	 * @generated
	 * @ordered
	 */
	protected ExternalSocket externalsocket;

	/**
	 * The cached value of the '{@link #getPortfourniconfigurationserveur() <em>Portfourniconfigurationserveur</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPortfourniconfigurationserveur()
	 * @generated
	 * @ordered
	 */
	protected PortFourniConfigurationServeur portfourniconfigurationserveur;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected BindingExternalSocketImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModelM1Package.Literals.BINDING_EXTERNAL_SOCKET;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ExternalSocket getExternalsocket() {
		if (externalsocket != null && externalsocket.eIsProxy()) {
			InternalEObject oldExternalsocket = (InternalEObject) externalsocket;
			externalsocket = (ExternalSocket) eResolveProxy(oldExternalsocket);
			if (externalsocket != oldExternalsocket) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ModelM1Package.BINDING_EXTERNAL_SOCKET__EXTERNALSOCKET, oldExternalsocket, externalsocket));
			}
		}
		return externalsocket;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ExternalSocket basicGetExternalsocket() {
		return externalsocket;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setExternalsocket(ExternalSocket newExternalsocket) {
		ExternalSocket oldExternalsocket = externalsocket;
		externalsocket = newExternalsocket;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					ModelM1Package.BINDING_EXTERNAL_SOCKET__EXTERNALSOCKET, oldExternalsocket, externalsocket));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public PortFourniConfigurationServeur getPortfourniconfigurationserveur() {
		if (portfourniconfigurationserveur != null && portfourniconfigurationserveur.eIsProxy()) {
			InternalEObject oldPortfourniconfigurationserveur = (InternalEObject) portfourniconfigurationserveur;
			portfourniconfigurationserveur = (PortFourniConfigurationServeur) eResolveProxy(
					oldPortfourniconfigurationserveur);
			if (portfourniconfigurationserveur != oldPortfourniconfigurationserveur) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ModelM1Package.BINDING_EXTERNAL_SOCKET__PORTFOURNICONFIGURATIONSERVEUR,
							oldPortfourniconfigurationserveur, portfourniconfigurationserveur));
			}
		}
		return portfourniconfigurationserveur;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PortFourniConfigurationServeur basicGetPortfourniconfigurationserveur() {
		return portfourniconfigurationserveur;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setPortfourniconfigurationserveur(PortFourniConfigurationServeur newPortfourniconfigurationserveur) {
		PortFourniConfigurationServeur oldPortfourniconfigurationserveur = portfourniconfigurationserveur;
		portfourniconfigurationserveur = newPortfourniconfigurationserveur;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					ModelM1Package.BINDING_EXTERNAL_SOCKET__PORTFOURNICONFIGURATIONSERVEUR,
					oldPortfourniconfigurationserveur, portfourniconfigurationserveur));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ModelM1Package.BINDING_EXTERNAL_SOCKET__EXTERNALSOCKET:
			if (resolve)
				return getExternalsocket();
			return basicGetExternalsocket();
		case ModelM1Package.BINDING_EXTERNAL_SOCKET__PORTFOURNICONFIGURATIONSERVEUR:
			if (resolve)
				return getPortfourniconfigurationserveur();
			return basicGetPortfourniconfigurationserveur();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ModelM1Package.BINDING_EXTERNAL_SOCKET__EXTERNALSOCKET:
			setExternalsocket((ExternalSocket) newValue);
			return;
		case ModelM1Package.BINDING_EXTERNAL_SOCKET__PORTFOURNICONFIGURATIONSERVEUR:
			setPortfourniconfigurationserveur((PortFourniConfigurationServeur) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ModelM1Package.BINDING_EXTERNAL_SOCKET__EXTERNALSOCKET:
			setExternalsocket((ExternalSocket) null);
			return;
		case ModelM1Package.BINDING_EXTERNAL_SOCKET__PORTFOURNICONFIGURATIONSERVEUR:
			setPortfourniconfigurationserveur((PortFourniConfigurationServeur) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ModelM1Package.BINDING_EXTERNAL_SOCKET__EXTERNALSOCKET:
			return externalsocket != null;
		case ModelM1Package.BINDING_EXTERNAL_SOCKET__PORTFOURNICONFIGURATIONSERVEUR:
			return portfourniconfigurationserveur != null;
		}
		return super.eIsSet(featureID);
	}

} //BindingExternalSocketImpl

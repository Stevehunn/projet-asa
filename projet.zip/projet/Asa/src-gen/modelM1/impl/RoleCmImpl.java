/**
 */
package modelM1.impl;

import modelM1.ModelM1Package;
import modelM1.RoleCm;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Role Cm</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class RoleCmImpl extends MinimalEObjectImpl.Container implements RoleCm {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected RoleCmImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModelM1Package.Literals.ROLE_CM;
	}

} //RoleCmImpl

/**
 */
package modelM1.impl;

import modelM1.InterfaceDatabase;
import modelM1.ModelM1Package;
import modelM1.QueryInterogation;
import modelM1.SecurityManagement;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Interface Database</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link modelM1.impl.InterfaceDatabaseImpl#getQueryinterogation <em>Queryinterogation</em>}</li>
 *   <li>{@link modelM1.impl.InterfaceDatabaseImpl#getSecuritymanagement <em>Securitymanagement</em>}</li>
 * </ul>
 *
 * @generated
 */
public class InterfaceDatabaseImpl extends MinimalEObjectImpl.Container implements InterfaceDatabase {
	/**
	 * The cached value of the '{@link #getQueryinterogation() <em>Queryinterogation</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getQueryinterogation()
	 * @generated
	 * @ordered
	 */
	protected QueryInterogation queryinterogation;

	/**
	 * The cached value of the '{@link #getSecuritymanagement() <em>Securitymanagement</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSecuritymanagement()
	 * @generated
	 * @ordered
	 */
	protected SecurityManagement securitymanagement;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected InterfaceDatabaseImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModelM1Package.Literals.INTERFACE_DATABASE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public QueryInterogation getQueryinterogation() {
		if (queryinterogation != null && queryinterogation.eIsProxy()) {
			InternalEObject oldQueryinterogation = (InternalEObject) queryinterogation;
			queryinterogation = (QueryInterogation) eResolveProxy(oldQueryinterogation);
			if (queryinterogation != oldQueryinterogation) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ModelM1Package.INTERFACE_DATABASE__QUERYINTEROGATION, oldQueryinterogation,
							queryinterogation));
			}
		}
		return queryinterogation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public QueryInterogation basicGetQueryinterogation() {
		return queryinterogation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setQueryinterogation(QueryInterogation newQueryinterogation) {
		QueryInterogation oldQueryinterogation = queryinterogation;
		queryinterogation = newQueryinterogation;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModelM1Package.INTERFACE_DATABASE__QUERYINTEROGATION,
					oldQueryinterogation, queryinterogation));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SecurityManagement getSecuritymanagement() {
		if (securitymanagement != null && securitymanagement.eIsProxy()) {
			InternalEObject oldSecuritymanagement = (InternalEObject) securitymanagement;
			securitymanagement = (SecurityManagement) eResolveProxy(oldSecuritymanagement);
			if (securitymanagement != oldSecuritymanagement) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ModelM1Package.INTERFACE_DATABASE__SECURITYMANAGEMENT, oldSecuritymanagement,
							securitymanagement));
			}
		}
		return securitymanagement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SecurityManagement basicGetSecuritymanagement() {
		return securitymanagement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setSecuritymanagement(SecurityManagement newSecuritymanagement) {
		SecurityManagement oldSecuritymanagement = securitymanagement;
		securitymanagement = newSecuritymanagement;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModelM1Package.INTERFACE_DATABASE__SECURITYMANAGEMENT,
					oldSecuritymanagement, securitymanagement));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ModelM1Package.INTERFACE_DATABASE__QUERYINTEROGATION:
			if (resolve)
				return getQueryinterogation();
			return basicGetQueryinterogation();
		case ModelM1Package.INTERFACE_DATABASE__SECURITYMANAGEMENT:
			if (resolve)
				return getSecuritymanagement();
			return basicGetSecuritymanagement();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ModelM1Package.INTERFACE_DATABASE__QUERYINTEROGATION:
			setQueryinterogation((QueryInterogation) newValue);
			return;
		case ModelM1Package.INTERFACE_DATABASE__SECURITYMANAGEMENT:
			setSecuritymanagement((SecurityManagement) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ModelM1Package.INTERFACE_DATABASE__QUERYINTEROGATION:
			setQueryinterogation((QueryInterogation) null);
			return;
		case ModelM1Package.INTERFACE_DATABASE__SECURITYMANAGEMENT:
			setSecuritymanagement((SecurityManagement) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ModelM1Package.INTERFACE_DATABASE__QUERYINTEROGATION:
			return queryinterogation != null;
		case ModelM1Package.INTERFACE_DATABASE__SECURITYMANAGEMENT:
			return securitymanagement != null;
		}
		return super.eIsSet(featureID);
	}

} //InterfaceDatabaseImpl

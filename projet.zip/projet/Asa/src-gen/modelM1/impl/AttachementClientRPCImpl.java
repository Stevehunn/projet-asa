/**
 */
package modelM1.impl;

import modelM1.AttachementClientRPC;
import modelM1.InterfaceConnecteurRPC;
import modelM1.ModelM1Package;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import asa.impl.RoleFourniImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Attachement Client RPC</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link modelM1.impl.AttachementClientRPCImpl#getInterfaceconnecteurrpc <em>Interfaceconnecteurrpc</em>}</li>
 * </ul>
 *
 * @generated
 */
public class AttachementClientRPCImpl extends MinimalEObjectImpl.Container implements AttachementClientRPC {
	/**
	 * The cached value of the '{@link #getInterfaceconnecteurrpc() <em>Interfaceconnecteurrpc</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInterfaceconnecteurrpc()
	 * @generated
	 * @ordered
	 */
	protected InterfaceConnecteurRPC interfaceconnecteurrpc;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AttachementClientRPCImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModelM1Package.Literals.ATTACHEMENT_CLIENT_RPC;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public InterfaceConnecteurRPC getInterfaceconnecteurrpc() {
		if (interfaceconnecteurrpc != null && interfaceconnecteurrpc.eIsProxy()) {
			InternalEObject oldInterfaceconnecteurrpc = (InternalEObject) interfaceconnecteurrpc;
			interfaceconnecteurrpc = (InterfaceConnecteurRPC) eResolveProxy(oldInterfaceconnecteurrpc);
			if (interfaceconnecteurrpc != oldInterfaceconnecteurrpc) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ModelM1Package.ATTACHEMENT_CLIENT_RPC__INTERFACECONNECTEURRPC, oldInterfaceconnecteurrpc,
							interfaceconnecteurrpc));
			}
		}
		return interfaceconnecteurrpc;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public InterfaceConnecteurRPC basicGetInterfaceconnecteurrpc() {
		return interfaceconnecteurrpc;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setInterfaceconnecteurrpc(InterfaceConnecteurRPC newInterfaceconnecteurrpc) {
		InterfaceConnecteurRPC oldInterfaceconnecteurrpc = interfaceconnecteurrpc;
		interfaceconnecteurrpc = newInterfaceconnecteurrpc;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					ModelM1Package.ATTACHEMENT_CLIENT_RPC__INTERFACECONNECTEURRPC, oldInterfaceconnecteurrpc,
					interfaceconnecteurrpc));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ModelM1Package.ATTACHEMENT_CLIENT_RPC__INTERFACECONNECTEURRPC:
			if (resolve)
				return getInterfaceconnecteurrpc();
			return basicGetInterfaceconnecteurrpc();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ModelM1Package.ATTACHEMENT_CLIENT_RPC__INTERFACECONNECTEURRPC:
			setInterfaceconnecteurrpc((InterfaceConnecteurRPC) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ModelM1Package.ATTACHEMENT_CLIENT_RPC__INTERFACECONNECTEURRPC:
			setInterfaceconnecteurrpc((InterfaceConnecteurRPC) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ModelM1Package.ATTACHEMENT_CLIENT_RPC__INTERFACECONNECTEURRPC:
			return interfaceconnecteurrpc != null;
		}
		return super.eIsSet(featureID);
	}

	public void setRoleFourni(RoleFourniImpl roleClient) {
		// TODO Auto-generated method stub
		
	}

	public void setPortRequis(PortRequisClientImpl portClient) {
		// TODO Auto-generated method stub
		
	}

} //AttachementClientRPCImpl

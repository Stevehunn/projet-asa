/**
 */
package modelM1.impl;

import modelM1.AttachementDbCm;
import modelM1.ModelM1Package;
import modelM1.QueryInterogation;
import modelM1.RoleCm;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Attachement Db Cm</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link modelM1.impl.AttachementDbCmImpl#getQueryinterogation <em>Queryinterogation</em>}</li>
 *   <li>{@link modelM1.impl.AttachementDbCmImpl#getRolecm <em>Rolecm</em>}</li>
 * </ul>
 *
 * @generated
 */
public class AttachementDbCmImpl extends MinimalEObjectImpl.Container implements AttachementDbCm {
	/**
	 * The cached value of the '{@link #getQueryinterogation() <em>Queryinterogation</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getQueryinterogation()
	 * @generated
	 * @ordered
	 */
	protected QueryInterogation queryinterogation;

	/**
	 * The cached value of the '{@link #getRolecm() <em>Rolecm</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRolecm()
	 * @generated
	 * @ordered
	 */
	protected RoleCm rolecm;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AttachementDbCmImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModelM1Package.Literals.ATTACHEMENT_DB_CM;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public QueryInterogation getQueryinterogation() {
		if (queryinterogation != null && queryinterogation.eIsProxy()) {
			InternalEObject oldQueryinterogation = (InternalEObject) queryinterogation;
			queryinterogation = (QueryInterogation) eResolveProxy(oldQueryinterogation);
			if (queryinterogation != oldQueryinterogation) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ModelM1Package.ATTACHEMENT_DB_CM__QUERYINTEROGATION, oldQueryinterogation,
							queryinterogation));
			}
		}
		return queryinterogation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public QueryInterogation basicGetQueryinterogation() {
		return queryinterogation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setQueryinterogation(QueryInterogation newQueryinterogation) {
		QueryInterogation oldQueryinterogation = queryinterogation;
		queryinterogation = newQueryinterogation;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModelM1Package.ATTACHEMENT_DB_CM__QUERYINTEROGATION,
					oldQueryinterogation, queryinterogation));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public RoleCm getRolecm() {
		if (rolecm != null && rolecm.eIsProxy()) {
			InternalEObject oldRolecm = (InternalEObject) rolecm;
			rolecm = (RoleCm) eResolveProxy(oldRolecm);
			if (rolecm != oldRolecm) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, ModelM1Package.ATTACHEMENT_DB_CM__ROLECM,
							oldRolecm, rolecm));
			}
		}
		return rolecm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RoleCm basicGetRolecm() {
		return rolecm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setRolecm(RoleCm newRolecm) {
		RoleCm oldRolecm = rolecm;
		rolecm = newRolecm;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModelM1Package.ATTACHEMENT_DB_CM__ROLECM, oldRolecm,
					rolecm));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ModelM1Package.ATTACHEMENT_DB_CM__QUERYINTEROGATION:
			if (resolve)
				return getQueryinterogation();
			return basicGetQueryinterogation();
		case ModelM1Package.ATTACHEMENT_DB_CM__ROLECM:
			if (resolve)
				return getRolecm();
			return basicGetRolecm();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ModelM1Package.ATTACHEMENT_DB_CM__QUERYINTEROGATION:
			setQueryinterogation((QueryInterogation) newValue);
			return;
		case ModelM1Package.ATTACHEMENT_DB_CM__ROLECM:
			setRolecm((RoleCm) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ModelM1Package.ATTACHEMENT_DB_CM__QUERYINTEROGATION:
			setQueryinterogation((QueryInterogation) null);
			return;
		case ModelM1Package.ATTACHEMENT_DB_CM__ROLECM:
			setRolecm((RoleCm) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ModelM1Package.ATTACHEMENT_DB_CM__QUERYINTEROGATION:
			return queryinterogation != null;
		case ModelM1Package.ATTACHEMENT_DB_CM__ROLECM:
			return rolecm != null;
		}
		return super.eIsSet(featureID);
	}

} //AttachementDbCmImpl

/**
 */
package modelM1.impl;

import modelM1.InterfaceConnecteurCmSm;
import modelM1.ModelM1Package;
import modelM1.RoleCm;
import modelM1.RoleSm;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Interface Connecteur Cm Sm</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link modelM1.impl.InterfaceConnecteurCmSmImpl#getRolecm <em>Rolecm</em>}</li>
 *   <li>{@link modelM1.impl.InterfaceConnecteurCmSmImpl#getRolesm <em>Rolesm</em>}</li>
 * </ul>
 *
 * @generated
 */
public class InterfaceConnecteurCmSmImpl extends MinimalEObjectImpl.Container implements InterfaceConnecteurCmSm {
	/**
	 * The cached value of the '{@link #getRolecm() <em>Rolecm</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRolecm()
	 * @generated
	 * @ordered
	 */
	protected RoleCm rolecm;

	/**
	 * The cached value of the '{@link #getRolesm() <em>Rolesm</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRolesm()
	 * @generated
	 * @ordered
	 */
	protected RoleSm rolesm;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected InterfaceConnecteurCmSmImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModelM1Package.Literals.INTERFACE_CONNECTEUR_CM_SM;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public RoleCm getRolecm() {
		if (rolecm != null && rolecm.eIsProxy()) {
			InternalEObject oldRolecm = (InternalEObject) rolecm;
			rolecm = (RoleCm) eResolveProxy(oldRolecm);
			if (rolecm != oldRolecm) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ModelM1Package.INTERFACE_CONNECTEUR_CM_SM__ROLECM, oldRolecm, rolecm));
			}
		}
		return rolecm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RoleCm basicGetRolecm() {
		return rolecm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setRolecm(RoleCm newRolecm) {
		RoleCm oldRolecm = rolecm;
		rolecm = newRolecm;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModelM1Package.INTERFACE_CONNECTEUR_CM_SM__ROLECM,
					oldRolecm, rolecm));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public RoleSm getRolesm() {
		if (rolesm != null && rolesm.eIsProxy()) {
			InternalEObject oldRolesm = (InternalEObject) rolesm;
			rolesm = (RoleSm) eResolveProxy(oldRolesm);
			if (rolesm != oldRolesm) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ModelM1Package.INTERFACE_CONNECTEUR_CM_SM__ROLESM, oldRolesm, rolesm));
			}
		}
		return rolesm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RoleSm basicGetRolesm() {
		return rolesm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setRolesm(RoleSm newRolesm) {
		RoleSm oldRolesm = rolesm;
		rolesm = newRolesm;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModelM1Package.INTERFACE_CONNECTEUR_CM_SM__ROLESM,
					oldRolesm, rolesm));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ModelM1Package.INTERFACE_CONNECTEUR_CM_SM__ROLECM:
			if (resolve)
				return getRolecm();
			return basicGetRolecm();
		case ModelM1Package.INTERFACE_CONNECTEUR_CM_SM__ROLESM:
			if (resolve)
				return getRolesm();
			return basicGetRolesm();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ModelM1Package.INTERFACE_CONNECTEUR_CM_SM__ROLECM:
			setRolecm((RoleCm) newValue);
			return;
		case ModelM1Package.INTERFACE_CONNECTEUR_CM_SM__ROLESM:
			setRolesm((RoleSm) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ModelM1Package.INTERFACE_CONNECTEUR_CM_SM__ROLECM:
			setRolecm((RoleCm) null);
			return;
		case ModelM1Package.INTERFACE_CONNECTEUR_CM_SM__ROLESM:
			setRolesm((RoleSm) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ModelM1Package.INTERFACE_CONNECTEUR_CM_SM__ROLECM:
			return rolecm != null;
		case ModelM1Package.INTERFACE_CONNECTEUR_CM_SM__ROLESM:
			return rolesm != null;
		}
		return super.eIsSet(featureID);
	}

} //InterfaceConnecteurCmSmImpl

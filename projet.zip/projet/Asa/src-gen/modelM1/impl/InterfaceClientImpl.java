/**
 */
package modelM1.impl;

import modelM1.AttachementClientRPC;
import modelM1.InterfaceClient;
import modelM1.ModelM1Package;
import modelM1.PortFourniClient;
import modelM1.PortRequisClient;
import modelM1.ServiceFourniClient;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Interface Client</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link modelM1.impl.InterfaceClientImpl#getAttachementclientrpc <em>Attachementclientrpc</em>}</li>
 *   <li>{@link modelM1.impl.InterfaceClientImpl#getPortfourniclient <em>Portfourniclient</em>}</li>
 *   <li>{@link modelM1.impl.InterfaceClientImpl#getPortrequisclient <em>Portrequisclient</em>}</li>
 *   <li>{@link modelM1.impl.InterfaceClientImpl#getServicefourniclient <em>Servicefourniclient</em>}</li>
 * </ul>
 *
 * @generated
 */
public class InterfaceClientImpl extends MinimalEObjectImpl.Container implements InterfaceClient {
	/**
	 * The cached value of the '{@link #getAttachementclientrpc() <em>Attachementclientrpc</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAttachementclientrpc()
	 * @generated
	 * @ordered
	 */
	protected AttachementClientRPC attachementclientrpc;

	/**
	 * The cached value of the '{@link #getPortfourniclient() <em>Portfourniclient</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPortfourniclient()
	 * @generated
	 * @ordered
	 */
	protected PortFourniClient portfourniclient;

	/**
	 * The cached value of the '{@link #getPortrequisclient() <em>Portrequisclient</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPortrequisclient()
	 * @generated
	 * @ordered
	 */
	protected PortRequisClient portrequisclient;

	/**
	 * The cached value of the '{@link #getServicefourniclient() <em>Servicefourniclient</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getServicefourniclient()
	 * @generated
	 * @ordered
	 */
	protected ServiceFourniClient servicefourniclient;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public InterfaceClientImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModelM1Package.Literals.INTERFACE_CLIENT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public AttachementClientRPC getAttachementclientrpc() {
		if (attachementclientrpc != null && attachementclientrpc.eIsProxy()) {
			InternalEObject oldAttachementclientrpc = (InternalEObject) attachementclientrpc;
			attachementclientrpc = (AttachementClientRPC) eResolveProxy(oldAttachementclientrpc);
			if (attachementclientrpc != oldAttachementclientrpc) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ModelM1Package.INTERFACE_CLIENT__ATTACHEMENTCLIENTRPC, oldAttachementclientrpc,
							attachementclientrpc));
			}
		}
		return attachementclientrpc;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AttachementClientRPC basicGetAttachementclientrpc() {
		return attachementclientrpc;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setAttachementclientrpc(AttachementClientRPC newAttachementclientrpc) {
		AttachementClientRPC oldAttachementclientrpc = attachementclientrpc;
		attachementclientrpc = newAttachementclientrpc;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModelM1Package.INTERFACE_CLIENT__ATTACHEMENTCLIENTRPC,
					oldAttachementclientrpc, attachementclientrpc));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public PortFourniClient getPortfourniclient() {
		if (portfourniclient != null && portfourniclient.eIsProxy()) {
			InternalEObject oldPortfourniclient = (InternalEObject) portfourniclient;
			portfourniclient = (PortFourniClient) eResolveProxy(oldPortfourniclient);
			if (portfourniclient != oldPortfourniclient) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ModelM1Package.INTERFACE_CLIENT__PORTFOURNICLIENT, oldPortfourniclient, portfourniclient));
			}
		}
		return portfourniclient;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PortFourniClient basicGetPortfourniclient() {
		return portfourniclient;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setPortfourniclient(PortFourniClient newPortfourniclient) {
		PortFourniClient oldPortfourniclient = portfourniclient;
		portfourniclient = newPortfourniclient;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModelM1Package.INTERFACE_CLIENT__PORTFOURNICLIENT,
					oldPortfourniclient, portfourniclient));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public PortRequisClient getPortrequisclient() {
		if (portrequisclient != null && portrequisclient.eIsProxy()) {
			InternalEObject oldPortrequisclient = (InternalEObject) portrequisclient;
			portrequisclient = (PortRequisClient) eResolveProxy(oldPortrequisclient);
			if (portrequisclient != oldPortrequisclient) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ModelM1Package.INTERFACE_CLIENT__PORTREQUISCLIENT, oldPortrequisclient, portrequisclient));
			}
		}
		return portrequisclient;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PortRequisClient basicGetPortrequisclient() {
		return portrequisclient;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setPortrequisclient(PortRequisClient newPortrequisclient) {
		PortRequisClient oldPortrequisclient = portrequisclient;
		portrequisclient = newPortrequisclient;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModelM1Package.INTERFACE_CLIENT__PORTREQUISCLIENT,
					oldPortrequisclient, portrequisclient));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ServiceFourniClient getServicefourniclient() {
		if (servicefourniclient != null && servicefourniclient.eIsProxy()) {
			InternalEObject oldServicefourniclient = (InternalEObject) servicefourniclient;
			servicefourniclient = (ServiceFourniClient) eResolveProxy(oldServicefourniclient);
			if (servicefourniclient != oldServicefourniclient) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ModelM1Package.INTERFACE_CLIENT__SERVICEFOURNICLIENT, oldServicefourniclient,
							servicefourniclient));
			}
		}
		return servicefourniclient;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ServiceFourniClient basicGetServicefourniclient() {
		return servicefourniclient;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setServicefourniclient(ServiceFourniClient newServicefourniclient) {
		ServiceFourniClient oldServicefourniclient = servicefourniclient;
		servicefourniclient = newServicefourniclient;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModelM1Package.INTERFACE_CLIENT__SERVICEFOURNICLIENT,
					oldServicefourniclient, servicefourniclient));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ModelM1Package.INTERFACE_CLIENT__ATTACHEMENTCLIENTRPC:
			if (resolve)
				return getAttachementclientrpc();
			return basicGetAttachementclientrpc();
		case ModelM1Package.INTERFACE_CLIENT__PORTFOURNICLIENT:
			if (resolve)
				return getPortfourniclient();
			return basicGetPortfourniclient();
		case ModelM1Package.INTERFACE_CLIENT__PORTREQUISCLIENT:
			if (resolve)
				return getPortrequisclient();
			return basicGetPortrequisclient();
		case ModelM1Package.INTERFACE_CLIENT__SERVICEFOURNICLIENT:
			if (resolve)
				return getServicefourniclient();
			return basicGetServicefourniclient();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ModelM1Package.INTERFACE_CLIENT__ATTACHEMENTCLIENTRPC:
			setAttachementclientrpc((AttachementClientRPC) newValue);
			return;
		case ModelM1Package.INTERFACE_CLIENT__PORTFOURNICLIENT:
			setPortfourniclient((PortFourniClient) newValue);
			return;
		case ModelM1Package.INTERFACE_CLIENT__PORTREQUISCLIENT:
			setPortrequisclient((PortRequisClient) newValue);
			return;
		case ModelM1Package.INTERFACE_CLIENT__SERVICEFOURNICLIENT:
			setServicefourniclient((ServiceFourniClient) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ModelM1Package.INTERFACE_CLIENT__ATTACHEMENTCLIENTRPC:
			setAttachementclientrpc((AttachementClientRPC) null);
			return;
		case ModelM1Package.INTERFACE_CLIENT__PORTFOURNICLIENT:
			setPortfourniclient((PortFourniClient) null);
			return;
		case ModelM1Package.INTERFACE_CLIENT__PORTREQUISCLIENT:
			setPortrequisclient((PortRequisClient) null);
			return;
		case ModelM1Package.INTERFACE_CLIENT__SERVICEFOURNICLIENT:
			setServicefourniclient((ServiceFourniClient) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ModelM1Package.INTERFACE_CLIENT__ATTACHEMENTCLIENTRPC:
			return attachementclientrpc != null;
		case ModelM1Package.INTERFACE_CLIENT__PORTFOURNICLIENT:
			return portfourniclient != null;
		case ModelM1Package.INTERFACE_CLIENT__PORTREQUISCLIENT:
			return portrequisclient != null;
		case ModelM1Package.INTERFACE_CLIENT__SERVICEFOURNICLIENT:
			return servicefourniclient != null;
		}
		return super.eIsSet(featureID);
	}

} //InterfaceClientImpl

/**
 */
package modelM1.impl;

import modelM1.ConnecteurCmDb;
import modelM1.InterfaceConnecteurCmDb;
import modelM1.ModelM1Package;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Connecteur Cm Db</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link modelM1.impl.ConnecteurCmDbImpl#getInterfaceconnecteurcmdb <em>Interfaceconnecteurcmdb</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ConnecteurCmDbImpl extends MinimalEObjectImpl.Container implements ConnecteurCmDb {
	/**
	 * The cached value of the '{@link #getInterfaceconnecteurcmdb() <em>Interfaceconnecteurcmdb</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInterfaceconnecteurcmdb()
	 * @generated
	 * @ordered
	 */
	protected InterfaceConnecteurCmDb interfaceconnecteurcmdb;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ConnecteurCmDbImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModelM1Package.Literals.CONNECTEUR_CM_DB;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public InterfaceConnecteurCmDb getInterfaceconnecteurcmdb() {
		if (interfaceconnecteurcmdb != null && interfaceconnecteurcmdb.eIsProxy()) {
			InternalEObject oldInterfaceconnecteurcmdb = (InternalEObject) interfaceconnecteurcmdb;
			interfaceconnecteurcmdb = (InterfaceConnecteurCmDb) eResolveProxy(oldInterfaceconnecteurcmdb);
			if (interfaceconnecteurcmdb != oldInterfaceconnecteurcmdb) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ModelM1Package.CONNECTEUR_CM_DB__INTERFACECONNECTEURCMDB, oldInterfaceconnecteurcmdb,
							interfaceconnecteurcmdb));
			}
		}
		return interfaceconnecteurcmdb;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public InterfaceConnecteurCmDb basicGetInterfaceconnecteurcmdb() {
		return interfaceconnecteurcmdb;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setInterfaceconnecteurcmdb(InterfaceConnecteurCmDb newInterfaceconnecteurcmdb) {
		InterfaceConnecteurCmDb oldInterfaceconnecteurcmdb = interfaceconnecteurcmdb;
		interfaceconnecteurcmdb = newInterfaceconnecteurcmdb;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					ModelM1Package.CONNECTEUR_CM_DB__INTERFACECONNECTEURCMDB, oldInterfaceconnecteurcmdb,
					interfaceconnecteurcmdb));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ModelM1Package.CONNECTEUR_CM_DB__INTERFACECONNECTEURCMDB:
			if (resolve)
				return getInterfaceconnecteurcmdb();
			return basicGetInterfaceconnecteurcmdb();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ModelM1Package.CONNECTEUR_CM_DB__INTERFACECONNECTEURCMDB:
			setInterfaceconnecteurcmdb((InterfaceConnecteurCmDb) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ModelM1Package.CONNECTEUR_CM_DB__INTERFACECONNECTEURCMDB:
			setInterfaceconnecteurcmdb((InterfaceConnecteurCmDb) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ModelM1Package.CONNECTEUR_CM_DB__INTERFACECONNECTEURCMDB:
			return interfaceconnecteurcmdb != null;
		}
		return super.eIsSet(featureID);
	}

} //ConnecteurCmDbImpl

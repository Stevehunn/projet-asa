/**
 */
package modelM1.impl;

import modelM1.ModelM1Package;
import modelM1.PortFourniClient;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Port Fourni Client</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class PortFourniClientImpl extends MinimalEObjectImpl.Container implements PortFourniClient {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PortFourniClientImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModelM1Package.Literals.PORT_FOURNI_CLIENT;
	}

} //PortFourniClientImpl

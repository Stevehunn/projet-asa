/**
 */
package modelM1.impl;

import modelM1.ModelM1Package;
import modelM1.RoleSm;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Role Sm</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class RoleSmImpl extends MinimalEObjectImpl.Container implements RoleSm {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected RoleSmImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModelM1Package.Literals.ROLE_SM;
	}

} //RoleSmImpl

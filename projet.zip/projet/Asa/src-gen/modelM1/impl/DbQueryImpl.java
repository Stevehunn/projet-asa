/**
 */
package modelM1.impl;

import modelM1.DbQuery;
import modelM1.ModelM1Package;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Db Query</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class DbQueryImpl extends MinimalEObjectImpl.Container implements DbQuery {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DbQueryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModelM1Package.Literals.DB_QUERY;
	}

} //DbQueryImpl

/**
 */
package modelM1.impl;

import modelM1.ModelM1Package;
import modelM1.SecurityAuthentification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Security Authentification</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SecurityAuthentificationImpl extends MinimalEObjectImpl.Container implements SecurityAuthentification {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SecurityAuthentificationImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModelM1Package.Literals.SECURITY_AUTHENTIFICATION;
	}

} //SecurityAuthentificationImpl

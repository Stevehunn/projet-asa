/**
 */
package modelM1.impl;

import modelM1.ModelM1Package;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Security Manager</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SecurityManagerImpl extends MinimalEObjectImpl.Container implements modelM1.SecurityManager {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SecurityManagerImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModelM1Package.Literals.SECURITY_MANAGER;
	}

} //SecurityManagerImpl

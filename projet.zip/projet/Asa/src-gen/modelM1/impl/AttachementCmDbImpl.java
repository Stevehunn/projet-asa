/**
 */
package modelM1.impl;

import modelM1.AttachementCmDb;
import modelM1.DbQuery;
import modelM1.ModelM1Package;
import modelM1.RoleDb;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Attachement Cm Db</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link modelM1.impl.AttachementCmDbImpl#getRoledb <em>Roledb</em>}</li>
 *   <li>{@link modelM1.impl.AttachementCmDbImpl#getDbquery <em>Dbquery</em>}</li>
 * </ul>
 *
 * @generated
 */
public class AttachementCmDbImpl extends MinimalEObjectImpl.Container implements AttachementCmDb {
	/**
	 * The cached value of the '{@link #getRoledb() <em>Roledb</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRoledb()
	 * @generated
	 * @ordered
	 */
	protected RoleDb roledb;

	/**
	 * The cached value of the '{@link #getDbquery() <em>Dbquery</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDbquery()
	 * @generated
	 * @ordered
	 */
	protected DbQuery dbquery;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AttachementCmDbImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModelM1Package.Literals.ATTACHEMENT_CM_DB;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public RoleDb getRoledb() {
		if (roledb != null && roledb.eIsProxy()) {
			InternalEObject oldRoledb = (InternalEObject) roledb;
			roledb = (RoleDb) eResolveProxy(oldRoledb);
			if (roledb != oldRoledb) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, ModelM1Package.ATTACHEMENT_CM_DB__ROLEDB,
							oldRoledb, roledb));
			}
		}
		return roledb;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RoleDb basicGetRoledb() {
		return roledb;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setRoledb(RoleDb newRoledb) {
		RoleDb oldRoledb = roledb;
		roledb = newRoledb;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModelM1Package.ATTACHEMENT_CM_DB__ROLEDB, oldRoledb,
					roledb));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public DbQuery getDbquery() {
		if (dbquery != null && dbquery.eIsProxy()) {
			InternalEObject oldDbquery = (InternalEObject) dbquery;
			dbquery = (DbQuery) eResolveProxy(oldDbquery);
			if (dbquery != oldDbquery) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, ModelM1Package.ATTACHEMENT_CM_DB__DBQUERY,
							oldDbquery, dbquery));
			}
		}
		return dbquery;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DbQuery basicGetDbquery() {
		return dbquery;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setDbquery(DbQuery newDbquery) {
		DbQuery oldDbquery = dbquery;
		dbquery = newDbquery;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModelM1Package.ATTACHEMENT_CM_DB__DBQUERY, oldDbquery,
					dbquery));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ModelM1Package.ATTACHEMENT_CM_DB__ROLEDB:
			if (resolve)
				return getRoledb();
			return basicGetRoledb();
		case ModelM1Package.ATTACHEMENT_CM_DB__DBQUERY:
			if (resolve)
				return getDbquery();
			return basicGetDbquery();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ModelM1Package.ATTACHEMENT_CM_DB__ROLEDB:
			setRoledb((RoleDb) newValue);
			return;
		case ModelM1Package.ATTACHEMENT_CM_DB__DBQUERY:
			setDbquery((DbQuery) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ModelM1Package.ATTACHEMENT_CM_DB__ROLEDB:
			setRoledb((RoleDb) null);
			return;
		case ModelM1Package.ATTACHEMENT_CM_DB__DBQUERY:
			setDbquery((DbQuery) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ModelM1Package.ATTACHEMENT_CM_DB__ROLEDB:
			return roledb != null;
		case ModelM1Package.ATTACHEMENT_CM_DB__DBQUERY:
			return dbquery != null;
		}
		return super.eIsSet(featureID);
	}

} //AttachementCmDbImpl

/**
 */
package modelM1.impl;

import modelM1.ModelM1Package;
import modelM1.RoleDb;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Role Db</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class RoleDbImpl extends MinimalEObjectImpl.Container implements RoleDb {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected RoleDbImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModelM1Package.Literals.ROLE_DB;
	}

} //RoleDbImpl

/**
 */
package modelM1.impl;

import modelM1.AttachementCmSm;
import modelM1.ModelM1Package;
import modelM1.RoleSm;
import modelM1.SecurityCheck;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Attachement Cm Sm</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link modelM1.impl.AttachementCmSmImpl#getRolesm <em>Rolesm</em>}</li>
 *   <li>{@link modelM1.impl.AttachementCmSmImpl#getSecuritycheck <em>Securitycheck</em>}</li>
 * </ul>
 *
 * @generated
 */
public class AttachementCmSmImpl extends MinimalEObjectImpl.Container implements AttachementCmSm {
	/**
	 * The cached value of the '{@link #getRolesm() <em>Rolesm</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRolesm()
	 * @generated
	 * @ordered
	 */
	protected RoleSm rolesm;

	/**
	 * The cached value of the '{@link #getSecuritycheck() <em>Securitycheck</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSecuritycheck()
	 * @generated
	 * @ordered
	 */
	protected SecurityCheck securitycheck;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AttachementCmSmImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModelM1Package.Literals.ATTACHEMENT_CM_SM;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public RoleSm getRolesm() {
		if (rolesm != null && rolesm.eIsProxy()) {
			InternalEObject oldRolesm = (InternalEObject) rolesm;
			rolesm = (RoleSm) eResolveProxy(oldRolesm);
			if (rolesm != oldRolesm) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, ModelM1Package.ATTACHEMENT_CM_SM__ROLESM,
							oldRolesm, rolesm));
			}
		}
		return rolesm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RoleSm basicGetRolesm() {
		return rolesm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setRolesm(RoleSm newRolesm) {
		RoleSm oldRolesm = rolesm;
		rolesm = newRolesm;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModelM1Package.ATTACHEMENT_CM_SM__ROLESM, oldRolesm,
					rolesm));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SecurityCheck getSecuritycheck() {
		if (securitycheck != null && securitycheck.eIsProxy()) {
			InternalEObject oldSecuritycheck = (InternalEObject) securitycheck;
			securitycheck = (SecurityCheck) eResolveProxy(oldSecuritycheck);
			if (securitycheck != oldSecuritycheck) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ModelM1Package.ATTACHEMENT_CM_SM__SECURITYCHECK, oldSecuritycheck, securitycheck));
			}
		}
		return securitycheck;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SecurityCheck basicGetSecuritycheck() {
		return securitycheck;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setSecuritycheck(SecurityCheck newSecuritycheck) {
		SecurityCheck oldSecuritycheck = securitycheck;
		securitycheck = newSecuritycheck;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModelM1Package.ATTACHEMENT_CM_SM__SECURITYCHECK,
					oldSecuritycheck, securitycheck));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ModelM1Package.ATTACHEMENT_CM_SM__ROLESM:
			if (resolve)
				return getRolesm();
			return basicGetRolesm();
		case ModelM1Package.ATTACHEMENT_CM_SM__SECURITYCHECK:
			if (resolve)
				return getSecuritycheck();
			return basicGetSecuritycheck();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ModelM1Package.ATTACHEMENT_CM_SM__ROLESM:
			setRolesm((RoleSm) newValue);
			return;
		case ModelM1Package.ATTACHEMENT_CM_SM__SECURITYCHECK:
			setSecuritycheck((SecurityCheck) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ModelM1Package.ATTACHEMENT_CM_SM__ROLESM:
			setRolesm((RoleSm) null);
			return;
		case ModelM1Package.ATTACHEMENT_CM_SM__SECURITYCHECK:
			setSecuritycheck((SecurityCheck) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ModelM1Package.ATTACHEMENT_CM_SM__ROLESM:
			return rolesm != null;
		case ModelM1Package.ATTACHEMENT_CM_SM__SECURITYCHECK:
			return securitycheck != null;
		}
		return super.eIsSet(featureID);
	}

} //AttachementCmSmImpl

/**
 */
package modelM1.impl;

import modelM1.ConnecteurDbSm;
import modelM1.InterfaceConnecteurDbSm;
import modelM1.ModelM1Package;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Connecteur Db Sm</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link modelM1.impl.ConnecteurDbSmImpl#getInterfaceconnecteurdbsm <em>Interfaceconnecteurdbsm</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ConnecteurDbSmImpl extends MinimalEObjectImpl.Container implements ConnecteurDbSm {
	/**
	 * The cached value of the '{@link #getInterfaceconnecteurdbsm() <em>Interfaceconnecteurdbsm</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInterfaceconnecteurdbsm()
	 * @generated
	 * @ordered
	 */
	protected InterfaceConnecteurDbSm interfaceconnecteurdbsm;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ConnecteurDbSmImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModelM1Package.Literals.CONNECTEUR_DB_SM;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public InterfaceConnecteurDbSm getInterfaceconnecteurdbsm() {
		if (interfaceconnecteurdbsm != null && interfaceconnecteurdbsm.eIsProxy()) {
			InternalEObject oldInterfaceconnecteurdbsm = (InternalEObject) interfaceconnecteurdbsm;
			interfaceconnecteurdbsm = (InterfaceConnecteurDbSm) eResolveProxy(oldInterfaceconnecteurdbsm);
			if (interfaceconnecteurdbsm != oldInterfaceconnecteurdbsm) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ModelM1Package.CONNECTEUR_DB_SM__INTERFACECONNECTEURDBSM, oldInterfaceconnecteurdbsm,
							interfaceconnecteurdbsm));
			}
		}
		return interfaceconnecteurdbsm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public InterfaceConnecteurDbSm basicGetInterfaceconnecteurdbsm() {
		return interfaceconnecteurdbsm;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setInterfaceconnecteurdbsm(InterfaceConnecteurDbSm newInterfaceconnecteurdbsm) {
		InterfaceConnecteurDbSm oldInterfaceconnecteurdbsm = interfaceconnecteurdbsm;
		interfaceconnecteurdbsm = newInterfaceconnecteurdbsm;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					ModelM1Package.CONNECTEUR_DB_SM__INTERFACECONNECTEURDBSM, oldInterfaceconnecteurdbsm,
					interfaceconnecteurdbsm));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ModelM1Package.CONNECTEUR_DB_SM__INTERFACECONNECTEURDBSM:
			if (resolve)
				return getInterfaceconnecteurdbsm();
			return basicGetInterfaceconnecteurdbsm();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ModelM1Package.CONNECTEUR_DB_SM__INTERFACECONNECTEURDBSM:
			setInterfaceconnecteurdbsm((InterfaceConnecteurDbSm) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ModelM1Package.CONNECTEUR_DB_SM__INTERFACECONNECTEURDBSM:
			setInterfaceconnecteurdbsm((InterfaceConnecteurDbSm) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ModelM1Package.CONNECTEUR_DB_SM__INTERFACECONNECTEURDBSM:
			return interfaceconnecteurdbsm != null;
		}
		return super.eIsSet(featureID);
	}

} //ConnecteurDbSmImpl

/**
 */
package modelM1;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Attachement Cm Db</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link modelM1.AttachementCmDb#getRoledb <em>Roledb</em>}</li>
 *   <li>{@link modelM1.AttachementCmDb#getDbquery <em>Dbquery</em>}</li>
 * </ul>
 *
 * @see modelM1.ModelM1Package#getAttachementCmDb()
 * @model
 * @generated
 */
public interface AttachementCmDb extends EObject {
	/**
	 * Returns the value of the '<em><b>Roledb</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Roledb</em>' reference.
	 * @see #setRoledb(RoleDb)
	 * @see modelM1.ModelM1Package#getAttachementCmDb_Roledb()
	 * @model
	 * @generated
	 */
	RoleDb getRoledb();

	/**
	 * Sets the value of the '{@link modelM1.AttachementCmDb#getRoledb <em>Roledb</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Roledb</em>' reference.
	 * @see #getRoledb()
	 * @generated
	 */
	void setRoledb(RoleDb value);

	/**
	 * Returns the value of the '<em><b>Dbquery</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Dbquery</em>' reference.
	 * @see #setDbquery(DbQuery)
	 * @see modelM1.ModelM1Package#getAttachementCmDb_Dbquery()
	 * @model
	 * @generated
	 */
	DbQuery getDbquery();

	/**
	 * Sets the value of the '{@link modelM1.AttachementCmDb#getDbquery <em>Dbquery</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Dbquery</em>' reference.
	 * @see #getDbquery()
	 * @generated
	 */
	void setDbquery(DbQuery value);

} // AttachementCmDb

/**
 */
package modelM1;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Configuration Serveur</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link modelM1.ConfigurationServeur#getInterfaceconfigurationserveur <em>Interfaceconfigurationserveur</em>}</li>
 *   <li>{@link modelM1.ConfigurationServeur#getSecuritymanager <em>Securitymanager</em>}</li>
 *   <li>{@link modelM1.ConfigurationServeur#getConnecteurcmdb <em>Connecteurcmdb</em>}</li>
 *   <li>{@link modelM1.ConfigurationServeur#getConnectionmanager <em>Connectionmanager</em>}</li>
 *   <li>{@link modelM1.ConfigurationServeur#getAttachementcmdb <em>Attachementcmdb</em>}</li>
 *   <li>{@link modelM1.ConfigurationServeur#getAttachementsmdb <em>Attachementsmdb</em>}</li>
 *   <li>{@link modelM1.ConfigurationServeur#getSecuritymanagement <em>Securitymanagement</em>}</li>
 *   <li>{@link modelM1.ConfigurationServeur#getAttachementcmsm <em>Attachementcmsm</em>}</li>
 *   <li>{@link modelM1.ConfigurationServeur#getConnecteurdbsm <em>Connecteurdbsm</em>}</li>
 *   <li>{@link modelM1.ConfigurationServeur#getAttachementsmcm <em>Attachementsmcm</em>}</li>
 *   <li>{@link modelM1.ConfigurationServeur#getDatabase <em>Database</em>}</li>
 *   <li>{@link modelM1.ConfigurationServeur#getAttachementdbcm <em>Attachementdbcm</em>}</li>
 *   <li>{@link modelM1.ConfigurationServeur#getAttachementdbsm <em>Attachementdbsm</em>}</li>
 *   <li>{@link modelM1.ConfigurationServeur#getConnecteurcmsm <em>Connecteurcmsm</em>}</li>
 * </ul>
 *
 * @see modelM1.ModelM1Package#getConfigurationServeur()
 * @model
 * @generated
 */
public interface ConfigurationServeur extends EObject {
	/**
	 * Returns the value of the '<em><b>Interfaceconfigurationserveur</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Interfaceconfigurationserveur</em>' reference.
	 * @see #setInterfaceconfigurationserveur(InterfaceConfigurationServeur)
	 * @see modelM1.ModelM1Package#getConfigurationServeur_Interfaceconfigurationserveur()
	 * @model
	 * @generated
	 */
	InterfaceConfigurationServeur getInterfaceconfigurationserveur();

	/**
	 * Sets the value of the '{@link modelM1.ConfigurationServeur#getInterfaceconfigurationserveur <em>Interfaceconfigurationserveur</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Interfaceconfigurationserveur</em>' reference.
	 * @see #getInterfaceconfigurationserveur()
	 * @generated
	 */
	void setInterfaceconfigurationserveur(InterfaceConfigurationServeur value);

	/**
	 * Returns the value of the '<em><b>Securitymanager</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Securitymanager</em>' reference.
	 * @see #setSecuritymanager(modelM1.SecurityManager)
	 * @see modelM1.ModelM1Package#getConfigurationServeur_Securitymanager()
	 * @model
	 * @generated
	 */
	modelM1.SecurityManager getSecuritymanager();

	/**
	 * Sets the value of the '{@link modelM1.ConfigurationServeur#getSecuritymanager <em>Securitymanager</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Securitymanager</em>' reference.
	 * @see #getSecuritymanager()
	 * @generated
	 */
	void setSecuritymanager(modelM1.SecurityManager value);

	/**
	 * Returns the value of the '<em><b>Connecteurcmdb</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Connecteurcmdb</em>' reference.
	 * @see #setConnecteurcmdb(ConnecteurCmDb)
	 * @see modelM1.ModelM1Package#getConfigurationServeur_Connecteurcmdb()
	 * @model
	 * @generated
	 */
	ConnecteurCmDb getConnecteurcmdb();

	/**
	 * Sets the value of the '{@link modelM1.ConfigurationServeur#getConnecteurcmdb <em>Connecteurcmdb</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Connecteurcmdb</em>' reference.
	 * @see #getConnecteurcmdb()
	 * @generated
	 */
	void setConnecteurcmdb(ConnecteurCmDb value);

	/**
	 * Returns the value of the '<em><b>Connectionmanager</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Connectionmanager</em>' reference.
	 * @see #setConnectionmanager(ConnectionManager)
	 * @see modelM1.ModelM1Package#getConfigurationServeur_Connectionmanager()
	 * @model
	 * @generated
	 */
	ConnectionManager getConnectionmanager();

	/**
	 * Sets the value of the '{@link modelM1.ConfigurationServeur#getConnectionmanager <em>Connectionmanager</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Connectionmanager</em>' reference.
	 * @see #getConnectionmanager()
	 * @generated
	 */
	void setConnectionmanager(ConnectionManager value);

	/**
	 * Returns the value of the '<em><b>Attachementcmdb</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Attachementcmdb</em>' reference.
	 * @see #setAttachementcmdb(AttachementCmDb)
	 * @see modelM1.ModelM1Package#getConfigurationServeur_Attachementcmdb()
	 * @model
	 * @generated
	 */
	AttachementCmDb getAttachementcmdb();

	/**
	 * Sets the value of the '{@link modelM1.ConfigurationServeur#getAttachementcmdb <em>Attachementcmdb</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Attachementcmdb</em>' reference.
	 * @see #getAttachementcmdb()
	 * @generated
	 */
	void setAttachementcmdb(AttachementCmDb value);

	/**
	 * Returns the value of the '<em><b>Attachementsmdb</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Attachementsmdb</em>' reference.
	 * @see #setAttachementsmdb(AttachementSmDb)
	 * @see modelM1.ModelM1Package#getConfigurationServeur_Attachementsmdb()
	 * @model
	 * @generated
	 */
	AttachementSmDb getAttachementsmdb();

	/**
	 * Sets the value of the '{@link modelM1.ConfigurationServeur#getAttachementsmdb <em>Attachementsmdb</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Attachementsmdb</em>' reference.
	 * @see #getAttachementsmdb()
	 * @generated
	 */
	void setAttachementsmdb(AttachementSmDb value);

	/**
	 * Returns the value of the '<em><b>Securitymanagement</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Securitymanagement</em>' reference.
	 * @see #setSecuritymanagement(SecurityManagement)
	 * @see modelM1.ModelM1Package#getConfigurationServeur_Securitymanagement()
	 * @model
	 * @generated
	 */
	SecurityManagement getSecuritymanagement();

	/**
	 * Sets the value of the '{@link modelM1.ConfigurationServeur#getSecuritymanagement <em>Securitymanagement</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Securitymanagement</em>' reference.
	 * @see #getSecuritymanagement()
	 * @generated
	 */
	void setSecuritymanagement(SecurityManagement value);

	/**
	 * Returns the value of the '<em><b>Attachementcmsm</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Attachementcmsm</em>' reference.
	 * @see #setAttachementcmsm(AttachementCmSm)
	 * @see modelM1.ModelM1Package#getConfigurationServeur_Attachementcmsm()
	 * @model
	 * @generated
	 */
	AttachementCmSm getAttachementcmsm();

	/**
	 * Sets the value of the '{@link modelM1.ConfigurationServeur#getAttachementcmsm <em>Attachementcmsm</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Attachementcmsm</em>' reference.
	 * @see #getAttachementcmsm()
	 * @generated
	 */
	void setAttachementcmsm(AttachementCmSm value);

	/**
	 * Returns the value of the '<em><b>Connecteurdbsm</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Connecteurdbsm</em>' reference.
	 * @see #setConnecteurdbsm(ConnecteurDbSm)
	 * @see modelM1.ModelM1Package#getConfigurationServeur_Connecteurdbsm()
	 * @model
	 * @generated
	 */
	ConnecteurDbSm getConnecteurdbsm();

	/**
	 * Sets the value of the '{@link modelM1.ConfigurationServeur#getConnecteurdbsm <em>Connecteurdbsm</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Connecteurdbsm</em>' reference.
	 * @see #getConnecteurdbsm()
	 * @generated
	 */
	void setConnecteurdbsm(ConnecteurDbSm value);

	/**
	 * Returns the value of the '<em><b>Attachementsmcm</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Attachementsmcm</em>' reference.
	 * @see #setAttachementsmcm(AttachementSmCm)
	 * @see modelM1.ModelM1Package#getConfigurationServeur_Attachementsmcm()
	 * @model
	 * @generated
	 */
	AttachementSmCm getAttachementsmcm();

	/**
	 * Sets the value of the '{@link modelM1.ConfigurationServeur#getAttachementsmcm <em>Attachementsmcm</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Attachementsmcm</em>' reference.
	 * @see #getAttachementsmcm()
	 * @generated
	 */
	void setAttachementsmcm(AttachementSmCm value);

	/**
	 * Returns the value of the '<em><b>Database</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Database</em>' reference.
	 * @see #setDatabase(Database)
	 * @see modelM1.ModelM1Package#getConfigurationServeur_Database()
	 * @model
	 * @generated
	 */
	Database getDatabase();

	/**
	 * Sets the value of the '{@link modelM1.ConfigurationServeur#getDatabase <em>Database</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Database</em>' reference.
	 * @see #getDatabase()
	 * @generated
	 */
	void setDatabase(Database value);

	/**
	 * Returns the value of the '<em><b>Attachementdbcm</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Attachementdbcm</em>' reference.
	 * @see #setAttachementdbcm(AttachementDbCm)
	 * @see modelM1.ModelM1Package#getConfigurationServeur_Attachementdbcm()
	 * @model
	 * @generated
	 */
	AttachementDbCm getAttachementdbcm();

	/**
	 * Sets the value of the '{@link modelM1.ConfigurationServeur#getAttachementdbcm <em>Attachementdbcm</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Attachementdbcm</em>' reference.
	 * @see #getAttachementdbcm()
	 * @generated
	 */
	void setAttachementdbcm(AttachementDbCm value);

	/**
	 * Returns the value of the '<em><b>Attachementdbsm</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Attachementdbsm</em>' reference.
	 * @see #setAttachementdbsm(AttachementDbSm)
	 * @see modelM1.ModelM1Package#getConfigurationServeur_Attachementdbsm()
	 * @model
	 * @generated
	 */
	AttachementDbSm getAttachementdbsm();

	/**
	 * Sets the value of the '{@link modelM1.ConfigurationServeur#getAttachementdbsm <em>Attachementdbsm</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Attachementdbsm</em>' reference.
	 * @see #getAttachementdbsm()
	 * @generated
	 */
	void setAttachementdbsm(AttachementDbSm value);

	/**
	 * Returns the value of the '<em><b>Connecteurcmsm</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Connecteurcmsm</em>' reference.
	 * @see #setConnecteurcmsm(ConnecteurCmSm)
	 * @see modelM1.ModelM1Package#getConfigurationServeur_Connecteurcmsm()
	 * @model
	 * @generated
	 */
	ConnecteurCmSm getConnecteurcmsm();

	/**
	 * Sets the value of the '{@link modelM1.ConfigurationServeur#getConnecteurcmsm <em>Connecteurcmsm</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Connecteurcmsm</em>' reference.
	 * @see #getConnecteurcmsm()
	 * @generated
	 */
	void setConnecteurcmsm(ConnecteurCmSm value);

} // ConfigurationServeur

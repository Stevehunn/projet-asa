/**
 */
package modelM1;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Security Authentification</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see modelM1.ModelM1Package#getSecurityAuthentification()
 * @model
 * @generated
 */
public interface SecurityAuthentification extends EObject {
} // SecurityAuthentification

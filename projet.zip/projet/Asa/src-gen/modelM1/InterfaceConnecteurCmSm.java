/**
 */
package modelM1;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Interface Connecteur Cm Sm</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link modelM1.InterfaceConnecteurCmSm#getRolecm <em>Rolecm</em>}</li>
 *   <li>{@link modelM1.InterfaceConnecteurCmSm#getRolesm <em>Rolesm</em>}</li>
 * </ul>
 *
 * @see modelM1.ModelM1Package#getInterfaceConnecteurCmSm()
 * @model
 * @generated
 */
public interface InterfaceConnecteurCmSm extends EObject {
	/**
	 * Returns the value of the '<em><b>Rolecm</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Rolecm</em>' reference.
	 * @see #setRolecm(RoleCm)
	 * @see modelM1.ModelM1Package#getInterfaceConnecteurCmSm_Rolecm()
	 * @model
	 * @generated
	 */
	RoleCm getRolecm();

	/**
	 * Sets the value of the '{@link modelM1.InterfaceConnecteurCmSm#getRolecm <em>Rolecm</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Rolecm</em>' reference.
	 * @see #getRolecm()
	 * @generated
	 */
	void setRolecm(RoleCm value);

	/**
	 * Returns the value of the '<em><b>Rolesm</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Rolesm</em>' reference.
	 * @see #setRolesm(RoleSm)
	 * @see modelM1.ModelM1Package#getInterfaceConnecteurCmSm_Rolesm()
	 * @model
	 * @generated
	 */
	RoleSm getRolesm();

	/**
	 * Sets the value of the '{@link modelM1.InterfaceConnecteurCmSm#getRolesm <em>Rolesm</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Rolesm</em>' reference.
	 * @see #getRolesm()
	 * @generated
	 */
	void setRolesm(RoleSm value);

} // InterfaceConnecteurCmSm

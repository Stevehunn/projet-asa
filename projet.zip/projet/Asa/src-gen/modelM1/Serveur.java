/**
 */
package modelM1;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Serveur</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link modelM1.Serveur#getConfigurationserveur <em>Configurationserveur</em>}</li>
 * </ul>
 *
 * @see modelM1.ModelM1Package#getServeur()
 * @model
 * @generated
 */
public interface Serveur extends EObject {
	/**
	 * Returns the value of the '<em><b>Configurationserveur</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Configurationserveur</em>' reference.
	 * @see #setConfigurationserveur(ConfigurationServeur)
	 * @see modelM1.ModelM1Package#getServeur_Configurationserveur()
	 * @model
	 * @generated
	 */
	ConfigurationServeur getConfigurationserveur();

	/**
	 * Sets the value of the '{@link modelM1.Serveur#getConfigurationserveur <em>Configurationserveur</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Configurationserveur</em>' reference.
	 * @see #getConfigurationserveur()
	 * @generated
	 */
	void setConfigurationserveur(ConfigurationServeur value);

} // Serveur

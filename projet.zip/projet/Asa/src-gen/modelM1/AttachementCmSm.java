/**
 */
package modelM1;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Attachement Cm Sm</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link modelM1.AttachementCmSm#getRolesm <em>Rolesm</em>}</li>
 *   <li>{@link modelM1.AttachementCmSm#getSecuritycheck <em>Securitycheck</em>}</li>
 * </ul>
 *
 * @see modelM1.ModelM1Package#getAttachementCmSm()
 * @model
 * @generated
 */
public interface AttachementCmSm extends EObject {
	/**
	 * Returns the value of the '<em><b>Rolesm</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Rolesm</em>' reference.
	 * @see #setRolesm(RoleSm)
	 * @see modelM1.ModelM1Package#getAttachementCmSm_Rolesm()
	 * @model
	 * @generated
	 */
	RoleSm getRolesm();

	/**
	 * Sets the value of the '{@link modelM1.AttachementCmSm#getRolesm <em>Rolesm</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Rolesm</em>' reference.
	 * @see #getRolesm()
	 * @generated
	 */
	void setRolesm(RoleSm value);

	/**
	 * Returns the value of the '<em><b>Securitycheck</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Securitycheck</em>' reference.
	 * @see #setSecuritycheck(SecurityCheck)
	 * @see modelM1.ModelM1Package#getAttachementCmSm_Securitycheck()
	 * @model
	 * @generated
	 */
	SecurityCheck getSecuritycheck();

	/**
	 * Sets the value of the '{@link modelM1.AttachementCmSm#getSecuritycheck <em>Securitycheck</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Securitycheck</em>' reference.
	 * @see #getSecuritycheck()
	 * @generated
	 */
	void setSecuritycheck(SecurityCheck value);

} // AttachementCmSm

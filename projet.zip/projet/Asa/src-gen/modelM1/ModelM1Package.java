/**
 */
package modelM1;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see modelM1.ModelM1Factory
 * @model kind="package"
 * @generated
 */
public interface ModelM1Package extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "modelM1";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.example.org/modelM1";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "modelM1";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	ModelM1Package eINSTANCE = modelM1.impl.ModelM1PackageImpl.init();

	/**
	 * The meta object id for the '{@link modelM1.impl.SecurityAuthentificationImpl <em>Security Authentification</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modelM1.impl.SecurityAuthentificationImpl
	 * @see modelM1.impl.ModelM1PackageImpl#getSecurityAuthentification()
	 * @generated
	 */
	int SECURITY_AUTHENTIFICATION = 0;

	/**
	 * The number of structural features of the '<em>Security Authentification</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SECURITY_AUTHENTIFICATION_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Security Authentification</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SECURITY_AUTHENTIFICATION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modelM1.impl.InterfaceConnecteurCmSmImpl <em>Interface Connecteur Cm Sm</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modelM1.impl.InterfaceConnecteurCmSmImpl
	 * @see modelM1.impl.ModelM1PackageImpl#getInterfaceConnecteurCmSm()
	 * @generated
	 */
	int INTERFACE_CONNECTEUR_CM_SM = 1;

	/**
	 * The feature id for the '<em><b>Rolecm</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERFACE_CONNECTEUR_CM_SM__ROLECM = 0;

	/**
	 * The feature id for the '<em><b>Rolesm</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERFACE_CONNECTEUR_CM_SM__ROLESM = 1;

	/**
	 * The number of structural features of the '<em>Interface Connecteur Cm Sm</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERFACE_CONNECTEUR_CM_SM_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Interface Connecteur Cm Sm</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERFACE_CONNECTEUR_CM_SM_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modelM1.impl.DbQueryImpl <em>Db Query</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modelM1.impl.DbQueryImpl
	 * @see modelM1.impl.ModelM1PackageImpl#getDbQuery()
	 * @generated
	 */
	int DB_QUERY = 2;

	/**
	 * The number of structural features of the '<em>Db Query</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DB_QUERY_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Db Query</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DB_QUERY_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modelM1.impl.InterfaceConnecteurDbSmImpl <em>Interface Connecteur Db Sm</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modelM1.impl.InterfaceConnecteurDbSmImpl
	 * @see modelM1.impl.ModelM1PackageImpl#getInterfaceConnecteurDbSm()
	 * @generated
	 */
	int INTERFACE_CONNECTEUR_DB_SM = 3;

	/**
	 * The feature id for the '<em><b>Rolesm</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERFACE_CONNECTEUR_DB_SM__ROLESM = 0;

	/**
	 * The feature id for the '<em><b>Roledb</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERFACE_CONNECTEUR_DB_SM__ROLEDB = 1;

	/**
	 * The number of structural features of the '<em>Interface Connecteur Db Sm</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERFACE_CONNECTEUR_DB_SM_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Interface Connecteur Db Sm</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERFACE_CONNECTEUR_DB_SM_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modelM1.impl.AttachementSmDbImpl <em>Attachement Sm Db</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modelM1.impl.AttachementSmDbImpl
	 * @see modelM1.impl.ModelM1PackageImpl#getAttachementSmDb()
	 * @generated
	 */
	int ATTACHEMENT_SM_DB = 4;

	/**
	 * The feature id for the '<em><b>Checkquery</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTACHEMENT_SM_DB__CHECKQUERY = 0;

	/**
	 * The feature id for the '<em><b>Roledb</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTACHEMENT_SM_DB__ROLEDB = 1;

	/**
	 * The number of structural features of the '<em>Attachement Sm Db</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTACHEMENT_SM_DB_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Attachement Sm Db</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTACHEMENT_SM_DB_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modelM1.impl.PortFourniConfigurationServeurImpl <em>Port Fourni Configuration Serveur</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modelM1.impl.PortFourniConfigurationServeurImpl
	 * @see modelM1.impl.ModelM1PackageImpl#getPortFourniConfigurationServeur()
	 * @generated
	 */
	int PORT_FOURNI_CONFIGURATION_SERVEUR = 5;

	/**
	 * The number of structural features of the '<em>Port Fourni Configuration Serveur</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORT_FOURNI_CONFIGURATION_SERVEUR_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Port Fourni Configuration Serveur</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORT_FOURNI_CONFIGURATION_SERVEUR_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modelM1.impl.ServiceFourniClientImpl <em>Service Fourni Client</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modelM1.impl.ServiceFourniClientImpl
	 * @see modelM1.impl.ModelM1PackageImpl#getServiceFourniClient()
	 * @generated
	 */
	int SERVICE_FOURNI_CLIENT = 6;

	/**
	 * The number of structural features of the '<em>Service Fourni Client</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVICE_FOURNI_CLIENT_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Service Fourni Client</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVICE_FOURNI_CLIENT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modelM1.impl.InterfaceSecurityManagerImpl <em>Interface Security Manager</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modelM1.impl.InterfaceSecurityManagerImpl
	 * @see modelM1.impl.ModelM1PackageImpl#getInterfaceSecurityManager()
	 * @generated
	 */
	int INTERFACE_SECURITY_MANAGER = 7;

	/**
	 * The feature id for the '<em><b>Checkquery</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERFACE_SECURITY_MANAGER__CHECKQUERY = 0;

	/**
	 * The feature id for the '<em><b>Securityauthentification</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERFACE_SECURITY_MANAGER__SECURITYAUTHENTIFICATION = 1;

	/**
	 * The number of structural features of the '<em>Interface Security Manager</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERFACE_SECURITY_MANAGER_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Interface Security Manager</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERFACE_SECURITY_MANAGER_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modelM1.impl.BindingExternalSocketImpl <em>Binding External Socket</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modelM1.impl.BindingExternalSocketImpl
	 * @see modelM1.impl.ModelM1PackageImpl#getBindingExternalSocket()
	 * @generated
	 */
	int BINDING_EXTERNAL_SOCKET = 8;

	/**
	 * The feature id for the '<em><b>Externalsocket</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BINDING_EXTERNAL_SOCKET__EXTERNALSOCKET = 0;

	/**
	 * The feature id for the '<em><b>Portfourniconfigurationserveur</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BINDING_EXTERNAL_SOCKET__PORTFOURNICONFIGURATIONSERVEUR = 1;

	/**
	 * The number of structural features of the '<em>Binding External Socket</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BINDING_EXTERNAL_SOCKET_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Binding External Socket</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BINDING_EXTERNAL_SOCKET_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modelM1.impl.RoleDbImpl <em>Role Db</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modelM1.impl.RoleDbImpl
	 * @see modelM1.impl.ModelM1PackageImpl#getRoleDb()
	 * @generated
	 */
	int ROLE_DB = 9;

	/**
	 * The number of structural features of the '<em>Role Db</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE_DB_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Role Db</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE_DB_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modelM1.impl.CheckQueryImpl <em>Check Query</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modelM1.impl.CheckQueryImpl
	 * @see modelM1.impl.ModelM1PackageImpl#getCheckQuery()
	 * @generated
	 */
	int CHECK_QUERY = 10;

	/**
	 * The number of structural features of the '<em>Check Query</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHECK_QUERY_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Check Query</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHECK_QUERY_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modelM1.impl.AttachementRPCServeurImpl <em>Attachement RPC Serveur</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modelM1.impl.AttachementRPCServeurImpl
	 * @see modelM1.impl.ModelM1PackageImpl#getAttachementRPCServeur()
	 * @generated
	 */
	int ATTACHEMENT_RPC_SERVEUR = 11;

	/**
	 * The feature id for the '<em><b>Interfaceconnecteurrpc</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTACHEMENT_RPC_SERVEUR__INTERFACECONNECTEURRPC = 0;

	/**
	 * The feature id for the '<em><b>Interfaceconfigurationserveur</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTACHEMENT_RPC_SERVEUR__INTERFACECONFIGURATIONSERVEUR = 1;

	/**
	 * The number of structural features of the '<em>Attachement RPC Serveur</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTACHEMENT_RPC_SERVEUR_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Attachement RPC Serveur</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTACHEMENT_RPC_SERVEUR_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modelM1.impl.AttachementClientRPCImpl <em>Attachement Client RPC</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modelM1.impl.AttachementClientRPCImpl
	 * @see modelM1.impl.ModelM1PackageImpl#getAttachementClientRPC()
	 * @generated
	 */
	int ATTACHEMENT_CLIENT_RPC = 12;

	/**
	 * The feature id for the '<em><b>Interfaceconnecteurrpc</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTACHEMENT_CLIENT_RPC__INTERFACECONNECTEURRPC = 0;

	/**
	 * The number of structural features of the '<em>Attachement Client RPC</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTACHEMENT_CLIENT_RPC_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Attachement Client RPC</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTACHEMENT_CLIENT_RPC_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modelM1.impl.SecurityManagementImpl <em>Security Management</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modelM1.impl.SecurityManagementImpl
	 * @see modelM1.impl.ModelM1PackageImpl#getSecurityManagement()
	 * @generated
	 */
	int SECURITY_MANAGEMENT = 13;

	/**
	 * The number of structural features of the '<em>Security Management</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SECURITY_MANAGEMENT_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Security Management</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SECURITY_MANAGEMENT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modelM1.impl.PortFourniClientImpl <em>Port Fourni Client</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modelM1.impl.PortFourniClientImpl
	 * @see modelM1.impl.ModelM1PackageImpl#getPortFourniClient()
	 * @generated
	 */
	int PORT_FOURNI_CLIENT = 14;

	/**
	 * The number of structural features of the '<em>Port Fourni Client</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORT_FOURNI_CLIENT_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Port Fourni Client</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORT_FOURNI_CLIENT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modelM1.impl.PortRequisClientImpl <em>Port Requis Client</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modelM1.impl.PortRequisClientImpl
	 * @see modelM1.impl.ModelM1PackageImpl#getPortRequisClient()
	 * @generated
	 */
	int PORT_REQUIS_CLIENT = 15;

	/**
	 * The number of structural features of the '<em>Port Requis Client</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORT_REQUIS_CLIENT_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Port Requis Client</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORT_REQUIS_CLIENT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modelM1.impl.AttachementDbSmImpl <em>Attachement Db Sm</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modelM1.impl.AttachementDbSmImpl
	 * @see modelM1.impl.ModelM1PackageImpl#getAttachementDbSm()
	 * @generated
	 */
	int ATTACHEMENT_DB_SM = 16;

	/**
	 * The feature id for the '<em><b>Rolesm</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTACHEMENT_DB_SM__ROLESM = 0;

	/**
	 * The feature id for the '<em><b>Securitymanagement</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTACHEMENT_DB_SM__SECURITYMANAGEMENT = 1;

	/**
	 * The number of structural features of the '<em>Attachement Db Sm</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTACHEMENT_DB_SM_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Attachement Db Sm</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTACHEMENT_DB_SM_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modelM1.impl.SecurityManagerImpl <em>Security Manager</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modelM1.impl.SecurityManagerImpl
	 * @see modelM1.impl.ModelM1PackageImpl#getSecurityManager()
	 * @generated
	 */
	int SECURITY_MANAGER = 17;

	/**
	 * The number of structural features of the '<em>Security Manager</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SECURITY_MANAGER_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Security Manager</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SECURITY_MANAGER_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modelM1.impl.RoleCmImpl <em>Role Cm</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modelM1.impl.RoleCmImpl
	 * @see modelM1.impl.ModelM1PackageImpl#getRoleCm()
	 * @generated
	 */
	int ROLE_CM = 18;

	/**
	 * The number of structural features of the '<em>Role Cm</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE_CM_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Role Cm</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE_CM_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modelM1.impl.InterfaceConnectionManagerImpl <em>Interface Connection Manager</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modelM1.impl.InterfaceConnectionManagerImpl
	 * @see modelM1.impl.ModelM1PackageImpl#getInterfaceConnectionManager()
	 * @generated
	 */
	int INTERFACE_CONNECTION_MANAGER = 19;

	/**
	 * The feature id for the '<em><b>Externalsocket</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERFACE_CONNECTION_MANAGER__EXTERNALSOCKET = 0;

	/**
	 * The feature id for the '<em><b>Dbquery</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERFACE_CONNECTION_MANAGER__DBQUERY = 1;

	/**
	 * The feature id for the '<em><b>Securitycheck</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERFACE_CONNECTION_MANAGER__SECURITYCHECK = 2;

	/**
	 * The number of structural features of the '<em>Interface Connection Manager</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERFACE_CONNECTION_MANAGER_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Interface Connection Manager</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERFACE_CONNECTION_MANAGER_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modelM1.impl.InterfaceClientImpl <em>Interface Client</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modelM1.impl.InterfaceClientImpl
	 * @see modelM1.impl.ModelM1PackageImpl#getInterfaceClient()
	 * @generated
	 */
	int INTERFACE_CLIENT = 20;

	/**
	 * The feature id for the '<em><b>Attachementclientrpc</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERFACE_CLIENT__ATTACHEMENTCLIENTRPC = 0;

	/**
	 * The feature id for the '<em><b>Portfourniclient</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERFACE_CLIENT__PORTFOURNICLIENT = 1;

	/**
	 * The feature id for the '<em><b>Portrequisclient</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERFACE_CLIENT__PORTREQUISCLIENT = 2;

	/**
	 * The feature id for the '<em><b>Servicefourniclient</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERFACE_CLIENT__SERVICEFOURNICLIENT = 3;

	/**
	 * The number of structural features of the '<em>Interface Client</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERFACE_CLIENT_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Interface Client</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERFACE_CLIENT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modelM1.impl.ExternalSocketImpl <em>External Socket</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modelM1.impl.ExternalSocketImpl
	 * @see modelM1.impl.ModelM1PackageImpl#getExternalSocket()
	 * @generated
	 */
	int EXTERNAL_SOCKET = 21;

	/**
	 * The number of structural features of the '<em>External Socket</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXTERNAL_SOCKET_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>External Socket</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXTERNAL_SOCKET_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modelM1.impl.SystemeClientServeurImpl <em>Systeme Client Serveur</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modelM1.impl.SystemeClientServeurImpl
	 * @see modelM1.impl.ModelM1PackageImpl#getSystemeClientServeur()
	 * @generated
	 */
	int SYSTEME_CLIENT_SERVEUR = 22;

	/**
	 * The feature id for the '<em><b>Client</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYSTEME_CLIENT_SERVEUR__CLIENT = 0;

	/**
	 * The feature id for the '<em><b>Serveur</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYSTEME_CLIENT_SERVEUR__SERVEUR = 1;

	/**
	 * The feature id for the '<em><b>Connecteurrpc</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYSTEME_CLIENT_SERVEUR__CONNECTEURRPC = 2;

	/**
	 * The feature id for the '<em><b>Attachementrpcserveur</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYSTEME_CLIENT_SERVEUR__ATTACHEMENTRPCSERVEUR = 3;

	/**
	 * The number of structural features of the '<em>Systeme Client Serveur</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYSTEME_CLIENT_SERVEUR_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Systeme Client Serveur</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYSTEME_CLIENT_SERVEUR_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modelM1.impl.ConfigurationServeurImpl <em>Configuration Serveur</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modelM1.impl.ConfigurationServeurImpl
	 * @see modelM1.impl.ModelM1PackageImpl#getConfigurationServeur()
	 * @generated
	 */
	int CONFIGURATION_SERVEUR = 23;

	/**
	 * The feature id for the '<em><b>Interfaceconfigurationserveur</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONFIGURATION_SERVEUR__INTERFACECONFIGURATIONSERVEUR = 0;

	/**
	 * The feature id for the '<em><b>Securitymanager</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONFIGURATION_SERVEUR__SECURITYMANAGER = 1;

	/**
	 * The feature id for the '<em><b>Connecteurcmdb</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONFIGURATION_SERVEUR__CONNECTEURCMDB = 2;

	/**
	 * The feature id for the '<em><b>Connectionmanager</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONFIGURATION_SERVEUR__CONNECTIONMANAGER = 3;

	/**
	 * The feature id for the '<em><b>Attachementcmdb</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONFIGURATION_SERVEUR__ATTACHEMENTCMDB = 4;

	/**
	 * The feature id for the '<em><b>Attachementsmdb</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONFIGURATION_SERVEUR__ATTACHEMENTSMDB = 5;

	/**
	 * The feature id for the '<em><b>Securitymanagement</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONFIGURATION_SERVEUR__SECURITYMANAGEMENT = 6;

	/**
	 * The feature id for the '<em><b>Attachementcmsm</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONFIGURATION_SERVEUR__ATTACHEMENTCMSM = 7;

	/**
	 * The feature id for the '<em><b>Connecteurdbsm</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONFIGURATION_SERVEUR__CONNECTEURDBSM = 8;

	/**
	 * The feature id for the '<em><b>Attachementsmcm</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONFIGURATION_SERVEUR__ATTACHEMENTSMCM = 9;

	/**
	 * The feature id for the '<em><b>Database</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONFIGURATION_SERVEUR__DATABASE = 10;

	/**
	 * The feature id for the '<em><b>Attachementdbcm</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONFIGURATION_SERVEUR__ATTACHEMENTDBCM = 11;

	/**
	 * The feature id for the '<em><b>Attachementdbsm</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONFIGURATION_SERVEUR__ATTACHEMENTDBSM = 12;

	/**
	 * The feature id for the '<em><b>Connecteurcmsm</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONFIGURATION_SERVEUR__CONNECTEURCMSM = 13;

	/**
	 * The number of structural features of the '<em>Configuration Serveur</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONFIGURATION_SERVEUR_FEATURE_COUNT = 14;

	/**
	 * The number of operations of the '<em>Configuration Serveur</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONFIGURATION_SERVEUR_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modelM1.impl.QueryInterogationImpl <em>Query Interogation</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modelM1.impl.QueryInterogationImpl
	 * @see modelM1.impl.ModelM1PackageImpl#getQueryInterogation()
	 * @generated
	 */
	int QUERY_INTEROGATION = 24;

	/**
	 * The number of structural features of the '<em>Query Interogation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int QUERY_INTEROGATION_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Query Interogation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int QUERY_INTEROGATION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modelM1.impl.InterfaceDatabaseImpl <em>Interface Database</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modelM1.impl.InterfaceDatabaseImpl
	 * @see modelM1.impl.ModelM1PackageImpl#getInterfaceDatabase()
	 * @generated
	 */
	int INTERFACE_DATABASE = 25;

	/**
	 * The feature id for the '<em><b>Queryinterogation</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERFACE_DATABASE__QUERYINTEROGATION = 0;

	/**
	 * The feature id for the '<em><b>Securitymanagement</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERFACE_DATABASE__SECURITYMANAGEMENT = 1;

	/**
	 * The number of structural features of the '<em>Interface Database</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERFACE_DATABASE_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Interface Database</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERFACE_DATABASE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modelM1.impl.DatabaseImpl <em>Database</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modelM1.impl.DatabaseImpl
	 * @see modelM1.impl.ModelM1PackageImpl#getDatabase()
	 * @generated
	 */
	int DATABASE = 26;

	/**
	 * The feature id for the '<em><b>Interfacedatabase</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DATABASE__INTERFACEDATABASE = 0;

	/**
	 * The number of structural features of the '<em>Database</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DATABASE_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Database</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DATABASE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modelM1.impl.ConnecteurCmSmImpl <em>Connecteur Cm Sm</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modelM1.impl.ConnecteurCmSmImpl
	 * @see modelM1.impl.ModelM1PackageImpl#getConnecteurCmSm()
	 * @generated
	 */
	int CONNECTEUR_CM_SM = 27;

	/**
	 * The feature id for the '<em><b>Interfaceconnecteurcmsm</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTEUR_CM_SM__INTERFACECONNECTEURCMSM = 0;

	/**
	 * The number of structural features of the '<em>Connecteur Cm Sm</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTEUR_CM_SM_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Connecteur Cm Sm</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTEUR_CM_SM_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modelM1.impl.InterfaceConnecteurRPCImpl <em>Interface Connecteur RPC</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modelM1.impl.InterfaceConnecteurRPCImpl
	 * @see modelM1.impl.ModelM1PackageImpl#getInterfaceConnecteurRPC()
	 * @generated
	 */
	int INTERFACE_CONNECTEUR_RPC = 28;

	/**
	 * The number of structural features of the '<em>Interface Connecteur RPC</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERFACE_CONNECTEUR_RPC_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Interface Connecteur RPC</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERFACE_CONNECTEUR_RPC_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modelM1.impl.AttachementCmSmImpl <em>Attachement Cm Sm</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modelM1.impl.AttachementCmSmImpl
	 * @see modelM1.impl.ModelM1PackageImpl#getAttachementCmSm()
	 * @generated
	 */
	int ATTACHEMENT_CM_SM = 29;

	/**
	 * The feature id for the '<em><b>Rolesm</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTACHEMENT_CM_SM__ROLESM = 0;

	/**
	 * The feature id for the '<em><b>Securitycheck</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTACHEMENT_CM_SM__SECURITYCHECK = 1;

	/**
	 * The number of structural features of the '<em>Attachement Cm Sm</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTACHEMENT_CM_SM_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Attachement Cm Sm</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTACHEMENT_CM_SM_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modelM1.impl.AttachementCmDbImpl <em>Attachement Cm Db</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modelM1.impl.AttachementCmDbImpl
	 * @see modelM1.impl.ModelM1PackageImpl#getAttachementCmDb()
	 * @generated
	 */
	int ATTACHEMENT_CM_DB = 30;

	/**
	 * The feature id for the '<em><b>Roledb</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTACHEMENT_CM_DB__ROLEDB = 0;

	/**
	 * The feature id for the '<em><b>Dbquery</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTACHEMENT_CM_DB__DBQUERY = 1;

	/**
	 * The number of structural features of the '<em>Attachement Cm Db</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTACHEMENT_CM_DB_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Attachement Cm Db</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTACHEMENT_CM_DB_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modelM1.impl.InterfaceConnecteurCmDbImpl <em>Interface Connecteur Cm Db</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modelM1.impl.InterfaceConnecteurCmDbImpl
	 * @see modelM1.impl.ModelM1PackageImpl#getInterfaceConnecteurCmDb()
	 * @generated
	 */
	int INTERFACE_CONNECTEUR_CM_DB = 31;

	/**
	 * The feature id for the '<em><b>Roledb</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERFACE_CONNECTEUR_CM_DB__ROLEDB = 0;

	/**
	 * The feature id for the '<em><b>Rolecm</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERFACE_CONNECTEUR_CM_DB__ROLECM = 1;

	/**
	 * The number of structural features of the '<em>Interface Connecteur Cm Db</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERFACE_CONNECTEUR_CM_DB_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Interface Connecteur Cm Db</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERFACE_CONNECTEUR_CM_DB_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modelM1.impl.AttachementSmCmImpl <em>Attachement Sm Cm</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modelM1.impl.AttachementSmCmImpl
	 * @see modelM1.impl.ModelM1PackageImpl#getAttachementSmCm()
	 * @generated
	 */
	int ATTACHEMENT_SM_CM = 32;

	/**
	 * The feature id for the '<em><b>Securityauthentification</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTACHEMENT_SM_CM__SECURITYAUTHENTIFICATION = 0;

	/**
	 * The feature id for the '<em><b>Rolecm</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTACHEMENT_SM_CM__ROLECM = 1;

	/**
	 * The number of structural features of the '<em>Attachement Sm Cm</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTACHEMENT_SM_CM_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Attachement Sm Cm</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTACHEMENT_SM_CM_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modelM1.impl.ClientImpl <em>Client</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modelM1.impl.ClientImpl
	 * @see modelM1.impl.ModelM1PackageImpl#getClient()
	 * @generated
	 */
	int CLIENT = 33;

	/**
	 * The feature id for the '<em><b>Interfaceclient</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLIENT__INTERFACECLIENT = 0;

	/**
	 * The number of structural features of the '<em>Client</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLIENT_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Client</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLIENT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modelM1.impl.ConnecteurCmDbImpl <em>Connecteur Cm Db</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modelM1.impl.ConnecteurCmDbImpl
	 * @see modelM1.impl.ModelM1PackageImpl#getConnecteurCmDb()
	 * @generated
	 */
	int CONNECTEUR_CM_DB = 34;

	/**
	 * The feature id for the '<em><b>Interfaceconnecteurcmdb</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTEUR_CM_DB__INTERFACECONNECTEURCMDB = 0;

	/**
	 * The number of structural features of the '<em>Connecteur Cm Db</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTEUR_CM_DB_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Connecteur Cm Db</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTEUR_CM_DB_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modelM1.impl.RoleSmImpl <em>Role Sm</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modelM1.impl.RoleSmImpl
	 * @see modelM1.impl.ModelM1PackageImpl#getRoleSm()
	 * @generated
	 */
	int ROLE_SM = 35;

	/**
	 * The number of structural features of the '<em>Role Sm</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE_SM_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Role Sm</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLE_SM_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modelM1.impl.SecurityCheckImpl <em>Security Check</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modelM1.impl.SecurityCheckImpl
	 * @see modelM1.impl.ModelM1PackageImpl#getSecurityCheck()
	 * @generated
	 */
	int SECURITY_CHECK = 36;

	/**
	 * The number of structural features of the '<em>Security Check</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SECURITY_CHECK_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Security Check</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SECURITY_CHECK_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modelM1.impl.ConnecteurRPCImpl <em>Connecteur RPC</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modelM1.impl.ConnecteurRPCImpl
	 * @see modelM1.impl.ModelM1PackageImpl#getConnecteurRPC()
	 * @generated
	 */
	int CONNECTEUR_RPC = 37;

	/**
	 * The feature id for the '<em><b>Interfaceconnecteurrpc</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTEUR_RPC__INTERFACECONNECTEURRPC = 0;

	/**
	 * The number of structural features of the '<em>Connecteur RPC</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTEUR_RPC_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Connecteur RPC</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTEUR_RPC_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modelM1.impl.AttachementDbCmImpl <em>Attachement Db Cm</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modelM1.impl.AttachementDbCmImpl
	 * @see modelM1.impl.ModelM1PackageImpl#getAttachementDbCm()
	 * @generated
	 */
	int ATTACHEMENT_DB_CM = 38;

	/**
	 * The feature id for the '<em><b>Queryinterogation</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTACHEMENT_DB_CM__QUERYINTEROGATION = 0;

	/**
	 * The feature id for the '<em><b>Rolecm</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTACHEMENT_DB_CM__ROLECM = 1;

	/**
	 * The number of structural features of the '<em>Attachement Db Cm</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTACHEMENT_DB_CM_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Attachement Db Cm</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTACHEMENT_DB_CM_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modelM1.impl.InterfaceConfigurationServeurImpl <em>Interface Configuration Serveur</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modelM1.impl.InterfaceConfigurationServeurImpl
	 * @see modelM1.impl.ModelM1PackageImpl#getInterfaceConfigurationServeur()
	 * @generated
	 */
	int INTERFACE_CONFIGURATION_SERVEUR = 39;

	/**
	 * The feature id for the '<em><b>Portfourniconfigurationserveur</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERFACE_CONFIGURATION_SERVEUR__PORTFOURNICONFIGURATIONSERVEUR = 0;

	/**
	 * The number of structural features of the '<em>Interface Configuration Serveur</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERFACE_CONFIGURATION_SERVEUR_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Interface Configuration Serveur</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERFACE_CONFIGURATION_SERVEUR_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modelM1.impl.ConnectionManagerImpl <em>Connection Manager</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modelM1.impl.ConnectionManagerImpl
	 * @see modelM1.impl.ModelM1PackageImpl#getConnectionManager()
	 * @generated
	 */
	int CONNECTION_MANAGER = 40;

	/**
	 * The feature id for the '<em><b>Interfaceconnectionmanager</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTION_MANAGER__INTERFACECONNECTIONMANAGER = 0;

	/**
	 * The number of structural features of the '<em>Connection Manager</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTION_MANAGER_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Connection Manager</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTION_MANAGER_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modelM1.impl.ServeurImpl <em>Serveur</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modelM1.impl.ServeurImpl
	 * @see modelM1.impl.ModelM1PackageImpl#getServeur()
	 * @generated
	 */
	int SERVEUR = 41;

	/**
	 * The feature id for the '<em><b>Configurationserveur</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVEUR__CONFIGURATIONSERVEUR = 0;

	/**
	 * The number of structural features of the '<em>Serveur</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVEUR_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Serveur</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVEUR_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modelM1.impl.ConnecteurDbSmImpl <em>Connecteur Db Sm</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modelM1.impl.ConnecteurDbSmImpl
	 * @see modelM1.impl.ModelM1PackageImpl#getConnecteurDbSm()
	 * @generated
	 */
	int CONNECTEUR_DB_SM = 42;

	/**
	 * The feature id for the '<em><b>Interfaceconnecteurdbsm</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTEUR_DB_SM__INTERFACECONNECTEURDBSM = 0;

	/**
	 * The number of structural features of the '<em>Connecteur Db Sm</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTEUR_DB_SM_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Connecteur Db Sm</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTEUR_DB_SM_OPERATION_COUNT = 0;

	/**
	 * Returns the meta object for class '{@link modelM1.SecurityAuthentification <em>Security Authentification</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Security Authentification</em>'.
	 * @see modelM1.SecurityAuthentification
	 * @generated
	 */
	EClass getSecurityAuthentification();

	/**
	 * Returns the meta object for class '{@link modelM1.InterfaceConnecteurCmSm <em>Interface Connecteur Cm Sm</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Interface Connecteur Cm Sm</em>'.
	 * @see modelM1.InterfaceConnecteurCmSm
	 * @generated
	 */
	EClass getInterfaceConnecteurCmSm();

	/**
	 * Returns the meta object for the reference '{@link modelM1.InterfaceConnecteurCmSm#getRolecm <em>Rolecm</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Rolecm</em>'.
	 * @see modelM1.InterfaceConnecteurCmSm#getRolecm()
	 * @see #getInterfaceConnecteurCmSm()
	 * @generated
	 */
	EReference getInterfaceConnecteurCmSm_Rolecm();

	/**
	 * Returns the meta object for the reference '{@link modelM1.InterfaceConnecteurCmSm#getRolesm <em>Rolesm</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Rolesm</em>'.
	 * @see modelM1.InterfaceConnecteurCmSm#getRolesm()
	 * @see #getInterfaceConnecteurCmSm()
	 * @generated
	 */
	EReference getInterfaceConnecteurCmSm_Rolesm();

	/**
	 * Returns the meta object for class '{@link modelM1.DbQuery <em>Db Query</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Db Query</em>'.
	 * @see modelM1.DbQuery
	 * @generated
	 */
	EClass getDbQuery();

	/**
	 * Returns the meta object for class '{@link modelM1.InterfaceConnecteurDbSm <em>Interface Connecteur Db Sm</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Interface Connecteur Db Sm</em>'.
	 * @see modelM1.InterfaceConnecteurDbSm
	 * @generated
	 */
	EClass getInterfaceConnecteurDbSm();

	/**
	 * Returns the meta object for the reference '{@link modelM1.InterfaceConnecteurDbSm#getRolesm <em>Rolesm</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Rolesm</em>'.
	 * @see modelM1.InterfaceConnecteurDbSm#getRolesm()
	 * @see #getInterfaceConnecteurDbSm()
	 * @generated
	 */
	EReference getInterfaceConnecteurDbSm_Rolesm();

	/**
	 * Returns the meta object for the reference '{@link modelM1.InterfaceConnecteurDbSm#getRoledb <em>Roledb</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Roledb</em>'.
	 * @see modelM1.InterfaceConnecteurDbSm#getRoledb()
	 * @see #getInterfaceConnecteurDbSm()
	 * @generated
	 */
	EReference getInterfaceConnecteurDbSm_Roledb();

	/**
	 * Returns the meta object for class '{@link modelM1.AttachementSmDb <em>Attachement Sm Db</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Attachement Sm Db</em>'.
	 * @see modelM1.AttachementSmDb
	 * @generated
	 */
	EClass getAttachementSmDb();

	/**
	 * Returns the meta object for the reference '{@link modelM1.AttachementSmDb#getCheckquery <em>Checkquery</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Checkquery</em>'.
	 * @see modelM1.AttachementSmDb#getCheckquery()
	 * @see #getAttachementSmDb()
	 * @generated
	 */
	EReference getAttachementSmDb_Checkquery();

	/**
	 * Returns the meta object for the reference '{@link modelM1.AttachementSmDb#getRoledb <em>Roledb</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Roledb</em>'.
	 * @see modelM1.AttachementSmDb#getRoledb()
	 * @see #getAttachementSmDb()
	 * @generated
	 */
	EReference getAttachementSmDb_Roledb();

	/**
	 * Returns the meta object for class '{@link modelM1.PortFourniConfigurationServeur <em>Port Fourni Configuration Serveur</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Port Fourni Configuration Serveur</em>'.
	 * @see modelM1.PortFourniConfigurationServeur
	 * @generated
	 */
	EClass getPortFourniConfigurationServeur();

	/**
	 * Returns the meta object for class '{@link modelM1.ServiceFourniClient <em>Service Fourni Client</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Service Fourni Client</em>'.
	 * @see modelM1.ServiceFourniClient
	 * @generated
	 */
	EClass getServiceFourniClient();

	/**
	 * Returns the meta object for class '{@link modelM1.InterfaceSecurityManager <em>Interface Security Manager</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Interface Security Manager</em>'.
	 * @see modelM1.InterfaceSecurityManager
	 * @generated
	 */
	EClass getInterfaceSecurityManager();

	/**
	 * Returns the meta object for the reference '{@link modelM1.InterfaceSecurityManager#getCheckquery <em>Checkquery</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Checkquery</em>'.
	 * @see modelM1.InterfaceSecurityManager#getCheckquery()
	 * @see #getInterfaceSecurityManager()
	 * @generated
	 */
	EReference getInterfaceSecurityManager_Checkquery();

	/**
	 * Returns the meta object for the reference '{@link modelM1.InterfaceSecurityManager#getSecurityauthentification <em>Securityauthentification</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Securityauthentification</em>'.
	 * @see modelM1.InterfaceSecurityManager#getSecurityauthentification()
	 * @see #getInterfaceSecurityManager()
	 * @generated
	 */
	EReference getInterfaceSecurityManager_Securityauthentification();

	/**
	 * Returns the meta object for class '{@link modelM1.BindingExternalSocket <em>Binding External Socket</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Binding External Socket</em>'.
	 * @see modelM1.BindingExternalSocket
	 * @generated
	 */
	EClass getBindingExternalSocket();

	/**
	 * Returns the meta object for the reference '{@link modelM1.BindingExternalSocket#getExternalsocket <em>Externalsocket</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Externalsocket</em>'.
	 * @see modelM1.BindingExternalSocket#getExternalsocket()
	 * @see #getBindingExternalSocket()
	 * @generated
	 */
	EReference getBindingExternalSocket_Externalsocket();

	/**
	 * Returns the meta object for the reference '{@link modelM1.BindingExternalSocket#getPortfourniconfigurationserveur <em>Portfourniconfigurationserveur</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Portfourniconfigurationserveur</em>'.
	 * @see modelM1.BindingExternalSocket#getPortfourniconfigurationserveur()
	 * @see #getBindingExternalSocket()
	 * @generated
	 */
	EReference getBindingExternalSocket_Portfourniconfigurationserveur();

	/**
	 * Returns the meta object for class '{@link modelM1.RoleDb <em>Role Db</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Role Db</em>'.
	 * @see modelM1.RoleDb
	 * @generated
	 */
	EClass getRoleDb();

	/**
	 * Returns the meta object for class '{@link modelM1.CheckQuery <em>Check Query</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Check Query</em>'.
	 * @see modelM1.CheckQuery
	 * @generated
	 */
	EClass getCheckQuery();

	/**
	 * Returns the meta object for class '{@link modelM1.AttachementRPCServeur <em>Attachement RPC Serveur</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Attachement RPC Serveur</em>'.
	 * @see modelM1.AttachementRPCServeur
	 * @generated
	 */
	EClass getAttachementRPCServeur();

	/**
	 * Returns the meta object for the reference '{@link modelM1.AttachementRPCServeur#getInterfaceconnecteurrpc <em>Interfaceconnecteurrpc</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Interfaceconnecteurrpc</em>'.
	 * @see modelM1.AttachementRPCServeur#getInterfaceconnecteurrpc()
	 * @see #getAttachementRPCServeur()
	 * @generated
	 */
	EReference getAttachementRPCServeur_Interfaceconnecteurrpc();

	/**
	 * Returns the meta object for the reference '{@link modelM1.AttachementRPCServeur#getInterfaceconfigurationserveur <em>Interfaceconfigurationserveur</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Interfaceconfigurationserveur</em>'.
	 * @see modelM1.AttachementRPCServeur#getInterfaceconfigurationserveur()
	 * @see #getAttachementRPCServeur()
	 * @generated
	 */
	EReference getAttachementRPCServeur_Interfaceconfigurationserveur();

	/**
	 * Returns the meta object for class '{@link modelM1.AttachementClientRPC <em>Attachement Client RPC</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Attachement Client RPC</em>'.
	 * @see modelM1.AttachementClientRPC
	 * @generated
	 */
	EClass getAttachementClientRPC();

	/**
	 * Returns the meta object for the reference '{@link modelM1.AttachementClientRPC#getInterfaceconnecteurrpc <em>Interfaceconnecteurrpc</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Interfaceconnecteurrpc</em>'.
	 * @see modelM1.AttachementClientRPC#getInterfaceconnecteurrpc()
	 * @see #getAttachementClientRPC()
	 * @generated
	 */
	EReference getAttachementClientRPC_Interfaceconnecteurrpc();

	/**
	 * Returns the meta object for class '{@link modelM1.SecurityManagement <em>Security Management</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Security Management</em>'.
	 * @see modelM1.SecurityManagement
	 * @generated
	 */
	EClass getSecurityManagement();

	/**
	 * Returns the meta object for class '{@link modelM1.PortFourniClient <em>Port Fourni Client</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Port Fourni Client</em>'.
	 * @see modelM1.PortFourniClient
	 * @generated
	 */
	EClass getPortFourniClient();

	/**
	 * Returns the meta object for class '{@link modelM1.PortRequisClient <em>Port Requis Client</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Port Requis Client</em>'.
	 * @see modelM1.PortRequisClient
	 * @generated
	 */
	EClass getPortRequisClient();

	/**
	 * Returns the meta object for class '{@link modelM1.AttachementDbSm <em>Attachement Db Sm</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Attachement Db Sm</em>'.
	 * @see modelM1.AttachementDbSm
	 * @generated
	 */
	EClass getAttachementDbSm();

	/**
	 * Returns the meta object for the reference '{@link modelM1.AttachementDbSm#getRolesm <em>Rolesm</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Rolesm</em>'.
	 * @see modelM1.AttachementDbSm#getRolesm()
	 * @see #getAttachementDbSm()
	 * @generated
	 */
	EReference getAttachementDbSm_Rolesm();

	/**
	 * Returns the meta object for the reference '{@link modelM1.AttachementDbSm#getSecuritymanagement <em>Securitymanagement</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Securitymanagement</em>'.
	 * @see modelM1.AttachementDbSm#getSecuritymanagement()
	 * @see #getAttachementDbSm()
	 * @generated
	 */
	EReference getAttachementDbSm_Securitymanagement();

	/**
	 * Returns the meta object for class '{@link modelM1.SecurityManager <em>Security Manager</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Security Manager</em>'.
	 * @see modelM1.SecurityManager
	 * @generated
	 */
	EClass getSecurityManager();

	/**
	 * Returns the meta object for class '{@link modelM1.RoleCm <em>Role Cm</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Role Cm</em>'.
	 * @see modelM1.RoleCm
	 * @generated
	 */
	EClass getRoleCm();

	/**
	 * Returns the meta object for class '{@link modelM1.InterfaceConnectionManager <em>Interface Connection Manager</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Interface Connection Manager</em>'.
	 * @see modelM1.InterfaceConnectionManager
	 * @generated
	 */
	EClass getInterfaceConnectionManager();

	/**
	 * Returns the meta object for the reference '{@link modelM1.InterfaceConnectionManager#getExternalsocket <em>Externalsocket</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Externalsocket</em>'.
	 * @see modelM1.InterfaceConnectionManager#getExternalsocket()
	 * @see #getInterfaceConnectionManager()
	 * @generated
	 */
	EReference getInterfaceConnectionManager_Externalsocket();

	/**
	 * Returns the meta object for the reference '{@link modelM1.InterfaceConnectionManager#getDbquery <em>Dbquery</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Dbquery</em>'.
	 * @see modelM1.InterfaceConnectionManager#getDbquery()
	 * @see #getInterfaceConnectionManager()
	 * @generated
	 */
	EReference getInterfaceConnectionManager_Dbquery();

	/**
	 * Returns the meta object for the reference '{@link modelM1.InterfaceConnectionManager#getSecuritycheck <em>Securitycheck</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Securitycheck</em>'.
	 * @see modelM1.InterfaceConnectionManager#getSecuritycheck()
	 * @see #getInterfaceConnectionManager()
	 * @generated
	 */
	EReference getInterfaceConnectionManager_Securitycheck();

	/**
	 * Returns the meta object for class '{@link modelM1.InterfaceClient <em>Interface Client</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Interface Client</em>'.
	 * @see modelM1.InterfaceClient
	 * @generated
	 */
	EClass getInterfaceClient();

	/**
	 * Returns the meta object for the reference '{@link modelM1.InterfaceClient#getAttachementclientrpc <em>Attachementclientrpc</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Attachementclientrpc</em>'.
	 * @see modelM1.InterfaceClient#getAttachementclientrpc()
	 * @see #getInterfaceClient()
	 * @generated
	 */
	EReference getInterfaceClient_Attachementclientrpc();

	/**
	 * Returns the meta object for the reference '{@link modelM1.InterfaceClient#getPortfourniclient <em>Portfourniclient</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Portfourniclient</em>'.
	 * @see modelM1.InterfaceClient#getPortfourniclient()
	 * @see #getInterfaceClient()
	 * @generated
	 */
	EReference getInterfaceClient_Portfourniclient();

	/**
	 * Returns the meta object for the reference '{@link modelM1.InterfaceClient#getPortrequisclient <em>Portrequisclient</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Portrequisclient</em>'.
	 * @see modelM1.InterfaceClient#getPortrequisclient()
	 * @see #getInterfaceClient()
	 * @generated
	 */
	EReference getInterfaceClient_Portrequisclient();

	/**
	 * Returns the meta object for the reference '{@link modelM1.InterfaceClient#getServicefourniclient <em>Servicefourniclient</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Servicefourniclient</em>'.
	 * @see modelM1.InterfaceClient#getServicefourniclient()
	 * @see #getInterfaceClient()
	 * @generated
	 */
	EReference getInterfaceClient_Servicefourniclient();

	/**
	 * Returns the meta object for class '{@link modelM1.ExternalSocket <em>External Socket</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>External Socket</em>'.
	 * @see modelM1.ExternalSocket
	 * @generated
	 */
	EClass getExternalSocket();

	/**
	 * Returns the meta object for class '{@link modelM1.SystemeClientServeur <em>Systeme Client Serveur</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Systeme Client Serveur</em>'.
	 * @see modelM1.SystemeClientServeur
	 * @generated
	 */
	EClass getSystemeClientServeur();

	/**
	 * Returns the meta object for the reference '{@link modelM1.SystemeClientServeur#getClient <em>Client</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Client</em>'.
	 * @see modelM1.SystemeClientServeur#getClient()
	 * @see #getSystemeClientServeur()
	 * @generated
	 */
	EReference getSystemeClientServeur_Client();

	/**
	 * Returns the meta object for the reference '{@link modelM1.SystemeClientServeur#getServeur <em>Serveur</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Serveur</em>'.
	 * @see modelM1.SystemeClientServeur#getServeur()
	 * @see #getSystemeClientServeur()
	 * @generated
	 */
	EReference getSystemeClientServeur_Serveur();

	/**
	 * Returns the meta object for the reference '{@link modelM1.SystemeClientServeur#getConnecteurrpc <em>Connecteurrpc</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Connecteurrpc</em>'.
	 * @see modelM1.SystemeClientServeur#getConnecteurrpc()
	 * @see #getSystemeClientServeur()
	 * @generated
	 */
	EReference getSystemeClientServeur_Connecteurrpc();

	/**
	 * Returns the meta object for the reference '{@link modelM1.SystemeClientServeur#getAttachementrpcserveur <em>Attachementrpcserveur</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Attachementrpcserveur</em>'.
	 * @see modelM1.SystemeClientServeur#getAttachementrpcserveur()
	 * @see #getSystemeClientServeur()
	 * @generated
	 */
	EReference getSystemeClientServeur_Attachementrpcserveur();

	/**
	 * Returns the meta object for class '{@link modelM1.ConfigurationServeur <em>Configuration Serveur</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Configuration Serveur</em>'.
	 * @see modelM1.ConfigurationServeur
	 * @generated
	 */
	EClass getConfigurationServeur();

	/**
	 * Returns the meta object for the reference '{@link modelM1.ConfigurationServeur#getInterfaceconfigurationserveur <em>Interfaceconfigurationserveur</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Interfaceconfigurationserveur</em>'.
	 * @see modelM1.ConfigurationServeur#getInterfaceconfigurationserveur()
	 * @see #getConfigurationServeur()
	 * @generated
	 */
	EReference getConfigurationServeur_Interfaceconfigurationserveur();

	/**
	 * Returns the meta object for the reference '{@link modelM1.ConfigurationServeur#getSecuritymanager <em>Securitymanager</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Securitymanager</em>'.
	 * @see modelM1.ConfigurationServeur#getSecuritymanager()
	 * @see #getConfigurationServeur()
	 * @generated
	 */
	EReference getConfigurationServeur_Securitymanager();

	/**
	 * Returns the meta object for the reference '{@link modelM1.ConfigurationServeur#getConnecteurcmdb <em>Connecteurcmdb</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Connecteurcmdb</em>'.
	 * @see modelM1.ConfigurationServeur#getConnecteurcmdb()
	 * @see #getConfigurationServeur()
	 * @generated
	 */
	EReference getConfigurationServeur_Connecteurcmdb();

	/**
	 * Returns the meta object for the reference '{@link modelM1.ConfigurationServeur#getConnectionmanager <em>Connectionmanager</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Connectionmanager</em>'.
	 * @see modelM1.ConfigurationServeur#getConnectionmanager()
	 * @see #getConfigurationServeur()
	 * @generated
	 */
	EReference getConfigurationServeur_Connectionmanager();

	/**
	 * Returns the meta object for the reference '{@link modelM1.ConfigurationServeur#getAttachementcmdb <em>Attachementcmdb</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Attachementcmdb</em>'.
	 * @see modelM1.ConfigurationServeur#getAttachementcmdb()
	 * @see #getConfigurationServeur()
	 * @generated
	 */
	EReference getConfigurationServeur_Attachementcmdb();

	/**
	 * Returns the meta object for the reference '{@link modelM1.ConfigurationServeur#getAttachementsmdb <em>Attachementsmdb</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Attachementsmdb</em>'.
	 * @see modelM1.ConfigurationServeur#getAttachementsmdb()
	 * @see #getConfigurationServeur()
	 * @generated
	 */
	EReference getConfigurationServeur_Attachementsmdb();

	/**
	 * Returns the meta object for the reference '{@link modelM1.ConfigurationServeur#getSecuritymanagement <em>Securitymanagement</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Securitymanagement</em>'.
	 * @see modelM1.ConfigurationServeur#getSecuritymanagement()
	 * @see #getConfigurationServeur()
	 * @generated
	 */
	EReference getConfigurationServeur_Securitymanagement();

	/**
	 * Returns the meta object for the reference '{@link modelM1.ConfigurationServeur#getAttachementcmsm <em>Attachementcmsm</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Attachementcmsm</em>'.
	 * @see modelM1.ConfigurationServeur#getAttachementcmsm()
	 * @see #getConfigurationServeur()
	 * @generated
	 */
	EReference getConfigurationServeur_Attachementcmsm();

	/**
	 * Returns the meta object for the reference '{@link modelM1.ConfigurationServeur#getConnecteurdbsm <em>Connecteurdbsm</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Connecteurdbsm</em>'.
	 * @see modelM1.ConfigurationServeur#getConnecteurdbsm()
	 * @see #getConfigurationServeur()
	 * @generated
	 */
	EReference getConfigurationServeur_Connecteurdbsm();

	/**
	 * Returns the meta object for the reference '{@link modelM1.ConfigurationServeur#getAttachementsmcm <em>Attachementsmcm</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Attachementsmcm</em>'.
	 * @see modelM1.ConfigurationServeur#getAttachementsmcm()
	 * @see #getConfigurationServeur()
	 * @generated
	 */
	EReference getConfigurationServeur_Attachementsmcm();

	/**
	 * Returns the meta object for the reference '{@link modelM1.ConfigurationServeur#getDatabase <em>Database</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Database</em>'.
	 * @see modelM1.ConfigurationServeur#getDatabase()
	 * @see #getConfigurationServeur()
	 * @generated
	 */
	EReference getConfigurationServeur_Database();

	/**
	 * Returns the meta object for the reference '{@link modelM1.ConfigurationServeur#getAttachementdbcm <em>Attachementdbcm</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Attachementdbcm</em>'.
	 * @see modelM1.ConfigurationServeur#getAttachementdbcm()
	 * @see #getConfigurationServeur()
	 * @generated
	 */
	EReference getConfigurationServeur_Attachementdbcm();

	/**
	 * Returns the meta object for the reference '{@link modelM1.ConfigurationServeur#getAttachementdbsm <em>Attachementdbsm</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Attachementdbsm</em>'.
	 * @see modelM1.ConfigurationServeur#getAttachementdbsm()
	 * @see #getConfigurationServeur()
	 * @generated
	 */
	EReference getConfigurationServeur_Attachementdbsm();

	/**
	 * Returns the meta object for the reference '{@link modelM1.ConfigurationServeur#getConnecteurcmsm <em>Connecteurcmsm</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Connecteurcmsm</em>'.
	 * @see modelM1.ConfigurationServeur#getConnecteurcmsm()
	 * @see #getConfigurationServeur()
	 * @generated
	 */
	EReference getConfigurationServeur_Connecteurcmsm();

	/**
	 * Returns the meta object for class '{@link modelM1.QueryInterogation <em>Query Interogation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Query Interogation</em>'.
	 * @see modelM1.QueryInterogation
	 * @generated
	 */
	EClass getQueryInterogation();

	/**
	 * Returns the meta object for class '{@link modelM1.InterfaceDatabase <em>Interface Database</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Interface Database</em>'.
	 * @see modelM1.InterfaceDatabase
	 * @generated
	 */
	EClass getInterfaceDatabase();

	/**
	 * Returns the meta object for the reference '{@link modelM1.InterfaceDatabase#getQueryinterogation <em>Queryinterogation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Queryinterogation</em>'.
	 * @see modelM1.InterfaceDatabase#getQueryinterogation()
	 * @see #getInterfaceDatabase()
	 * @generated
	 */
	EReference getInterfaceDatabase_Queryinterogation();

	/**
	 * Returns the meta object for the reference '{@link modelM1.InterfaceDatabase#getSecuritymanagement <em>Securitymanagement</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Securitymanagement</em>'.
	 * @see modelM1.InterfaceDatabase#getSecuritymanagement()
	 * @see #getInterfaceDatabase()
	 * @generated
	 */
	EReference getInterfaceDatabase_Securitymanagement();

	/**
	 * Returns the meta object for class '{@link modelM1.Database <em>Database</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Database</em>'.
	 * @see modelM1.Database
	 * @generated
	 */
	EClass getDatabase();

	/**
	 * Returns the meta object for the reference '{@link modelM1.Database#getInterfacedatabase <em>Interfacedatabase</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Interfacedatabase</em>'.
	 * @see modelM1.Database#getInterfacedatabase()
	 * @see #getDatabase()
	 * @generated
	 */
	EReference getDatabase_Interfacedatabase();

	/**
	 * Returns the meta object for class '{@link modelM1.ConnecteurCmSm <em>Connecteur Cm Sm</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Connecteur Cm Sm</em>'.
	 * @see modelM1.ConnecteurCmSm
	 * @generated
	 */
	EClass getConnecteurCmSm();

	/**
	 * Returns the meta object for the reference '{@link modelM1.ConnecteurCmSm#getInterfaceconnecteurcmsm <em>Interfaceconnecteurcmsm</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Interfaceconnecteurcmsm</em>'.
	 * @see modelM1.ConnecteurCmSm#getInterfaceconnecteurcmsm()
	 * @see #getConnecteurCmSm()
	 * @generated
	 */
	EReference getConnecteurCmSm_Interfaceconnecteurcmsm();

	/**
	 * Returns the meta object for class '{@link modelM1.InterfaceConnecteurRPC <em>Interface Connecteur RPC</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Interface Connecteur RPC</em>'.
	 * @see modelM1.InterfaceConnecteurRPC
	 * @generated
	 */
	EClass getInterfaceConnecteurRPC();

	/**
	 * Returns the meta object for class '{@link modelM1.AttachementCmSm <em>Attachement Cm Sm</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Attachement Cm Sm</em>'.
	 * @see modelM1.AttachementCmSm
	 * @generated
	 */
	EClass getAttachementCmSm();

	/**
	 * Returns the meta object for the reference '{@link modelM1.AttachementCmSm#getRolesm <em>Rolesm</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Rolesm</em>'.
	 * @see modelM1.AttachementCmSm#getRolesm()
	 * @see #getAttachementCmSm()
	 * @generated
	 */
	EReference getAttachementCmSm_Rolesm();

	/**
	 * Returns the meta object for the reference '{@link modelM1.AttachementCmSm#getSecuritycheck <em>Securitycheck</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Securitycheck</em>'.
	 * @see modelM1.AttachementCmSm#getSecuritycheck()
	 * @see #getAttachementCmSm()
	 * @generated
	 */
	EReference getAttachementCmSm_Securitycheck();

	/**
	 * Returns the meta object for class '{@link modelM1.AttachementCmDb <em>Attachement Cm Db</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Attachement Cm Db</em>'.
	 * @see modelM1.AttachementCmDb
	 * @generated
	 */
	EClass getAttachementCmDb();

	/**
	 * Returns the meta object for the reference '{@link modelM1.AttachementCmDb#getRoledb <em>Roledb</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Roledb</em>'.
	 * @see modelM1.AttachementCmDb#getRoledb()
	 * @see #getAttachementCmDb()
	 * @generated
	 */
	EReference getAttachementCmDb_Roledb();

	/**
	 * Returns the meta object for the reference '{@link modelM1.AttachementCmDb#getDbquery <em>Dbquery</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Dbquery</em>'.
	 * @see modelM1.AttachementCmDb#getDbquery()
	 * @see #getAttachementCmDb()
	 * @generated
	 */
	EReference getAttachementCmDb_Dbquery();

	/**
	 * Returns the meta object for class '{@link modelM1.InterfaceConnecteurCmDb <em>Interface Connecteur Cm Db</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Interface Connecteur Cm Db</em>'.
	 * @see modelM1.InterfaceConnecteurCmDb
	 * @generated
	 */
	EClass getInterfaceConnecteurCmDb();

	/**
	 * Returns the meta object for the reference '{@link modelM1.InterfaceConnecteurCmDb#getRoledb <em>Roledb</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Roledb</em>'.
	 * @see modelM1.InterfaceConnecteurCmDb#getRoledb()
	 * @see #getInterfaceConnecteurCmDb()
	 * @generated
	 */
	EReference getInterfaceConnecteurCmDb_Roledb();

	/**
	 * Returns the meta object for the reference '{@link modelM1.InterfaceConnecteurCmDb#getRolecm <em>Rolecm</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Rolecm</em>'.
	 * @see modelM1.InterfaceConnecteurCmDb#getRolecm()
	 * @see #getInterfaceConnecteurCmDb()
	 * @generated
	 */
	EReference getInterfaceConnecteurCmDb_Rolecm();

	/**
	 * Returns the meta object for class '{@link modelM1.AttachementSmCm <em>Attachement Sm Cm</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Attachement Sm Cm</em>'.
	 * @see modelM1.AttachementSmCm
	 * @generated
	 */
	EClass getAttachementSmCm();

	/**
	 * Returns the meta object for the reference '{@link modelM1.AttachementSmCm#getSecurityauthentification <em>Securityauthentification</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Securityauthentification</em>'.
	 * @see modelM1.AttachementSmCm#getSecurityauthentification()
	 * @see #getAttachementSmCm()
	 * @generated
	 */
	EReference getAttachementSmCm_Securityauthentification();

	/**
	 * Returns the meta object for the reference '{@link modelM1.AttachementSmCm#getRolecm <em>Rolecm</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Rolecm</em>'.
	 * @see modelM1.AttachementSmCm#getRolecm()
	 * @see #getAttachementSmCm()
	 * @generated
	 */
	EReference getAttachementSmCm_Rolecm();

	/**
	 * Returns the meta object for class '{@link modelM1.Client <em>Client</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Client</em>'.
	 * @see modelM1.Client
	 * @generated
	 */
	EClass getClient();

	/**
	 * Returns the meta object for the reference '{@link modelM1.Client#getInterfaceclient <em>Interfaceclient</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Interfaceclient</em>'.
	 * @see modelM1.Client#getInterfaceclient()
	 * @see #getClient()
	 * @generated
	 */
	EReference getClient_Interfaceclient();

	/**
	 * Returns the meta object for class '{@link modelM1.ConnecteurCmDb <em>Connecteur Cm Db</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Connecteur Cm Db</em>'.
	 * @see modelM1.ConnecteurCmDb
	 * @generated
	 */
	EClass getConnecteurCmDb();

	/**
	 * Returns the meta object for the reference '{@link modelM1.ConnecteurCmDb#getInterfaceconnecteurcmdb <em>Interfaceconnecteurcmdb</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Interfaceconnecteurcmdb</em>'.
	 * @see modelM1.ConnecteurCmDb#getInterfaceconnecteurcmdb()
	 * @see #getConnecteurCmDb()
	 * @generated
	 */
	EReference getConnecteurCmDb_Interfaceconnecteurcmdb();

	/**
	 * Returns the meta object for class '{@link modelM1.RoleSm <em>Role Sm</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Role Sm</em>'.
	 * @see modelM1.RoleSm
	 * @generated
	 */
	EClass getRoleSm();

	/**
	 * Returns the meta object for class '{@link modelM1.SecurityCheck <em>Security Check</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Security Check</em>'.
	 * @see modelM1.SecurityCheck
	 * @generated
	 */
	EClass getSecurityCheck();

	/**
	 * Returns the meta object for class '{@link modelM1.ConnecteurRPC <em>Connecteur RPC</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Connecteur RPC</em>'.
	 * @see modelM1.ConnecteurRPC
	 * @generated
	 */
	EClass getConnecteurRPC();

	/**
	 * Returns the meta object for the reference '{@link modelM1.ConnecteurRPC#getInterfaceconnecteurrpc <em>Interfaceconnecteurrpc</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Interfaceconnecteurrpc</em>'.
	 * @see modelM1.ConnecteurRPC#getInterfaceconnecteurrpc()
	 * @see #getConnecteurRPC()
	 * @generated
	 */
	EReference getConnecteurRPC_Interfaceconnecteurrpc();

	/**
	 * Returns the meta object for class '{@link modelM1.AttachementDbCm <em>Attachement Db Cm</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Attachement Db Cm</em>'.
	 * @see modelM1.AttachementDbCm
	 * @generated
	 */
	EClass getAttachementDbCm();

	/**
	 * Returns the meta object for the reference '{@link modelM1.AttachementDbCm#getQueryinterogation <em>Queryinterogation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Queryinterogation</em>'.
	 * @see modelM1.AttachementDbCm#getQueryinterogation()
	 * @see #getAttachementDbCm()
	 * @generated
	 */
	EReference getAttachementDbCm_Queryinterogation();

	/**
	 * Returns the meta object for the reference '{@link modelM1.AttachementDbCm#getRolecm <em>Rolecm</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Rolecm</em>'.
	 * @see modelM1.AttachementDbCm#getRolecm()
	 * @see #getAttachementDbCm()
	 * @generated
	 */
	EReference getAttachementDbCm_Rolecm();

	/**
	 * Returns the meta object for class '{@link modelM1.InterfaceConfigurationServeur <em>Interface Configuration Serveur</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Interface Configuration Serveur</em>'.
	 * @see modelM1.InterfaceConfigurationServeur
	 * @generated
	 */
	EClass getInterfaceConfigurationServeur();

	/**
	 * Returns the meta object for the reference '{@link modelM1.InterfaceConfigurationServeur#getPortfourniconfigurationserveur <em>Portfourniconfigurationserveur</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Portfourniconfigurationserveur</em>'.
	 * @see modelM1.InterfaceConfigurationServeur#getPortfourniconfigurationserveur()
	 * @see #getInterfaceConfigurationServeur()
	 * @generated
	 */
	EReference getInterfaceConfigurationServeur_Portfourniconfigurationserveur();

	/**
	 * Returns the meta object for class '{@link modelM1.ConnectionManager <em>Connection Manager</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Connection Manager</em>'.
	 * @see modelM1.ConnectionManager
	 * @generated
	 */
	EClass getConnectionManager();

	/**
	 * Returns the meta object for the reference '{@link modelM1.ConnectionManager#getInterfaceconnectionmanager <em>Interfaceconnectionmanager</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Interfaceconnectionmanager</em>'.
	 * @see modelM1.ConnectionManager#getInterfaceconnectionmanager()
	 * @see #getConnectionManager()
	 * @generated
	 */
	EReference getConnectionManager_Interfaceconnectionmanager();

	/**
	 * Returns the meta object for class '{@link modelM1.Serveur <em>Serveur</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Serveur</em>'.
	 * @see modelM1.Serveur
	 * @generated
	 */
	EClass getServeur();

	/**
	 * Returns the meta object for the reference '{@link modelM1.Serveur#getConfigurationserveur <em>Configurationserveur</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Configurationserveur</em>'.
	 * @see modelM1.Serveur#getConfigurationserveur()
	 * @see #getServeur()
	 * @generated
	 */
	EReference getServeur_Configurationserveur();

	/**
	 * Returns the meta object for class '{@link modelM1.ConnecteurDbSm <em>Connecteur Db Sm</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Connecteur Db Sm</em>'.
	 * @see modelM1.ConnecteurDbSm
	 * @generated
	 */
	EClass getConnecteurDbSm();

	/**
	 * Returns the meta object for the reference '{@link modelM1.ConnecteurDbSm#getInterfaceconnecteurdbsm <em>Interfaceconnecteurdbsm</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Interfaceconnecteurdbsm</em>'.
	 * @see modelM1.ConnecteurDbSm#getInterfaceconnecteurdbsm()
	 * @see #getConnecteurDbSm()
	 * @generated
	 */
	EReference getConnecteurDbSm_Interfaceconnecteurdbsm();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	ModelM1Factory getModelM1Factory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link modelM1.impl.SecurityAuthentificationImpl <em>Security Authentification</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modelM1.impl.SecurityAuthentificationImpl
		 * @see modelM1.impl.ModelM1PackageImpl#getSecurityAuthentification()
		 * @generated
		 */
		EClass SECURITY_AUTHENTIFICATION = eINSTANCE.getSecurityAuthentification();

		/**
		 * The meta object literal for the '{@link modelM1.impl.InterfaceConnecteurCmSmImpl <em>Interface Connecteur Cm Sm</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modelM1.impl.InterfaceConnecteurCmSmImpl
		 * @see modelM1.impl.ModelM1PackageImpl#getInterfaceConnecteurCmSm()
		 * @generated
		 */
		EClass INTERFACE_CONNECTEUR_CM_SM = eINSTANCE.getInterfaceConnecteurCmSm();

		/**
		 * The meta object literal for the '<em><b>Rolecm</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INTERFACE_CONNECTEUR_CM_SM__ROLECM = eINSTANCE.getInterfaceConnecteurCmSm_Rolecm();

		/**
		 * The meta object literal for the '<em><b>Rolesm</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INTERFACE_CONNECTEUR_CM_SM__ROLESM = eINSTANCE.getInterfaceConnecteurCmSm_Rolesm();

		/**
		 * The meta object literal for the '{@link modelM1.impl.DbQueryImpl <em>Db Query</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modelM1.impl.DbQueryImpl
		 * @see modelM1.impl.ModelM1PackageImpl#getDbQuery()
		 * @generated
		 */
		EClass DB_QUERY = eINSTANCE.getDbQuery();

		/**
		 * The meta object literal for the '{@link modelM1.impl.InterfaceConnecteurDbSmImpl <em>Interface Connecteur Db Sm</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modelM1.impl.InterfaceConnecteurDbSmImpl
		 * @see modelM1.impl.ModelM1PackageImpl#getInterfaceConnecteurDbSm()
		 * @generated
		 */
		EClass INTERFACE_CONNECTEUR_DB_SM = eINSTANCE.getInterfaceConnecteurDbSm();

		/**
		 * The meta object literal for the '<em><b>Rolesm</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INTERFACE_CONNECTEUR_DB_SM__ROLESM = eINSTANCE.getInterfaceConnecteurDbSm_Rolesm();

		/**
		 * The meta object literal for the '<em><b>Roledb</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INTERFACE_CONNECTEUR_DB_SM__ROLEDB = eINSTANCE.getInterfaceConnecteurDbSm_Roledb();

		/**
		 * The meta object literal for the '{@link modelM1.impl.AttachementSmDbImpl <em>Attachement Sm Db</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modelM1.impl.AttachementSmDbImpl
		 * @see modelM1.impl.ModelM1PackageImpl#getAttachementSmDb()
		 * @generated
		 */
		EClass ATTACHEMENT_SM_DB = eINSTANCE.getAttachementSmDb();

		/**
		 * The meta object literal for the '<em><b>Checkquery</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ATTACHEMENT_SM_DB__CHECKQUERY = eINSTANCE.getAttachementSmDb_Checkquery();

		/**
		 * The meta object literal for the '<em><b>Roledb</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ATTACHEMENT_SM_DB__ROLEDB = eINSTANCE.getAttachementSmDb_Roledb();

		/**
		 * The meta object literal for the '{@link modelM1.impl.PortFourniConfigurationServeurImpl <em>Port Fourni Configuration Serveur</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modelM1.impl.PortFourniConfigurationServeurImpl
		 * @see modelM1.impl.ModelM1PackageImpl#getPortFourniConfigurationServeur()
		 * @generated
		 */
		EClass PORT_FOURNI_CONFIGURATION_SERVEUR = eINSTANCE.getPortFourniConfigurationServeur();

		/**
		 * The meta object literal for the '{@link modelM1.impl.ServiceFourniClientImpl <em>Service Fourni Client</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modelM1.impl.ServiceFourniClientImpl
		 * @see modelM1.impl.ModelM1PackageImpl#getServiceFourniClient()
		 * @generated
		 */
		EClass SERVICE_FOURNI_CLIENT = eINSTANCE.getServiceFourniClient();

		/**
		 * The meta object literal for the '{@link modelM1.impl.InterfaceSecurityManagerImpl <em>Interface Security Manager</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modelM1.impl.InterfaceSecurityManagerImpl
		 * @see modelM1.impl.ModelM1PackageImpl#getInterfaceSecurityManager()
		 * @generated
		 */
		EClass INTERFACE_SECURITY_MANAGER = eINSTANCE.getInterfaceSecurityManager();

		/**
		 * The meta object literal for the '<em><b>Checkquery</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INTERFACE_SECURITY_MANAGER__CHECKQUERY = eINSTANCE.getInterfaceSecurityManager_Checkquery();

		/**
		 * The meta object literal for the '<em><b>Securityauthentification</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INTERFACE_SECURITY_MANAGER__SECURITYAUTHENTIFICATION = eINSTANCE
				.getInterfaceSecurityManager_Securityauthentification();

		/**
		 * The meta object literal for the '{@link modelM1.impl.BindingExternalSocketImpl <em>Binding External Socket</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modelM1.impl.BindingExternalSocketImpl
		 * @see modelM1.impl.ModelM1PackageImpl#getBindingExternalSocket()
		 * @generated
		 */
		EClass BINDING_EXTERNAL_SOCKET = eINSTANCE.getBindingExternalSocket();

		/**
		 * The meta object literal for the '<em><b>Externalsocket</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BINDING_EXTERNAL_SOCKET__EXTERNALSOCKET = eINSTANCE.getBindingExternalSocket_Externalsocket();

		/**
		 * The meta object literal for the '<em><b>Portfourniconfigurationserveur</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BINDING_EXTERNAL_SOCKET__PORTFOURNICONFIGURATIONSERVEUR = eINSTANCE
				.getBindingExternalSocket_Portfourniconfigurationserveur();

		/**
		 * The meta object literal for the '{@link modelM1.impl.RoleDbImpl <em>Role Db</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modelM1.impl.RoleDbImpl
		 * @see modelM1.impl.ModelM1PackageImpl#getRoleDb()
		 * @generated
		 */
		EClass ROLE_DB = eINSTANCE.getRoleDb();

		/**
		 * The meta object literal for the '{@link modelM1.impl.CheckQueryImpl <em>Check Query</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modelM1.impl.CheckQueryImpl
		 * @see modelM1.impl.ModelM1PackageImpl#getCheckQuery()
		 * @generated
		 */
		EClass CHECK_QUERY = eINSTANCE.getCheckQuery();

		/**
		 * The meta object literal for the '{@link modelM1.impl.AttachementRPCServeurImpl <em>Attachement RPC Serveur</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modelM1.impl.AttachementRPCServeurImpl
		 * @see modelM1.impl.ModelM1PackageImpl#getAttachementRPCServeur()
		 * @generated
		 */
		EClass ATTACHEMENT_RPC_SERVEUR = eINSTANCE.getAttachementRPCServeur();

		/**
		 * The meta object literal for the '<em><b>Interfaceconnecteurrpc</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ATTACHEMENT_RPC_SERVEUR__INTERFACECONNECTEURRPC = eINSTANCE
				.getAttachementRPCServeur_Interfaceconnecteurrpc();

		/**
		 * The meta object literal for the '<em><b>Interfaceconfigurationserveur</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ATTACHEMENT_RPC_SERVEUR__INTERFACECONFIGURATIONSERVEUR = eINSTANCE
				.getAttachementRPCServeur_Interfaceconfigurationserveur();

		/**
		 * The meta object literal for the '{@link modelM1.impl.AttachementClientRPCImpl <em>Attachement Client RPC</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modelM1.impl.AttachementClientRPCImpl
		 * @see modelM1.impl.ModelM1PackageImpl#getAttachementClientRPC()
		 * @generated
		 */
		EClass ATTACHEMENT_CLIENT_RPC = eINSTANCE.getAttachementClientRPC();

		/**
		 * The meta object literal for the '<em><b>Interfaceconnecteurrpc</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ATTACHEMENT_CLIENT_RPC__INTERFACECONNECTEURRPC = eINSTANCE
				.getAttachementClientRPC_Interfaceconnecteurrpc();

		/**
		 * The meta object literal for the '{@link modelM1.impl.SecurityManagementImpl <em>Security Management</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modelM1.impl.SecurityManagementImpl
		 * @see modelM1.impl.ModelM1PackageImpl#getSecurityManagement()
		 * @generated
		 */
		EClass SECURITY_MANAGEMENT = eINSTANCE.getSecurityManagement();

		/**
		 * The meta object literal for the '{@link modelM1.impl.PortFourniClientImpl <em>Port Fourni Client</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modelM1.impl.PortFourniClientImpl
		 * @see modelM1.impl.ModelM1PackageImpl#getPortFourniClient()
		 * @generated
		 */
		EClass PORT_FOURNI_CLIENT = eINSTANCE.getPortFourniClient();

		/**
		 * The meta object literal for the '{@link modelM1.impl.PortRequisClientImpl <em>Port Requis Client</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modelM1.impl.PortRequisClientImpl
		 * @see modelM1.impl.ModelM1PackageImpl#getPortRequisClient()
		 * @generated
		 */
		EClass PORT_REQUIS_CLIENT = eINSTANCE.getPortRequisClient();

		/**
		 * The meta object literal for the '{@link modelM1.impl.AttachementDbSmImpl <em>Attachement Db Sm</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modelM1.impl.AttachementDbSmImpl
		 * @see modelM1.impl.ModelM1PackageImpl#getAttachementDbSm()
		 * @generated
		 */
		EClass ATTACHEMENT_DB_SM = eINSTANCE.getAttachementDbSm();

		/**
		 * The meta object literal for the '<em><b>Rolesm</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ATTACHEMENT_DB_SM__ROLESM = eINSTANCE.getAttachementDbSm_Rolesm();

		/**
		 * The meta object literal for the '<em><b>Securitymanagement</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ATTACHEMENT_DB_SM__SECURITYMANAGEMENT = eINSTANCE.getAttachementDbSm_Securitymanagement();

		/**
		 * The meta object literal for the '{@link modelM1.impl.SecurityManagerImpl <em>Security Manager</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modelM1.impl.SecurityManagerImpl
		 * @see modelM1.impl.ModelM1PackageImpl#getSecurityManager()
		 * @generated
		 */
		EClass SECURITY_MANAGER = eINSTANCE.getSecurityManager();

		/**
		 * The meta object literal for the '{@link modelM1.impl.RoleCmImpl <em>Role Cm</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modelM1.impl.RoleCmImpl
		 * @see modelM1.impl.ModelM1PackageImpl#getRoleCm()
		 * @generated
		 */
		EClass ROLE_CM = eINSTANCE.getRoleCm();

		/**
		 * The meta object literal for the '{@link modelM1.impl.InterfaceConnectionManagerImpl <em>Interface Connection Manager</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modelM1.impl.InterfaceConnectionManagerImpl
		 * @see modelM1.impl.ModelM1PackageImpl#getInterfaceConnectionManager()
		 * @generated
		 */
		EClass INTERFACE_CONNECTION_MANAGER = eINSTANCE.getInterfaceConnectionManager();

		/**
		 * The meta object literal for the '<em><b>Externalsocket</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INTERFACE_CONNECTION_MANAGER__EXTERNALSOCKET = eINSTANCE
				.getInterfaceConnectionManager_Externalsocket();

		/**
		 * The meta object literal for the '<em><b>Dbquery</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INTERFACE_CONNECTION_MANAGER__DBQUERY = eINSTANCE.getInterfaceConnectionManager_Dbquery();

		/**
		 * The meta object literal for the '<em><b>Securitycheck</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INTERFACE_CONNECTION_MANAGER__SECURITYCHECK = eINSTANCE
				.getInterfaceConnectionManager_Securitycheck();

		/**
		 * The meta object literal for the '{@link modelM1.impl.InterfaceClientImpl <em>Interface Client</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modelM1.impl.InterfaceClientImpl
		 * @see modelM1.impl.ModelM1PackageImpl#getInterfaceClient()
		 * @generated
		 */
		EClass INTERFACE_CLIENT = eINSTANCE.getInterfaceClient();

		/**
		 * The meta object literal for the '<em><b>Attachementclientrpc</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INTERFACE_CLIENT__ATTACHEMENTCLIENTRPC = eINSTANCE.getInterfaceClient_Attachementclientrpc();

		/**
		 * The meta object literal for the '<em><b>Portfourniclient</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INTERFACE_CLIENT__PORTFOURNICLIENT = eINSTANCE.getInterfaceClient_Portfourniclient();

		/**
		 * The meta object literal for the '<em><b>Portrequisclient</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INTERFACE_CLIENT__PORTREQUISCLIENT = eINSTANCE.getInterfaceClient_Portrequisclient();

		/**
		 * The meta object literal for the '<em><b>Servicefourniclient</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INTERFACE_CLIENT__SERVICEFOURNICLIENT = eINSTANCE.getInterfaceClient_Servicefourniclient();

		/**
		 * The meta object literal for the '{@link modelM1.impl.ExternalSocketImpl <em>External Socket</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modelM1.impl.ExternalSocketImpl
		 * @see modelM1.impl.ModelM1PackageImpl#getExternalSocket()
		 * @generated
		 */
		EClass EXTERNAL_SOCKET = eINSTANCE.getExternalSocket();

		/**
		 * The meta object literal for the '{@link modelM1.impl.SystemeClientServeurImpl <em>Systeme Client Serveur</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modelM1.impl.SystemeClientServeurImpl
		 * @see modelM1.impl.ModelM1PackageImpl#getSystemeClientServeur()
		 * @generated
		 */
		EClass SYSTEME_CLIENT_SERVEUR = eINSTANCE.getSystemeClientServeur();

		/**
		 * The meta object literal for the '<em><b>Client</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SYSTEME_CLIENT_SERVEUR__CLIENT = eINSTANCE.getSystemeClientServeur_Client();

		/**
		 * The meta object literal for the '<em><b>Serveur</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SYSTEME_CLIENT_SERVEUR__SERVEUR = eINSTANCE.getSystemeClientServeur_Serveur();

		/**
		 * The meta object literal for the '<em><b>Connecteurrpc</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SYSTEME_CLIENT_SERVEUR__CONNECTEURRPC = eINSTANCE.getSystemeClientServeur_Connecteurrpc();

		/**
		 * The meta object literal for the '<em><b>Attachementrpcserveur</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SYSTEME_CLIENT_SERVEUR__ATTACHEMENTRPCSERVEUR = eINSTANCE
				.getSystemeClientServeur_Attachementrpcserveur();

		/**
		 * The meta object literal for the '{@link modelM1.impl.ConfigurationServeurImpl <em>Configuration Serveur</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modelM1.impl.ConfigurationServeurImpl
		 * @see modelM1.impl.ModelM1PackageImpl#getConfigurationServeur()
		 * @generated
		 */
		EClass CONFIGURATION_SERVEUR = eINSTANCE.getConfigurationServeur();

		/**
		 * The meta object literal for the '<em><b>Interfaceconfigurationserveur</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONFIGURATION_SERVEUR__INTERFACECONFIGURATIONSERVEUR = eINSTANCE
				.getConfigurationServeur_Interfaceconfigurationserveur();

		/**
		 * The meta object literal for the '<em><b>Securitymanager</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONFIGURATION_SERVEUR__SECURITYMANAGER = eINSTANCE.getConfigurationServeur_Securitymanager();

		/**
		 * The meta object literal for the '<em><b>Connecteurcmdb</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONFIGURATION_SERVEUR__CONNECTEURCMDB = eINSTANCE.getConfigurationServeur_Connecteurcmdb();

		/**
		 * The meta object literal for the '<em><b>Connectionmanager</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONFIGURATION_SERVEUR__CONNECTIONMANAGER = eINSTANCE.getConfigurationServeur_Connectionmanager();

		/**
		 * The meta object literal for the '<em><b>Attachementcmdb</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONFIGURATION_SERVEUR__ATTACHEMENTCMDB = eINSTANCE.getConfigurationServeur_Attachementcmdb();

		/**
		 * The meta object literal for the '<em><b>Attachementsmdb</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONFIGURATION_SERVEUR__ATTACHEMENTSMDB = eINSTANCE.getConfigurationServeur_Attachementsmdb();

		/**
		 * The meta object literal for the '<em><b>Securitymanagement</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONFIGURATION_SERVEUR__SECURITYMANAGEMENT = eINSTANCE.getConfigurationServeur_Securitymanagement();

		/**
		 * The meta object literal for the '<em><b>Attachementcmsm</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONFIGURATION_SERVEUR__ATTACHEMENTCMSM = eINSTANCE.getConfigurationServeur_Attachementcmsm();

		/**
		 * The meta object literal for the '<em><b>Connecteurdbsm</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONFIGURATION_SERVEUR__CONNECTEURDBSM = eINSTANCE.getConfigurationServeur_Connecteurdbsm();

		/**
		 * The meta object literal for the '<em><b>Attachementsmcm</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONFIGURATION_SERVEUR__ATTACHEMENTSMCM = eINSTANCE.getConfigurationServeur_Attachementsmcm();

		/**
		 * The meta object literal for the '<em><b>Database</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONFIGURATION_SERVEUR__DATABASE = eINSTANCE.getConfigurationServeur_Database();

		/**
		 * The meta object literal for the '<em><b>Attachementdbcm</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONFIGURATION_SERVEUR__ATTACHEMENTDBCM = eINSTANCE.getConfigurationServeur_Attachementdbcm();

		/**
		 * The meta object literal for the '<em><b>Attachementdbsm</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONFIGURATION_SERVEUR__ATTACHEMENTDBSM = eINSTANCE.getConfigurationServeur_Attachementdbsm();

		/**
		 * The meta object literal for the '<em><b>Connecteurcmsm</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONFIGURATION_SERVEUR__CONNECTEURCMSM = eINSTANCE.getConfigurationServeur_Connecteurcmsm();

		/**
		 * The meta object literal for the '{@link modelM1.impl.QueryInterogationImpl <em>Query Interogation</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modelM1.impl.QueryInterogationImpl
		 * @see modelM1.impl.ModelM1PackageImpl#getQueryInterogation()
		 * @generated
		 */
		EClass QUERY_INTEROGATION = eINSTANCE.getQueryInterogation();

		/**
		 * The meta object literal for the '{@link modelM1.impl.InterfaceDatabaseImpl <em>Interface Database</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modelM1.impl.InterfaceDatabaseImpl
		 * @see modelM1.impl.ModelM1PackageImpl#getInterfaceDatabase()
		 * @generated
		 */
		EClass INTERFACE_DATABASE = eINSTANCE.getInterfaceDatabase();

		/**
		 * The meta object literal for the '<em><b>Queryinterogation</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INTERFACE_DATABASE__QUERYINTEROGATION = eINSTANCE.getInterfaceDatabase_Queryinterogation();

		/**
		 * The meta object literal for the '<em><b>Securitymanagement</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INTERFACE_DATABASE__SECURITYMANAGEMENT = eINSTANCE.getInterfaceDatabase_Securitymanagement();

		/**
		 * The meta object literal for the '{@link modelM1.impl.DatabaseImpl <em>Database</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modelM1.impl.DatabaseImpl
		 * @see modelM1.impl.ModelM1PackageImpl#getDatabase()
		 * @generated
		 */
		EClass DATABASE = eINSTANCE.getDatabase();

		/**
		 * The meta object literal for the '<em><b>Interfacedatabase</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DATABASE__INTERFACEDATABASE = eINSTANCE.getDatabase_Interfacedatabase();

		/**
		 * The meta object literal for the '{@link modelM1.impl.ConnecteurCmSmImpl <em>Connecteur Cm Sm</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modelM1.impl.ConnecteurCmSmImpl
		 * @see modelM1.impl.ModelM1PackageImpl#getConnecteurCmSm()
		 * @generated
		 */
		EClass CONNECTEUR_CM_SM = eINSTANCE.getConnecteurCmSm();

		/**
		 * The meta object literal for the '<em><b>Interfaceconnecteurcmsm</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONNECTEUR_CM_SM__INTERFACECONNECTEURCMSM = eINSTANCE.getConnecteurCmSm_Interfaceconnecteurcmsm();

		/**
		 * The meta object literal for the '{@link modelM1.impl.InterfaceConnecteurRPCImpl <em>Interface Connecteur RPC</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modelM1.impl.InterfaceConnecteurRPCImpl
		 * @see modelM1.impl.ModelM1PackageImpl#getInterfaceConnecteurRPC()
		 * @generated
		 */
		EClass INTERFACE_CONNECTEUR_RPC = eINSTANCE.getInterfaceConnecteurRPC();

		/**
		 * The meta object literal for the '{@link modelM1.impl.AttachementCmSmImpl <em>Attachement Cm Sm</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modelM1.impl.AttachementCmSmImpl
		 * @see modelM1.impl.ModelM1PackageImpl#getAttachementCmSm()
		 * @generated
		 */
		EClass ATTACHEMENT_CM_SM = eINSTANCE.getAttachementCmSm();

		/**
		 * The meta object literal for the '<em><b>Rolesm</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ATTACHEMENT_CM_SM__ROLESM = eINSTANCE.getAttachementCmSm_Rolesm();

		/**
		 * The meta object literal for the '<em><b>Securitycheck</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ATTACHEMENT_CM_SM__SECURITYCHECK = eINSTANCE.getAttachementCmSm_Securitycheck();

		/**
		 * The meta object literal for the '{@link modelM1.impl.AttachementCmDbImpl <em>Attachement Cm Db</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modelM1.impl.AttachementCmDbImpl
		 * @see modelM1.impl.ModelM1PackageImpl#getAttachementCmDb()
		 * @generated
		 */
		EClass ATTACHEMENT_CM_DB = eINSTANCE.getAttachementCmDb();

		/**
		 * The meta object literal for the '<em><b>Roledb</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ATTACHEMENT_CM_DB__ROLEDB = eINSTANCE.getAttachementCmDb_Roledb();

		/**
		 * The meta object literal for the '<em><b>Dbquery</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ATTACHEMENT_CM_DB__DBQUERY = eINSTANCE.getAttachementCmDb_Dbquery();

		/**
		 * The meta object literal for the '{@link modelM1.impl.InterfaceConnecteurCmDbImpl <em>Interface Connecteur Cm Db</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modelM1.impl.InterfaceConnecteurCmDbImpl
		 * @see modelM1.impl.ModelM1PackageImpl#getInterfaceConnecteurCmDb()
		 * @generated
		 */
		EClass INTERFACE_CONNECTEUR_CM_DB = eINSTANCE.getInterfaceConnecteurCmDb();

		/**
		 * The meta object literal for the '<em><b>Roledb</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INTERFACE_CONNECTEUR_CM_DB__ROLEDB = eINSTANCE.getInterfaceConnecteurCmDb_Roledb();

		/**
		 * The meta object literal for the '<em><b>Rolecm</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INTERFACE_CONNECTEUR_CM_DB__ROLECM = eINSTANCE.getInterfaceConnecteurCmDb_Rolecm();

		/**
		 * The meta object literal for the '{@link modelM1.impl.AttachementSmCmImpl <em>Attachement Sm Cm</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modelM1.impl.AttachementSmCmImpl
		 * @see modelM1.impl.ModelM1PackageImpl#getAttachementSmCm()
		 * @generated
		 */
		EClass ATTACHEMENT_SM_CM = eINSTANCE.getAttachementSmCm();

		/**
		 * The meta object literal for the '<em><b>Securityauthentification</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ATTACHEMENT_SM_CM__SECURITYAUTHENTIFICATION = eINSTANCE
				.getAttachementSmCm_Securityauthentification();

		/**
		 * The meta object literal for the '<em><b>Rolecm</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ATTACHEMENT_SM_CM__ROLECM = eINSTANCE.getAttachementSmCm_Rolecm();

		/**
		 * The meta object literal for the '{@link modelM1.impl.ClientImpl <em>Client</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modelM1.impl.ClientImpl
		 * @see modelM1.impl.ModelM1PackageImpl#getClient()
		 * @generated
		 */
		EClass CLIENT = eINSTANCE.getClient();

		/**
		 * The meta object literal for the '<em><b>Interfaceclient</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CLIENT__INTERFACECLIENT = eINSTANCE.getClient_Interfaceclient();

		/**
		 * The meta object literal for the '{@link modelM1.impl.ConnecteurCmDbImpl <em>Connecteur Cm Db</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modelM1.impl.ConnecteurCmDbImpl
		 * @see modelM1.impl.ModelM1PackageImpl#getConnecteurCmDb()
		 * @generated
		 */
		EClass CONNECTEUR_CM_DB = eINSTANCE.getConnecteurCmDb();

		/**
		 * The meta object literal for the '<em><b>Interfaceconnecteurcmdb</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONNECTEUR_CM_DB__INTERFACECONNECTEURCMDB = eINSTANCE.getConnecteurCmDb_Interfaceconnecteurcmdb();

		/**
		 * The meta object literal for the '{@link modelM1.impl.RoleSmImpl <em>Role Sm</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modelM1.impl.RoleSmImpl
		 * @see modelM1.impl.ModelM1PackageImpl#getRoleSm()
		 * @generated
		 */
		EClass ROLE_SM = eINSTANCE.getRoleSm();

		/**
		 * The meta object literal for the '{@link modelM1.impl.SecurityCheckImpl <em>Security Check</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modelM1.impl.SecurityCheckImpl
		 * @see modelM1.impl.ModelM1PackageImpl#getSecurityCheck()
		 * @generated
		 */
		EClass SECURITY_CHECK = eINSTANCE.getSecurityCheck();

		/**
		 * The meta object literal for the '{@link modelM1.impl.ConnecteurRPCImpl <em>Connecteur RPC</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modelM1.impl.ConnecteurRPCImpl
		 * @see modelM1.impl.ModelM1PackageImpl#getConnecteurRPC()
		 * @generated
		 */
		EClass CONNECTEUR_RPC = eINSTANCE.getConnecteurRPC();

		/**
		 * The meta object literal for the '<em><b>Interfaceconnecteurrpc</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONNECTEUR_RPC__INTERFACECONNECTEURRPC = eINSTANCE.getConnecteurRPC_Interfaceconnecteurrpc();

		/**
		 * The meta object literal for the '{@link modelM1.impl.AttachementDbCmImpl <em>Attachement Db Cm</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modelM1.impl.AttachementDbCmImpl
		 * @see modelM1.impl.ModelM1PackageImpl#getAttachementDbCm()
		 * @generated
		 */
		EClass ATTACHEMENT_DB_CM = eINSTANCE.getAttachementDbCm();

		/**
		 * The meta object literal for the '<em><b>Queryinterogation</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ATTACHEMENT_DB_CM__QUERYINTEROGATION = eINSTANCE.getAttachementDbCm_Queryinterogation();

		/**
		 * The meta object literal for the '<em><b>Rolecm</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ATTACHEMENT_DB_CM__ROLECM = eINSTANCE.getAttachementDbCm_Rolecm();

		/**
		 * The meta object literal for the '{@link modelM1.impl.InterfaceConfigurationServeurImpl <em>Interface Configuration Serveur</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modelM1.impl.InterfaceConfigurationServeurImpl
		 * @see modelM1.impl.ModelM1PackageImpl#getInterfaceConfigurationServeur()
		 * @generated
		 */
		EClass INTERFACE_CONFIGURATION_SERVEUR = eINSTANCE.getInterfaceConfigurationServeur();

		/**
		 * The meta object literal for the '<em><b>Portfourniconfigurationserveur</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INTERFACE_CONFIGURATION_SERVEUR__PORTFOURNICONFIGURATIONSERVEUR = eINSTANCE
				.getInterfaceConfigurationServeur_Portfourniconfigurationserveur();

		/**
		 * The meta object literal for the '{@link modelM1.impl.ConnectionManagerImpl <em>Connection Manager</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modelM1.impl.ConnectionManagerImpl
		 * @see modelM1.impl.ModelM1PackageImpl#getConnectionManager()
		 * @generated
		 */
		EClass CONNECTION_MANAGER = eINSTANCE.getConnectionManager();

		/**
		 * The meta object literal for the '<em><b>Interfaceconnectionmanager</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONNECTION_MANAGER__INTERFACECONNECTIONMANAGER = eINSTANCE
				.getConnectionManager_Interfaceconnectionmanager();

		/**
		 * The meta object literal for the '{@link modelM1.impl.ServeurImpl <em>Serveur</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modelM1.impl.ServeurImpl
		 * @see modelM1.impl.ModelM1PackageImpl#getServeur()
		 * @generated
		 */
		EClass SERVEUR = eINSTANCE.getServeur();

		/**
		 * The meta object literal for the '<em><b>Configurationserveur</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SERVEUR__CONFIGURATIONSERVEUR = eINSTANCE.getServeur_Configurationserveur();

		/**
		 * The meta object literal for the '{@link modelM1.impl.ConnecteurDbSmImpl <em>Connecteur Db Sm</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modelM1.impl.ConnecteurDbSmImpl
		 * @see modelM1.impl.ModelM1PackageImpl#getConnecteurDbSm()
		 * @generated
		 */
		EClass CONNECTEUR_DB_SM = eINSTANCE.getConnecteurDbSm();

		/**
		 * The meta object literal for the '<em><b>Interfaceconnecteurdbsm</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONNECTEUR_DB_SM__INTERFACECONNECTEURDBSM = eINSTANCE.getConnecteurDbSm_Interfaceconnecteurdbsm();

	}

} //ModelM1Package

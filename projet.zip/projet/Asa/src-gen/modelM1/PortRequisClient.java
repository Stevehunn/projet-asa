/**
 */
package modelM1;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Port Requis Client</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see modelM1.ModelM1Package#getPortRequisClient()
 * @model
 * @generated
 */
public interface PortRequisClient extends EObject {
} // PortRequisClient

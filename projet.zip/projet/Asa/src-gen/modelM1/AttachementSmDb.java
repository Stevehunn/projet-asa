/**
 */
package modelM1;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Attachement Sm Db</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link modelM1.AttachementSmDb#getCheckquery <em>Checkquery</em>}</li>
 *   <li>{@link modelM1.AttachementSmDb#getRoledb <em>Roledb</em>}</li>
 * </ul>
 *
 * @see modelM1.ModelM1Package#getAttachementSmDb()
 * @model
 * @generated
 */
public interface AttachementSmDb extends EObject {
	/**
	 * Returns the value of the '<em><b>Checkquery</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Checkquery</em>' reference.
	 * @see #setCheckquery(CheckQuery)
	 * @see modelM1.ModelM1Package#getAttachementSmDb_Checkquery()
	 * @model
	 * @generated
	 */
	CheckQuery getCheckquery();

	/**
	 * Sets the value of the '{@link modelM1.AttachementSmDb#getCheckquery <em>Checkquery</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Checkquery</em>' reference.
	 * @see #getCheckquery()
	 * @generated
	 */
	void setCheckquery(CheckQuery value);

	/**
	 * Returns the value of the '<em><b>Roledb</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Roledb</em>' reference.
	 * @see #setRoledb(RoleDb)
	 * @see modelM1.ModelM1Package#getAttachementSmDb_Roledb()
	 * @model
	 * @generated
	 */
	RoleDb getRoledb();

	/**
	 * Sets the value of the '{@link modelM1.AttachementSmDb#getRoledb <em>Roledb</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Roledb</em>' reference.
	 * @see #getRoledb()
	 * @generated
	 */
	void setRoledb(RoleDb value);

} // AttachementSmDb

/**
 */
package modelM1;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see modelM1.ModelM1Package
 * @generated
 */
public interface ModelM1Factory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	ModelM1Factory eINSTANCE = modelM1.impl.ModelM1FactoryImpl.init();

	/**
	 * Returns a new object of class '<em>Security Authentification</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Security Authentification</em>'.
	 * @generated
	 */
	SecurityAuthentification createSecurityAuthentification();

	/**
	 * Returns a new object of class '<em>Interface Connecteur Cm Sm</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Interface Connecteur Cm Sm</em>'.
	 * @generated
	 */
	InterfaceConnecteurCmSm createInterfaceConnecteurCmSm();

	/**
	 * Returns a new object of class '<em>Db Query</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Db Query</em>'.
	 * @generated
	 */
	DbQuery createDbQuery();

	/**
	 * Returns a new object of class '<em>Interface Connecteur Db Sm</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Interface Connecteur Db Sm</em>'.
	 * @generated
	 */
	InterfaceConnecteurDbSm createInterfaceConnecteurDbSm();

	/**
	 * Returns a new object of class '<em>Attachement Sm Db</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Attachement Sm Db</em>'.
	 * @generated
	 */
	AttachementSmDb createAttachementSmDb();

	/**
	 * Returns a new object of class '<em>Port Fourni Configuration Serveur</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Port Fourni Configuration Serveur</em>'.
	 * @generated
	 */
	PortFourniConfigurationServeur createPortFourniConfigurationServeur();

	/**
	 * Returns a new object of class '<em>Service Fourni Client</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Service Fourni Client</em>'.
	 * @generated
	 */
	ServiceFourniClient createServiceFourniClient();

	/**
	 * Returns a new object of class '<em>Interface Security Manager</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Interface Security Manager</em>'.
	 * @generated
	 */
	InterfaceSecurityManager createInterfaceSecurityManager();

	/**
	 * Returns a new object of class '<em>Binding External Socket</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Binding External Socket</em>'.
	 * @generated
	 */
	BindingExternalSocket createBindingExternalSocket();

	/**
	 * Returns a new object of class '<em>Role Db</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Role Db</em>'.
	 * @generated
	 */
	RoleDb createRoleDb();

	/**
	 * Returns a new object of class '<em>Check Query</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Check Query</em>'.
	 * @generated
	 */
	CheckQuery createCheckQuery();

	/**
	 * Returns a new object of class '<em>Attachement RPC Serveur</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Attachement RPC Serveur</em>'.
	 * @generated
	 */
	AttachementRPCServeur createAttachementRPCServeur();

	/**
	 * Returns a new object of class '<em>Attachement Client RPC</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Attachement Client RPC</em>'.
	 * @generated
	 */
	AttachementClientRPC createAttachementClientRPC();

	/**
	 * Returns a new object of class '<em>Security Management</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Security Management</em>'.
	 * @generated
	 */
	SecurityManagement createSecurityManagement();

	/**
	 * Returns a new object of class '<em>Port Fourni Client</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Port Fourni Client</em>'.
	 * @generated
	 */
	PortFourniClient createPortFourniClient();

	/**
	 * Returns a new object of class '<em>Port Requis Client</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Port Requis Client</em>'.
	 * @generated
	 */
	PortRequisClient createPortRequisClient();

	/**
	 * Returns a new object of class '<em>Attachement Db Sm</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Attachement Db Sm</em>'.
	 * @generated
	 */
	AttachementDbSm createAttachementDbSm();

	/**
	 * Returns a new object of class '<em>Security Manager</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Security Manager</em>'.
	 * @generated
	 */
	SecurityManager createSecurityManager();

	/**
	 * Returns a new object of class '<em>Role Cm</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Role Cm</em>'.
	 * @generated
	 */
	RoleCm createRoleCm();

	/**
	 * Returns a new object of class '<em>Interface Connection Manager</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Interface Connection Manager</em>'.
	 * @generated
	 */
	InterfaceConnectionManager createInterfaceConnectionManager();

	/**
	 * Returns a new object of class '<em>Interface Client</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Interface Client</em>'.
	 * @generated
	 */
	InterfaceClient createInterfaceClient();

	/**
	 * Returns a new object of class '<em>External Socket</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>External Socket</em>'.
	 * @generated
	 */
	ExternalSocket createExternalSocket();

	/**
	 * Returns a new object of class '<em>Systeme Client Serveur</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Systeme Client Serveur</em>'.
	 * @generated
	 */
	SystemeClientServeur createSystemeClientServeur();

	/**
	 * Returns a new object of class '<em>Configuration Serveur</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Configuration Serveur</em>'.
	 * @generated
	 */
	ConfigurationServeur createConfigurationServeur();

	/**
	 * Returns a new object of class '<em>Query Interogation</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Query Interogation</em>'.
	 * @generated
	 */
	QueryInterogation createQueryInterogation();

	/**
	 * Returns a new object of class '<em>Interface Database</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Interface Database</em>'.
	 * @generated
	 */
	InterfaceDatabase createInterfaceDatabase();

	/**
	 * Returns a new object of class '<em>Database</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Database</em>'.
	 * @generated
	 */
	Database createDatabase();

	/**
	 * Returns a new object of class '<em>Connecteur Cm Sm</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Connecteur Cm Sm</em>'.
	 * @generated
	 */
	ConnecteurCmSm createConnecteurCmSm();

	/**
	 * Returns a new object of class '<em>Interface Connecteur RPC</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Interface Connecteur RPC</em>'.
	 * @generated
	 */
	InterfaceConnecteurRPC createInterfaceConnecteurRPC();

	/**
	 * Returns a new object of class '<em>Attachement Cm Sm</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Attachement Cm Sm</em>'.
	 * @generated
	 */
	AttachementCmSm createAttachementCmSm();

	/**
	 * Returns a new object of class '<em>Attachement Cm Db</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Attachement Cm Db</em>'.
	 * @generated
	 */
	AttachementCmDb createAttachementCmDb();

	/**
	 * Returns a new object of class '<em>Interface Connecteur Cm Db</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Interface Connecteur Cm Db</em>'.
	 * @generated
	 */
	InterfaceConnecteurCmDb createInterfaceConnecteurCmDb();

	/**
	 * Returns a new object of class '<em>Attachement Sm Cm</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Attachement Sm Cm</em>'.
	 * @generated
	 */
	AttachementSmCm createAttachementSmCm();

	/**
	 * Returns a new object of class '<em>Client</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Client</em>'.
	 * @generated
	 */
	Client createClient();

	/**
	 * Returns a new object of class '<em>Connecteur Cm Db</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Connecteur Cm Db</em>'.
	 * @generated
	 */
	ConnecteurCmDb createConnecteurCmDb();

	/**
	 * Returns a new object of class '<em>Role Sm</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Role Sm</em>'.
	 * @generated
	 */
	RoleSm createRoleSm();

	/**
	 * Returns a new object of class '<em>Security Check</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Security Check</em>'.
	 * @generated
	 */
	SecurityCheck createSecurityCheck();

	/**
	 * Returns a new object of class '<em>Connecteur RPC</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Connecteur RPC</em>'.
	 * @generated
	 */
	ConnecteurRPC createConnecteurRPC();

	/**
	 * Returns a new object of class '<em>Attachement Db Cm</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Attachement Db Cm</em>'.
	 * @generated
	 */
	AttachementDbCm createAttachementDbCm();

	/**
	 * Returns a new object of class '<em>Interface Configuration Serveur</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Interface Configuration Serveur</em>'.
	 * @generated
	 */
	InterfaceConfigurationServeur createInterfaceConfigurationServeur();

	/**
	 * Returns a new object of class '<em>Connection Manager</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Connection Manager</em>'.
	 * @generated
	 */
	ConnectionManager createConnectionManager();

	/**
	 * Returns a new object of class '<em>Serveur</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Serveur</em>'.
	 * @generated
	 */
	Serveur createServeur();

	/**
	 * Returns a new object of class '<em>Connecteur Db Sm</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Connecteur Db Sm</em>'.
	 * @generated
	 */
	ConnecteurDbSm createConnecteurDbSm();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	ModelM1Package getModelM1Package();

} //ModelM1Factory

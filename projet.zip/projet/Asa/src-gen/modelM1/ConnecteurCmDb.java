/**
 */
package modelM1;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Connecteur Cm Db</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link modelM1.ConnecteurCmDb#getInterfaceconnecteurcmdb <em>Interfaceconnecteurcmdb</em>}</li>
 * </ul>
 *
 * @see modelM1.ModelM1Package#getConnecteurCmDb()
 * @model
 * @generated
 */
public interface ConnecteurCmDb extends EObject {
	/**
	 * Returns the value of the '<em><b>Interfaceconnecteurcmdb</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Interfaceconnecteurcmdb</em>' reference.
	 * @see #setInterfaceconnecteurcmdb(InterfaceConnecteurCmDb)
	 * @see modelM1.ModelM1Package#getConnecteurCmDb_Interfaceconnecteurcmdb()
	 * @model
	 * @generated
	 */
	InterfaceConnecteurCmDb getInterfaceconnecteurcmdb();

	/**
	 * Sets the value of the '{@link modelM1.ConnecteurCmDb#getInterfaceconnecteurcmdb <em>Interfaceconnecteurcmdb</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Interfaceconnecteurcmdb</em>' reference.
	 * @see #getInterfaceconnecteurcmdb()
	 * @generated
	 */
	void setInterfaceconnecteurcmdb(InterfaceConnecteurCmDb value);

} // ConnecteurCmDb

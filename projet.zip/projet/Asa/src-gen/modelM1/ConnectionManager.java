/**
 */
package modelM1;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Connection Manager</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link modelM1.ConnectionManager#getInterfaceconnectionmanager <em>Interfaceconnectionmanager</em>}</li>
 * </ul>
 *
 * @see modelM1.ModelM1Package#getConnectionManager()
 * @model
 * @generated
 */
public interface ConnectionManager extends EObject {
	/**
	 * Returns the value of the '<em><b>Interfaceconnectionmanager</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Interfaceconnectionmanager</em>' reference.
	 * @see #setInterfaceconnectionmanager(InterfaceConnectionManager)
	 * @see modelM1.ModelM1Package#getConnectionManager_Interfaceconnectionmanager()
	 * @model
	 * @generated
	 */
	InterfaceConnectionManager getInterfaceconnectionmanager();

	/**
	 * Sets the value of the '{@link modelM1.ConnectionManager#getInterfaceconnectionmanager <em>Interfaceconnectionmanager</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Interfaceconnectionmanager</em>' reference.
	 * @see #getInterfaceconnectionmanager()
	 * @generated
	 */
	void setInterfaceconnectionmanager(InterfaceConnectionManager value);

} // ConnectionManager

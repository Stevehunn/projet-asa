/**
 */
package modelM1;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Interface Security Manager</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link modelM1.InterfaceSecurityManager#getCheckquery <em>Checkquery</em>}</li>
 *   <li>{@link modelM1.InterfaceSecurityManager#getSecurityauthentification <em>Securityauthentification</em>}</li>
 * </ul>
 *
 * @see modelM1.ModelM1Package#getInterfaceSecurityManager()
 * @model
 * @generated
 */
public interface InterfaceSecurityManager extends EObject {
	/**
	 * Returns the value of the '<em><b>Checkquery</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Checkquery</em>' reference.
	 * @see #setCheckquery(CheckQuery)
	 * @see modelM1.ModelM1Package#getInterfaceSecurityManager_Checkquery()
	 * @model
	 * @generated
	 */
	CheckQuery getCheckquery();

	/**
	 * Sets the value of the '{@link modelM1.InterfaceSecurityManager#getCheckquery <em>Checkquery</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Checkquery</em>' reference.
	 * @see #getCheckquery()
	 * @generated
	 */
	void setCheckquery(CheckQuery value);

	/**
	 * Returns the value of the '<em><b>Securityauthentification</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Securityauthentification</em>' reference.
	 * @see #setSecurityauthentification(SecurityAuthentification)
	 * @see modelM1.ModelM1Package#getInterfaceSecurityManager_Securityauthentification()
	 * @model
	 * @generated
	 */
	SecurityAuthentification getSecurityauthentification();

	/**
	 * Sets the value of the '{@link modelM1.InterfaceSecurityManager#getSecurityauthentification <em>Securityauthentification</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Securityauthentification</em>' reference.
	 * @see #getSecurityauthentification()
	 * @generated
	 */
	void setSecurityauthentification(SecurityAuthentification value);

} // InterfaceSecurityManager

package main;
import modelM1.impl.*;

import asa.impl.*;

public class main {
	 public static void main (String[] args) {
		   SystemeClientServeurImpl system = new SystemeClientServeurImpl();

		   
		   ClientImpl client = new ClientImpl();
		   InterfaceClientImpl interfaceClient = new InterfaceClientImpl();
		   PortRequisClientImpl portClient = new PortRequisClientImpl();
		   portClient.setValue("valeur");
		   interfaceClient.setPortrequisclient(portClient);
		   client.setInterfaceclient(interfaceClient);
		   
		   
		// Creation serveur
		   ServeurImpl serveur = new ServeurImpl();
		   ConfigurationServeurImpl configServeur = new ConfigurationServeurImpl();
		   InterfaceConfigurationServeurImpl interfaceConfigServeur = new InterfaceConfigurationServeurImpl();
		   PortFourniConfigurationServeurImpl portFourniConfigServeur = new PortFourniConfigurationServeurImpl();
		   interfaceConfigServeur.setPortfourniconfigurationserveur(portFourniConfigServeur);
		   configServeur.setInterfaceconfigurationserveur(interfaceConfigServeur);
		   
		 //Creation connecteur RPC
		   ConnecteurRPCImpl rpc = new ConnecteurRPCImpl();
		   InterfaceConnecteurRPCImpl interfaceRPC = new InterfaceConnecteurRPCImpl();
		   RoleFourniImpl roleClient = new RoleFourniImpl();
		   RoleRequisImpl roleServeur = new RoleRequisImpl();
		   interfaceRPC.roles.add(roleServeur);
		   interfaceRPC.roles.add(roleClient);

		   
		   // Creation des attachement
		   AttachementRPCServeurImpl attachRPCServeur = new AttachementRPCServeurImpl();
		   attachRPCServeur.setRoleRequis(roleServeur);
		   AttachementClientRPCImpl attachRPCClient = new AttachementClientRPCImpl();
		   attachRPCClient.setRoleFourni(roleClient);
		   attachRPCClient.setPortRequis(portClient);
		   
		 //Ajout des composant au systÃ¨me
		   system.setComposantFeuilleClient(client);
		   system.setComposantCompositeServeur(serveur);
		   system.setConnecteurrpc(rpc);
		   system.setAttachementrpcclient(attachRPCClient);
		   system.setAttachementrpcserveur(attachRPCServeur);
	   }
}
